package com.example.king.managebook.presenters.statictis.customer_statictis;

import com.example.king.managebook.presenters.BaseInteractor;

public interface CustomerStatictisInterator extends BaseInteractor {
    void callListCustomerStatictis(OnGetCustomerStatictisSuccessListener listener);
}
