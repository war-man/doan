package com.example.king.managebook.presenters.confirmation.detail_order;


import com.example.king.managebook.presenters.BasePresenter;

/**
 * Created by KingIT on 4/22/2018.
 */

public interface GetItemsPresenter extends BasePresenter {
    void showItemPreviews(String orderID);
}
