package com.example.king.managebook.model;

import java.io.Serializable;

/**
 * Created by KingIT on 4/25/2018.
 */

public class Customer implements Serializable{
}
