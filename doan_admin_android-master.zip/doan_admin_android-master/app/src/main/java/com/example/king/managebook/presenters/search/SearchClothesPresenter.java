package com.example.king.managebook.presenters.search;


import com.example.king.managebook.presenters.BasePresenter;

public interface SearchClothesPresenter extends BasePresenter {
    void fetchListClothesSearchPreview();
}
