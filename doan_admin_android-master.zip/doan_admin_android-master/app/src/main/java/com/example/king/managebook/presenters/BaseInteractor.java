package com.example.king.managebook.presenters;



public interface BaseInteractor {
    void onViewDestroy();
}
