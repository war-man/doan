package com.example.king.managebook.presenters.account.login;

public interface OnGetFacebookLoginStateListener {
    void onGetState(Object o);
    void onError(String msg);
}
