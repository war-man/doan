package com.example.king.managebook.view.manage_category;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.king.managebook.R;

public class AddCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);
    }
}
