package com.example.king.managebook.presenters.shop.clothes_detail;

public interface OnGetClothesStateSuccessListener {
        void onGetStateSuccess(boolean state);
        void onError(String msg);
}
