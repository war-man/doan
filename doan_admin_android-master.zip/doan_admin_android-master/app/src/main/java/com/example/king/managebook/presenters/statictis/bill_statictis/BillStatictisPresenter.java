package com.example.king.managebook.presenters.statictis.bill_statictis;

import com.example.king.managebook.presenters.BasePresenter;

public interface BillStatictisPresenter extends BasePresenter {
    void staticBillByYear(String year);
}
