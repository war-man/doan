package com.example.king.managebook.presenters.shop.clothes_detail;


import com.example.king.managebook.presenters.BasePresenter;

/**
 * Created by KingIT on 4/23/2018.
 */

public interface ClothesDetailPresenter extends BasePresenter {
    void fetchClothesDetail(String clothesID);

}
