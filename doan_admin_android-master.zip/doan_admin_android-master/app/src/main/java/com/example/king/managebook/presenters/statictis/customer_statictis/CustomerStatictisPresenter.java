package com.example.king.managebook.presenters.statictis.customer_statictis;

import com.example.king.managebook.presenters.BasePresenter;

public interface CustomerStatictisPresenter extends BasePresenter {
    void getListCustomerStatictis();
}
