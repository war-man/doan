package com.example.king.managebook.presenters;


public interface BasePresenter {
    void onViewDestroy();
}
