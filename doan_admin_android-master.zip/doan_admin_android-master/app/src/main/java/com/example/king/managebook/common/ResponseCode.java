package com.example.king.managebook.common;

/**
<<<<<<< HEAD
 * Created by La Vo Tinh on 23/01/2018.
=======
 * Created by TranThanhTung on 23/01/2018.
>>>>>>> 3e7089d8449f4fd61835e2738564ed1edf3331d2
 */

public class ResponseCode {
    public static final int OK = 200;
    public static final int BAD_REQUEST = 400;
    public static final int NOT_FOUND = 404;
    public static final int CONFLICT = 409;
    public static final int UNAUTHORIZATION = 401;
    public static final int FORBIDDEN = 403;
}
