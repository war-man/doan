package com.example.king.managebook.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.king.managebook.R;
import com.example.king.managebook.common.Utils;
import com.example.king.managebook.model.response.SaveClothesPreview;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SaveClothesAdapter extends EndlessLoadingRecyclerViewAdapter implements View.OnClickListener{
    OnButtonSaveClick onButtonSaveClick;
    public SaveClothesAdapter(Context context, boolean enableSelectedMode,OnButtonSaveClick onButtonSaveClick) {
        super(context, enableSelectedMode);
        this.onButtonSaveClick = onButtonSaveClick;
    }

    @Override
    protected RecyclerView.ViewHolder initLoadingViewHolder(ViewGroup parent) {

        View view = LayoutInflater.from(getContext()).inflate(R.layout.item_load_more,parent,false);
        return new SaveClothesPreviewHolder(view);
    }

    @Override
    protected void bindLoadingViewHolder(LoadingViewHolder loadingViewHolder, int position) {

    }

    @Override
    protected RecyclerView.ViewHolder initNormalViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.item_save_clothes,parent,false);
        return new SaveClothesPreviewHolder(view);
    }

    @Override
    protected void bindNormalViewHolder(NormalViewHolder normalViewHolder, int position) {
        SaveClothesPreviewHolder holder = (SaveClothesPreviewHolder) normalViewHolder;
        SaveClothesPreview saveClothesPreview = getItem(position,SaveClothesPreview.class);
        holder.tvCreatedDate.setText(Utils.getDateFromMilliseconds(saveClothesPreview.getSaveDate()));
        holder.tvName.setText(saveClothesPreview.getName());
        holder.tvprice.setText(Utils.formatNumberMoney(saveClothesPreview.getPrice())+" đ");
        Glide.with(getContext()).load(saveClothesPreview.getLogoUrl()).apply(new RequestOptions().placeholder(R.drawable.logo_clothes)).into(holder.imgAvatar);

    }

    @Override
    public void onClick(View view) {

    }

    class SaveClothesPreviewHolder extends NormalViewHolder{
        @BindView(R.id.img_avatar)
        ImageView imgAvatar;
        @BindView(R.id.tv_full_name)
        TextView tvName;
        @BindView(R.id.tv_price)
        TextView tvprice;
        @BindView(R.id.tv_created_date)
        TextView tvCreatedDate;
        @BindView(R.id.img_save)
        ImageView img_save;

        public SaveClothesPreviewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            img_save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onButtonSaveClick.onClick(getAdapterPosition());
                }
            });
        }
    }

    public interface OnButtonSaveClick{
        void onClick(int pos);
    }


}
