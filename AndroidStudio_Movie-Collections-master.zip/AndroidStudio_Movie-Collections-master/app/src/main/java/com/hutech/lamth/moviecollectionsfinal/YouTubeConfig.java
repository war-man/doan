package com.hutech.lamth.moviecollectionsfinal;

public class YouTubeConfig {
    public YouTubeConfig(){}
    private static final String API_KEY="AIzaSyC3ZBX0LQNLd8DNcAPk_lFS9NCJ5fxOa4k";

    public static String getApiKey() {
        return API_KEY;
    }
}
