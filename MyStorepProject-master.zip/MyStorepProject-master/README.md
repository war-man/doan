# MyStorepProject
Hướng dẫn xây dựng ứng dụng quản lý bán hàng trên ứng dụng android sử dụng công nghệ firebase.
Project dành cho các bạn bắt đầu tìm học sử dụng firebase, mà muốn xây dựng một ứng dụng với các chức năng hoàn chỉnh.

--------------
Tham khảo các bài viết khác tại:https://androidcoban.com
