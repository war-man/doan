package com.androidcoban.mystore.listener;

/**
 * Created by LynkMieu on 4/9/2017.
 */

public interface RegisterListener {
    void registerSuccess();
    void registerFailure(String message);
}
