package com.androidcoban.mystore.listener;

/**
 * Created by LynkMieu on 4/9/2017.
 */

public interface LoginListener {
    void loginSuccess();
    void loginFailure(String message);
}
