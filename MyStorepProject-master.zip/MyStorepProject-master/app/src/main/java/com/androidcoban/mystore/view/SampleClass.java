package com.androidcoban.mystore.view;

/**
 * Created by LynkMieu on 4/5/2017.
 */

public class SampleClass {
}
