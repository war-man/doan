package com.example.myapplication.ui.main.Adapter;

public class Hinh {
    String hinh;

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }

    public Hinh(String hinh) {
        this.hinh = hinh;
    }
}
