package com.example.myapplication.ui.main.Adapter.RecyclerViewAdapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.ui.main.Activity.timkiem_name;
import com.example.myapplication.ui.main.Adapter.Hinh;

import java.util.List;

public class Top100Adapter extends RecyclerView.Adapter<Top100Adapter.ViewHolder> {

    Context context;
    List<Hinh> mData;

    public Top100Adapter(Context context, List<Hinh> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(context).inflate(R.layout.item_theloai,parent,false);

        final ViewHolder viewHolder= new ViewHolder(v);

        viewHolder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(context,mData.get(viewHolder.getAdapterPosition()).getHinh(), Toast.LENGTH_SHORT).show();
                context = view.getContext();
                Intent intent = new Intent(context, timkiem_name.class);
                intent.putExtra("btn_name", mData.get(viewHolder.getAdapterPosition()).getHinh());
                context.startActivity(intent);

            }
        });
        return viewHolder;
    }

//    private void passData(int id) {
//
//        Intent intent = new Intent(context,timkiem_name.class);
//        intent.putExtra(btn_name, ""+id);
//        context.startActivity(intent);
//    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.btn.setText(mData.get(position).getHinh());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private final ImageView top100;
        Button btn ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            top100 = itemView.findViewById(R.id.image_top100);
        }
    }

}
