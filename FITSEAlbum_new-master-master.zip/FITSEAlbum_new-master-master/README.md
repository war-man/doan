# FITSEAlbum_new
Album app from FIT (Software Engineering) - HCMUS.

Splash screen:

![alt text](https://github.com/quangthach59/FITSEAlbum_new/blob/master/SplashScreen_demo.png)


App drawer:

![alt text](https://github.com/quangthach59/FITSEAlbum_new/blob/master/AppDrawer_demo.png)


Full image view:

![alt text](https://github.com/quangthach59/FITSEAlbum_new/blob/master/Full%20Image%20View_demo.png)


Menu options:

![alt text](https://github.com/quangthach59/FITSEAlbum_new/blob/master/Menu%20Options_demo.png)


Image details:

![alt text](https://github.com/quangthach59/FITSEAlbum_new/blob/master/Details_demo.png)
