package hcmus.mdsd.fitsealbum;

public class CloudUsers {
    public String NameCloud;
    public  String PassCloud;

    public CloudUsers(){

    }

    public CloudUsers(String nameCloud, String passCloud) {
        NameCloud = nameCloud;
        PassCloud = passCloud;
    }


}