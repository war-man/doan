package hcmus.mdsd.fitsealbum;

public class UserEmail {
    public static final String EMAIL ="fitsealbum.user@gmail.com";
    public static final String PASSWORD ="nguyenkhuongtruc2102";
}