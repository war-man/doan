# SecretReadMessage_TranThiKhanhLinh
phần mềm đọc trộm tin nhắn Android
![alt tag](https://cloud.githubusercontent.com/assets/12017473/15271928/08acc630-1a93-11e6-8819-8a84dea63988.png)

