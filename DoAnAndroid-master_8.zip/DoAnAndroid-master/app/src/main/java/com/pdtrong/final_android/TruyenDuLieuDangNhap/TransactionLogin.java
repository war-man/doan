package com.pdtrong.final_android.TruyenDuLieuDangNhap;

public interface TransactionLogin {
    void duLieuDangNhap(String usernameLogin, String passwordLogin);
}
