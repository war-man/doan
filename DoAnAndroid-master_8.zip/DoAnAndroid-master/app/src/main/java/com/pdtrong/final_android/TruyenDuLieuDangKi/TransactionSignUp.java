package com.pdtrong.final_android.TruyenDuLieuDangKi;

import com.pdtrong.final_android.UserDatabase.UserInfo;

public interface TransactionSignUp {
    void duLieuDangKi(UserInfo userInfoSignUp);
}
