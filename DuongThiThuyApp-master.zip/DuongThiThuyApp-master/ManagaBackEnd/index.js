var express = require('express');
var mysql 	= require('mysql');
var bodyParser = require('body-parser');
var con = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'testmanga'
});

var app = express();
var publicDir = (__dirname+'/public/');
app.use(express.static(publicDir));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.get("/banner",(req,res,next)=>{
	con.query('SELECT * FROM banner',function(error,result,fields){
		con.on('error',function(err){
			console.log('[MY SQL ERROR]',err);
		});

		if (result && result.length) {
			res.end(JSON.stringify(result));
		}else{
			res.end(JSON.stringify("No cimic here"));
		}
	})
});

app.get("/chapter/:mangaid",(req,res,next)=>{
	con.query('SELECT * FROM chapter WHERE MangaID=?',[req.params.mangaid],function(error,result,fields){
		con.on('error',function(err){
			console.log('[MY SQL ERROR]',err);
		});

		if (result && result.length) {
			res.end(JSON.stringify(result));
		}else{
			res.end(JSON.stringify("No cimic here"));
		}
	})
});

app.get("/links/:chapterid",(req,res,next)=>{
	con.query('SELECT * FROM link WHERE ChapterId=?',[req.params.chapterid],function(error,result,fields){
		con.on('error',function(err){
			console.log('[MY SQL ERROR]',err);
		});

		if (result && result.length) {
			res.end(JSON.stringify(result));
		}else{
			res.end(JSON.stringify("No cimic here"));
		}
	})
});


app.get("/comic",(req,res,next)=>{
	con.query('SELECT * FROM manga',function(error,result,fields){
		con.on('error',function(err){
			console.log('[MY SQL ERROR]',err);
		});

		if (result && result.length) {
			res.end(JSON.stringify(result));
		}else{
			res.end(JSON.stringify("No cimic here"));
		}
	})
});


app.listen(3000,()=>{
	console.log('Dang connect post 3000');
})