# DuongThiThuyApp
# Bài tập lớn môn android
#### Màn hình chờ
<img src="https://i.imgur.com/SWjwWV2.png">

#### Giao diện chính
<img src="https://i.imgur.com/Oc97Ga3.png">

#### Giao diện khi chọn truyện 
<img src="https://i.imgur.com/QSCgady.png">

#### Giao diện khi chọn chapter truyện để đọc
<img src="https://i.imgur.com/KFMMdl9.png">
