-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2019 at 03:37 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banhang`
--
CREATE DATABASE IF NOT EXISTS `banhang` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `banhang`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loaihang`
--

CREATE TABLE `tbl_loaihang` (
  `id_loai` int(11) NOT NULL,
  `ten_loaihang` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_loaihang`
--

INSERT INTO `tbl_loaihang` (`id_loai`, `ten_loaihang`) VALUES
(1, 'bánh'),
(2, 'kẹo'),
(3, 'Sach');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sanpham`
--

CREATE TABLE `tbl_sanpham` (
  `id_sp` int(11) NOT NULL,
  `tensanpham` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gia` float NOT NULL,
  `luotview` int(11) NOT NULL,
  `id_loai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_sanpham`
--

INSERT INTO `tbl_sanpham` (`id_sp`, `tensanpham`, `hinhanh`, `gia`, `luotview`, `id_loai`) VALUES
(3, 'sách gk', '1.png', 12000, 10, 3),
(4, 'bánh chôcpie', '1.png', 12000, 9, 1),
(9, 'thjuy', '2.png', 7777, 0, 2),
(10, 'keo lac', '3.png', 100200, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `level`) VALUES
(1, 'admin', '123', 1),
(2, 'user', '123', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_loaihang`
--
ALTER TABLE `tbl_loaihang`
  ADD PRIMARY KEY (`id_loai`);

--
-- Indexes for table `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  ADD PRIMARY KEY (`id_sp`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_loaihang`
--
ALTER TABLE `tbl_loaihang`
  MODIFY `id_loai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  MODIFY `id_sp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `bestmvc`
--
CREATE DATABASE IF NOT EXISTS `bestmvc` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bestmvc`;

-- --------------------------------------------------------

--
-- Table structure for table `loaisp`
--

CREATE TABLE `loaisp` (
  `id` int(11) NOT NULL,
  `ten_loai` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaisp`
--

INSERT INTO `loaisp` (`id`, `ten_loai`) VALUES
(1, 'kẹo'),
(2, 'bánh');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `anh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_loaisp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `ten`, `gia`, `anh`, `id_loaisp`) VALUES
(1, 'keo mut', '22000', '1.jpg', 1),
(2, 'keo mut', '22000', '1.png', 1),
(3, 'keo mut', '22000', '2.png', 2),
(4, 'keo mut', '22000', '3.png', 2),
(5, 'aaa', '333', '1.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loaisp`
--
ALTER TABLE `loaisp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `loaisp`
--
ALTER TABLE `loaisp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Database: `csdl_k14b`
--
CREATE DATABASE IF NOT EXISTS `csdl_k14b` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `csdl_k14b`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id_category` int(11) NOT NULL,
  `name_category` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `name_category`) VALUES
(1, 'hoa hong'),
(2, 'hoa mai'),
(3, 'ho hao'),
(4, 'akjdhashd');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id_product` int(11) NOT NULL,
  `name_product` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(20) DEFAULT NULL,
  `img` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `sale` int(11) DEFAULT NULL,
  `id_category` int(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id_product`, `name_product`, `price`, `img`, `des`, `date`, `sale`, `id_category`) VALUES
(2, 'qqqqq', 1111000, 'img/anh3.png', 'ddd', '2018-08-29', 3, 1),
(3, 'thiyuuya', 44, 'img/anh1.png', NULL, '2018-09-04', NULL, 2),
(4, 'trong', 20000, 'img/anh3.png', NULL, '2018-09-12', 30, 3),
(5, 'sang', 33333, 'img/anh1.png', NULL, '2018-09-04', 444, 1),
(6, 'truyen', 1000000, 'img/anh0.jpg', '', '2018-09-09', 33, 3),
(7, 'a', 111, 'img/anh1.png', 'a', '2018-10-26', 2, 0),
(8, 'a', 4444, '', 'rr', '2018-10-26', 5, 1),
(9, 'thuy', 1111, '', 'â', '2018-11-18', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `level`) VALUES
(1, 'thuyduong', '11111111', 2),
(2, 'duong', '222', 2),
(3, 'admin', 'admin', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Database: `csdl_test`
--
CREATE DATABASE IF NOT EXISTS `csdl_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `csdl_test`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `genderdich` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Database: `db`
--
CREATE DATABASE IF NOT EXISTS `db` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `db`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` varchar(30) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `category`) VALUES
('1', 'men'),
('2', 'women'),
('3', 'kids');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`name`, `pass`) VALUES
('admin', 'priya123');

-- --------------------------------------------------------

--
-- Table structure for table `fdbk`
--

CREATE TABLE `fdbk` (
  `name` varchar(30) NOT NULL,
  `phone no` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subj` varchar(30) NOT NULL,
  `mesg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fdbk`
--

INSERT INTO `fdbk` (`name`, `phone no`, `email`, `subj`, `mesg`) VALUES
('priya', '33333333333', 'priya@gmail.com', 'service', 'try to improve ur service'),
('priya', '33333333333', 'priya@gmail.com', 'service', 'try to improve ur service'),
('priya', '33333333333', 'priya@gmail.com', 'service', 'try to improve ur service');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `catg` varchar(40) NOT NULL,
  `subcatg` varchar(40) NOT NULL,
  `img` varchar(30) NOT NULL,
  `itemno` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `desc` varchar(300) NOT NULL,
  `info` varchar(500) NOT NULL,
  `dat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`catg`, `subcatg`, `img`, `itemno`, `price`, `desc`, `info`, `dat`) VALUES
('2', 'Dresses', 'c:/wamp/tmpphp1EC.tmp', 'd4', '1899', 'Semi Formal Dress', 'Fabric Detailing Cap Sleeves Open Bust Button', '05-07-11 04-45-09'),
('2', 'Dresses', 'c:/wamp/tmpphp1EE.tmp', 'd2', '1699', 'Casual Dress', 'Viscose Blend Fabric Smoked Back Smart Shift Dress Sleeveless Linen Shift Dress', '05-07-11 04-48-38'),
('2', 'Dresses', 'c:/wamp/tmpphp1EF.tmp', 'd6', '1799', 'Formal dress', 'Pin Striped Incut Dress Polyester Fabric Sleeveless  ', '05-07-11 04-50-17'),
('2', 'Dresses', 'c:/wamp/tmpphp1F0.tmp', 'd7', '1649', 'Formal Dress', 'Buttoned Down Front Linen Fabric Sleeveless', '05-07-11 04-51-14'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp20F.tmp', 'cs2', '1999', 'United Colors of Benetton Mens Full Sleeves Checks Shirt', '100% Cotton Full Sleeves Smart Checks Earthy Foliage Combination', '05-07-11 05-29-05'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp210.tmp', 'cs3', '1999', 'United Colors of Benetton Mens Full Sleeves Checks Shirt', '100% Cotton Full Sleeves Stripe Shirt Light Weight Fabric', '05-07-11 05-29-41'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp211.tmp', 'cs4', '1999', 'United Colors of Benetton Mens Full Sleeves Checks Shirt\r\n', '', '05-07-11 05-30-36'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp212.tmp', 'cs5', '1499', 'Allen Solly Mens Full Sleeves Checks Sport Shirt', 'Bias Yoke Patch Pockets Slim Fit Half Sleeves', '05-07-11 05-31-47'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp213.tmp', 'cs6', '1999', 'Levis Mens Roll Up Sleeves Workers Shirt', 'Light Age Theme 100% Cotton Full Sleeves Checks Shirt White Base', '05-07-11 05-32-26'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp98C5.tmp', 'cs7', '1599', 'Mustang Mens Long Sleeves Mini Checks Shirt', 'Summer Colors Theme 100% Cotton Full Sleeves Bias Detailing at Side Seam', '05-07-11 01-02-23'),
('2', 'Churidar Suits', 'c:/wamp/tmpphp980C.tmp', 's5', '1699', 'BIBA Churidar - Kurta-Dupatta Set', 'Printed kurta Round neck Full sleeves Kurta length -40 inches Contrast churidar and shaded crushed Duppatta', '05-07-11 05-02-05'),
('2', 'Churidar Suits', 'c:/wamp/tmpphp6588.tmp', 's1', '2599', 'Kashish Churidar - Kurta-Dupatta Set', 'Floral print Embelished Yoke Puff sleeves Kurta length -40 inches Contrast churidar and Duppatta', '05-07-11 05-05-09'),
('2', 'Churidar Suits', 'c:/wamp/tmpphp1BFC.tmp', 's3', '2899', 'Kashish Churidar - Kurta-Dupatta Set', 'Textured Fabric V-neck 3/4th sleeves Kurta length -40 inches Contrast churidar and Duppatta', '05-07-11 05-05-56'),
('2', 'Churidar Suits', 'c:/wamp/tmpphpFE60.tmp', 's6', '2799', 'Seven East Churidar - Kurta-Dupatta Set', 'Textured Fabric Embelished Yoke Sleeveless Kurta length -38 inches Contrast churidar and Duppatta', '05-07-11 05-06-54'),
('2', 'Churidar Suits', 'c:/wamp/tmpphp877D.tmp', 's4', '2799', 'Kashish Churidar - Kurta-Dupatta Set', 'Printed kurta Round neck Half sleeves Kurta length -38 inches Contrast churidar and Printed Duppatta', '05-07-11 05-07-29'),
('2', 'Churidar Suits', 'c:/wamp/tmpphp5B2.tmp', 's2', '2299', 'BIBA Churidar - Kurta-Dupatta Set', 'Regular fit Round neck Full sleeves Kurta length -40 inches Contrast churidar and shaded crushed Duppatta   ', '05-07-11 05-08-01'),
('2', 'Sandals', 'c:/wamp/tmpphpEAAC.tmp', 'foot1', '1690', 'Tresmode Ladies Peep toes', '', '06-07-11 01-51-03'),
('2', 'Sandals', 'c:/wamp/tmpphp8EE7.tmp', 'foot2', '1690', 'Tresmode Ladies Pump Shoes', '', '06-07-11 01-51-45'),
('2', 'Sandals', 'c:/wamp/tmpphp2FD8.tmp', 'foot4', '4990', 'Tresmode Ladies Sandals', '', '06-07-11 01-52-27'),
('2', 'Sandals', 'c:/wamp/tmpphp1894.tmp', 'nf2', '1299', 'Haute Curry - Ladies Footwear\r\n', '', '06-07-11 01-56-43'),
('2', 'Sandals', 'c:/wamp/tmpphp9A9F.tmp', 'nf3', '1399', 'Lemon Pepper - Ladies Footwear\r\n', '', '06-07-11 01-57-16'),
('2', 'Sandals', 'c:/wamp/tmpphp52F7.tmp', 'nf1', '1499', 'Lemon Pepper - Ladies Footwear\r\n', '', '06-07-11 02-02-25'),
('2', 'Kurtas', 'c:/wamp/tmpphp8B17.tmp', 'k3', '1399', 'Haute curry Mix and Match Kurta', 'Tie up 5/8th sleeves Kurta Length - 38 inches Tribal printed 100% cotton  ', '06-07-11 02-03-45'),
('2', 'Kurtas', 'c:/wamp/tmpphp2AEF.tmp', 'k4', '1079', 'W Mix and match kurta\r\n', 'Sleeveless Regular Wear Regular Fit Length- 38 inches Fabric- Cotton Cambric', '06-07-11 02-05-32'),
('2', 'Kurtas', 'c:/wamp/tmpphp9095.tmp', 'k2', '1599', 'Kashish Mix and Match Kurta', '3/4th sleeves Kurta Length - 38 inches sequine highlighted printed 100% cotton', '06-07-11 02-05-58'),
('2', 'Kurtas', 'c:/wamp/tmpphp9299.tmp', 'k7', '799', 'W Mix and Match Kurta', 'V Neck Kurta Printed Short Sleeves Mauve printed non embellished Kurta Kurta length -38 inches 60 s Cambric', '06-07-11 02-07-04'),
('2', 'Kurtas', 'c:/wamp/tmpphp3713.tmp', 'k8', '1199', 'Stop Classic Mix and Match Short Kurta\r\n', 'Dobby kurta with embroidery on the yoke and sleeve Kurta length- 36 inches 3/4th sleeves Officewear', '06-07-11 02-08-51'),
('2', 'Kurtas', 'c:/wamp/tmpphpDC29.tmp', 'k9', '1299', 'Stop Classic Mix and Match Short Kurta\r\n', 'Printed Highlighted placket and sleeve hem 3/4th sleeves', '06-07-11 02-09-34'),
('2', 'Dresses', 'c:/wamp/tmpphp8332.tmp', 'd5', '1799', 'Life Ladies Rara Dress\r\n', '', '06-07-11 02-19-01'),
('2', 'Dresses', 'c:/wamp/tmpphp3FEC.tmp', 'd3', '1599', 'Mustang Ladies Mia Denim dress\r\n', '', '06-07-11 02-19-49'),
('2', 'Office Wear', 'c:/wamp/tmpphp8832.tmp', 'of2', '799', 'Austin Reed Office Wear T shirt', '', '07-07-11 10-23-12'),
('2', 'Office Wear', 'c:/wamp/tmpphp770.tmp', 'of1', '1999', 'Austin Reed Office Wear waist coat', '', '07-07-11 10-23-45'),
('2', 'Office Wear', 'c:/wamp/tmpphpDDD2.tmp', 'of5', '799', 'Austin Reed Office Wear Top', '', '07-07-11 10-24-40'),
('2', 'Office Wear', 'c:/wamp/tmpphpC9F6.tmp', 'of3', '899', 'Austin Reed Office Wear T shirt', '', '07-07-11 10-25-40'),
('2', 'Office Wear', 'c:/wamp/tmpphpAA95.tmp', 'of4', '1199', 'Austin Reed Office Wear T shirt', '', '07-07-11 10-26-38'),
('2', 'Office Wear', 'c:/wamp/tmpphp9AAE.tmp', 'of6', '699', 'SHOP Office wear collection', '', '07-07-11 10-27-39'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphpBCC0.tmp', 'j7', '20,865', 'Haute Curry Earring HCSE1012', '', '07-07-11 10-33-15'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphpE824.tmp', 'j3', '10,999', 'Lucera Rhodium plated Sterling Silver Diamond tops ', '', '07-07-11 10-34-32'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphp328D.tmp', 'j4', '20,345', 'Pretty Women Peacock theme Set ', '', '07-07-11 10-35-57'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphp2574.tmp', 'j2', '23,678', 'Pretty Women dangling Earrings ', '', '07-07-11 10-36-59'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphp97E6.tmp', 'j6', '22,780', 'DITI Flower theme Diamond Ring ', '', '07-07-11 10-38-34'),
('2', 'Artificial Jewellery', 'c:/wamp/tmpphp3A5.tmp', 'j5', '24,890', 'Pretty Women Modern theme set ', '', '07-07-11 10-51-02'),
('3', 'Baby Apparel', 'c:/wamp/tmpphpEFD8.tmp', 'bb1', '899', 'Girls Spot and Stripe Jersey Romper Dress', 'Floral print Sleeveless Round neck Along with belt Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 10-53-08'),
('3', 'Baby Apparel', 'c:/wamp/tmpphp67B6.tmp', 'bb2', '1,299', 'Girls Denim Pinny', 'Floral print denim dress Sleeveless Round neck Along with a belt Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 10-53-39'),
('3', 'Baby Apparel', 'c:/wamp/tmpphpDFC3.tmp', 'bb7', '1,299', 'Girls frill and pompy short Dress', 'Polka dot Strappy Square neck Double layered dress Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 10-55-15'),
('3', 'Baby Apparel', 'c:/wamp/tmpphp5BB.tmp', 'bb3', '1,799', 'Girls Layette Snowsuit', '', '07-07-11 10-56-30'),
('3', 'Baby Apparel', 'c:/wamp/tmpphp9722.tmp', 'bb5', '899', 'Unisex Duck Pyjamas', 'Round Neck Half Sleeves Stripes With Print Button Styling Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 10-57-08'),
('3', 'Baby Apparel', 'c:/wamp/tmpphpA621.tmp', 'bb4', '1,299', 'Boys Truck Bodysuits - 7pk', 'Round Neck Half Sleeves Stripes Button Styling Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 10-58-17'),
('3', 'Girls Apparel', 'c:/wamp/tmpphp6DB4.tmp', 'g1', '999', 'Gini and Jony girls dress (Infant)', ' Sleeveless Balloon dress Striped at the waist Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 11-06-47'),
('3', 'Girls Apparel', 'c:/wamp/tmpphpBC8.tmp', 'g2', '445', '612 Ivy League girls dress', ' Floral print, Strappy, Elasticised at the hem, Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 11-07-27'),
('3', 'Girls Apparel', 'c:/wamp/tmpphpF962.tmp', 'g6', '699', 'Girls floral dress', 'Floral print Strappy Elasticized body Frills at the hem Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 11-08-28'),
('3', 'Girls Apparel', 'c:/wamp/tmpphp95FF.tmp', 'g3', '499', 'Shop girls top', 'Stop girls top Product Details Floral print Halter Bow at the side Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 11-09-08'),
('3', 'Girls Apparel', 'c:/wamp/tmpphp2C94.tmp', 'g5', '549', 'Shop girls skirt', ' Floral print Halter neck V-neck Bow at the front Frills at the bottom Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 11-09-47'),
('3', 'Girls Apparel', 'c:/wamp/tmpphpA76F.tmp', 'g4', '549', 'Shop girls casual top', 'Polka dot Puff sleeves Collar Polka dot print belt Front pleat Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 11-10-18'),
('3', 'Boys Apparel', 'c:/wamp/tmpphp6557.tmp', 'b1', '499', 'United Colors of Benetton boys t-shirt', 'Half sleeves Printed message &#39;St.Kilda surfer&#39; Round neck Regular fit Prices of the items may be different from those displayed on the product details page, where the price varies by size.  ', '07-07-11 04-10-53'),
('3', 'Boys Apparel', 'c:/wamp/tmpphp1EB7.tmp', 'b2', '399', 'United Colors of Benetton boys t-shirt', 'Half sleeves Printed message &#39;Art village 2&#39; Round neck Regular fit Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 04-11-40'),
('3', 'Boys Apparel', 'c:/wamp/tmpphpBA0D.tmp', 'b4', '799', 'Gini and Jony boys T-shirt (Kids)', 'Printed tee Half sleeves Polo neck Printed baseball logo Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 04-12-20'),
('3', 'Boys Apparel', 'c:/wamp/tmpphp4D29.tmp', 'b3', '545', '612 Ivy League boys shirt', 'Checks shirt Half sleeve with turnup loop Along with a tee Printed tee and shirt Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 04-12-58'),
('3', 'Boys Apparel', 'c:/wamp/tmpphpE18C.tmp', 'b5', '745', '612 Ivy League boys T-shirt', 'Striped shirt Half sleeves Patch on the front Contrast collar and sleeve hem Prices of the items may be different from those displayed on the product details page, where the price varies by size.', '07-07-11 04-13-36'),
('3', 'Boys Apparel', 'c:/wamp/tmpphp86A2.tmp', 'b6', '879', 'Nike boys t-shirt', 'Solid color tee Sleeveless Round neck Printed logo \'64\' Prices of the items may be different from those displayed on the product details page, where the price varies by size', '07-07-11 04-14-18'),
('3', 'Kids Toys', 'c:/wamp/tmpphp109.tmp', 'e2', '525', 'Wild Republic Rascals Dolphin 20 inch soft toy', 'Simple Cute fluffy and adorable Non Toxic Quality Fabric Ultra Squishy Stuffing 20 inches Hand Crafted', '08-07-11 06-00-04'),
('3', 'Kids Toys', 'c:/wamp/tmpphp4C9D.tmp', 'e3', '2499', 'Little Mommy Play All Day', 'Doll', '09-07-11 06-58-08'),
('3', 'Kids Toys', 'c:/wamp/tmpphpBD3B.tmp', 'e4', '1649', 'Road Storage Mat R', 'A fantastic backdrop for road adventures and a practical storage case in one Race your toy cars on the playmat then fold the playmat into a storage box and place your favourite toys in it Water resistant wipe-clean surface Age Range: From 3 years Social skills-This toy helps your child learn how to make friends and enjoy company. Imagination-This toy encourages your child to enjoy using their imagination.', '09-07-11 06-58-37'),
('3', 'Kids Toys', 'c:/wamp/tmpphp3A19.tmp', 'e5', '549', 'Paper Straw Pets', 'Use your imagination to create your very own straw pets and a house for them too Age Range: From 3 years Creativity-This toy enables your child to express themselves artistically. Imagination-This toy encourages your child to enjoy using their imagination.', '09-07-11 06-59-09'),
('3', 'Kids Toys', 'c:/wamp/tmpphpAA1.tmp', 'e6', '1999', 'Disney Rapunzel hair braider', 'Manually operated Rapunzel doll', '09-07-11 07-00-02'),
('3', 'Kids Toys', 'c:/wamp/tmpphp8BC3.tmp', 'e1', '699', 'Paper Aquarium', 'Have wonderful adventures with these dazzling paper fish and funky fish tank. Age Range: From 3 years Imagination-This toy encourages your child to enjoy using their imagination. Creativity-This toy enables your child to express themselves artistically.', '09-07-11 07-00-35'),
('1', 'T-shirts', 'c:/wamp/tmpphpAC30.tmp', 'ts5', '1699.00 ', 'United Colors of Benetton Mens Half Sleeves Polo Striper T-Shirt', '', '09-07-11 07-06-11'),
('1', 'T-shirts', 'c:/wamp/tmpphp4870.tmp', 'ts4', '1099', 'United Colors of Benetton Mens Half Sleeves Polo T-Shirt1', '', '09-07-11 07-07-57'),
('1', 'T-shirts', 'c:/wamp/tmpphpBCF4.tmp', 'ts1', '1299', 'United Colors of Benetton Mens Half Sleeves Polo T-Shirt', '', '09-07-11 07-17-11'),
('1', 'T-shirts', 'c:/wamp/tmpphp71C3.tmp', 'ts3', '1099', 'Spykar Mens Half Sleeve Collar Neck Flat Knit T-Shirt', '', '09-07-11 07-17-57'),
('1', 'T-shirts', 'c:/wamp/tmpphpEC50.tmp', 'ts6', '749', 'Spykar Mens Half Sleeve Round Neck Printed T-Shirt', '', '09-07-11 07-18-29'),
('1', 'T-shirts', 'c:/wamp/tmpphp643E.tmp', 'ts2', '999', 'Mustang Mens Circular Knit Prinetd Short Sleeves T-Shirt', '', '09-07-11 07-18-59'),
('1', 'jeans', 'c:/wamp/tmpphp46B1.tmp', 'jeans1', '2399', 'Mustang Mens New Oregon Fit Denim', '', '09-07-11 07-19-57'),
('1', 'jeans', 'c:/wamp/tmpphp99A1.tmp', 'jeans4', '1699', 'Flying Machine Mens Regular Fit Bruce Denim', '', '09-07-11 07-22-30'),
('1', 'jeans', 'c:/wamp/tmpphp1D23.tmp', 'jeans5', '1999', 'United Colors of Benetton Mens Slim Fit Denim', '', '09-07-11 07-23-03'),
('1', 'jeans', 'c:/wamp/tmpphpE5A1.tmp', 'jeans2', '2199', 'Mustang Mens Michigan Fit Denim', '', '09-07-11 07-23-55'),
('1', 'jeans', 'c:/wamp/tmpphp74B7.tmp', 'jeans3', '1599', 'Flying Machine Mens Slim Fit Eddie Denim', '', '09-07-11 07-24-31'),
('1', 'jeans', 'c:/wamp/tmpphp4188.tmp', 'jeans6', '2599', 'Levis Mens 504 Fit Tapered Denim', '', '09-07-11 07-25-24'),
('1', 'Footwear', 'c:/wamp/tmpphpD61A.tmp', 'shoe1', '3999', 'Enroute Men\'s Footwear', '', '09-07-11 07-29-18'),
('1', 'Footwear', 'c:/wamp/tmpphp659D.tmp', 'shoe2', '4499', 'Enroute Men\'s Footwear', '', '09-07-11 07-29-55'),
('', '', '', '', '', '', '', '09-07-11 07-29-57'),
('1', 'Footwear', 'c:/wamp/tmpphp4515.tmp', 'shoe4', '3999', 'Enroute Men\'s Footwear', '', '09-07-11 07-30-52'),
('1', 'Footwear', 'c:/wamp/tmpphpF4A5.tmp', 'shoe3', '1676', 'Franco Leone - Men\'s Shoes', '', '09-07-11 07-31-37'),
('1', 'Footwear', 'c:/wamp/tmpphp6F9F.tmp', 'shoe5', '2195', 'Franco Leone - Men\'s Shoes', '', '09-07-11 07-32-09'),
('1', 'Footwear', 'c:/wamp/tmpphp2AB.tmp', 'shoe6', '1895', 'Franco Leone - Men\'s Shoes', '', '09-07-11 07-32-46'),
('1', 'watches', 'c:/wamp/tmpphpE3F6.tmp', 'w1', '3650', 'Polo Club Men\'s Watch', '', '09-07-11 07-37-01'),
('1', 'watches', 'c:/wamp/tmpphp862F.tmp', 'w3', '1750', 'Polo Club Men\'s Watch', '', '09-07-11 07-56-16'),
('1', 'watches', 'c:/wamp/tmpphp31E9.tmp', 'w4', '1750', 'Polo Club Men\'s Watch', '', '09-07-11 07-57-00'),
('1', 'watches', 'c:/wamp/tmpphpE447.tmp', 'w5', '1569', 'Polo Club Men\'s Watch', '', '09-07-11 07-57-46'),
('1', 'watches', 'c:/wamp/tmpphp5FCE.tmp', 'w6', '1999', 'Polo Club Men\'s Watch', '', '09-07-11 07-58-17'),
('1', 'watches', 'c:/wamp/tmpphp26C5.tmp', 'w2', '1349', 'Polo Club Men\'s Watch', '', '09-07-11 07-59-08'),
('1', 'Shorts', 'c:/wamp/tmpphp2F3F.tmp', 'sh1', '1799', 'Mustang Mens Casual Shorts', '', '09-07-11 08-02-27'),
('1', 'Shorts', 'c:/wamp/tmpphp82D.tmp', 'sh3', '1299', 'Killer Mens 8 Pocket Checks Shorts', '', '10-07-11 11-16-33'),
('1', 'Shorts', 'c:/wamp/tmpphp78FA.tmp', 'sh4', '1295', 'Wrangler Mens Spencer Denim Shorts', '', '10-07-11 11-17-02'),
('1', 'Shorts', 'c:/wamp/tmpphpE4E7.tmp', 'sh6', '1299', 'Killer Mens 8 Pocket Checks Shorts', '', '10-07-11 11-17-30'),
('1', 'Shorts', 'c:/wamp/tmpphp6EA0.tmp', 'sh5', '2195', 'Wrangler Mens Cargo Fit Checks Shorts', '', '10-07-11 11-18-05'),
('1', 'Shorts', 'c:/wamp/tmpphpD6B6.tmp', 'sh2', '1699', 'Indian Terrain Mens Regular Fit Cargo Shorts', '', '10-07-11 11-18-32');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `pname` varchar(30) NOT NULL,
  `itemno` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `size` varchar(30) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `ac_no` varchar(30) NOT NULL,
  `mob_no` varchar(30) NOT NULL,
  `add` varchar(300) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `order_no` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`pname`, `itemno`, `price`, `size`, `uname`, `ac_no`, `mob_no`, `add`, `bank`, `city`, `order_no`) VALUES
('Tresmode Ladies Pump Shoes', 'foot2', 'Rs1690', 'Medium', 'Priya Gupta', 'ac234', '987654987', 'Tilak Nagar,Shanti path', 'ICICI', 'Jaipur', 'ord228'),
('W Mix and match kurta ', 'k4', 'Rs1079', 'Medium', 'Priya Gupta', 'ac345', '36536356353', 'jaewahar Nagar', 'SBI', 'Delhi', 'ord326');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `title` varchar(6) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `gen` varchar(30) NOT NULL,
  `id` varchar(50) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `add` varchar(300) NOT NULL,
  `city` varchar(30) NOT NULL,
  `coun` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`title`, `fname`, `lname`, `gen`, `id`, `pass`, `phone`, `add`, `city`, `coun`, `dob`) VALUES
('Mr.', 'Ankur', 'gupta', 'male', 'ankur@gmail.com', 'ankur123', '9414279845', 'Shanti Path Tilak Nagar', 'Jaipur', 'India', '13-11-89'),
('Ms.', 'Priya', 'gupta', 'female', 'priya@gmail.com', 'priya123', '9460380893', 'Patrakar Colany Jawahar Nagar', 'Delhi', 'India', '30-03-91');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `cat_id` varchar(30) NOT NULL,
  `subcategory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`cat_id`, `subcategory`) VALUES
('1', 'Casual Shirts'),
('1', 'jeans'),
('1', 'T-shirts'),
('1', 'Footwear'),
('1', 'Shorts'),
('1', 'watches'),
('2', 'Dresses'),
('2', 'Churidar Suits'),
('2', 'Kurtas'),
('2', 'Sandals'),
('2', 'Office Wear'),
('2', 'Artificial Jewellery'),
('3', 'Baby Apparel'),
('3', 'Girls Apparel'),
('3', 'Boys Apparel'),
('3', 'Kids Toys');

-- --------------------------------------------------------

--
-- Table structure for table `trash`
--

CREATE TABLE `trash` (
  `catg` varchar(50) NOT NULL,
  `subcatg` varchar(50) NOT NULL,
  `img` varchar(60) NOT NULL,
  `itemno` varchar(30) NOT NULL,
  `price` int(30) NOT NULL,
  `desc` varchar(300) NOT NULL,
  `dat` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trash`
--

INSERT INTO `trash` (`catg`, `subcatg`, `img`, `itemno`, `price`, `desc`, `dat`) VALUES
('men', 'Casual Shirts', 'd:/wamp/tmpphp13A.tmp', 'cs1', 400, 'ahakaaajaj', '28-06-11 04-56-14'),
('', '', '', '', 0, '', '28-06-11 04-56-18'),
('men', 'Casual Shirts', 'd:/wamp/tmpphp15A.tmp', 'cs3', 500, 'haioaajalkaj', '28-06-11 04-57-11'),
('', '', '', '', 0, '', '28-06-11 04-57-18'),
('', '', '', '', 0, '', '28-06-11 04-57-51'),
('women', 'Dresses', 'c:/wamp/tmpphp15F.tmp', 'd1', 5700, 'ghsfshsshs', '28-06-11 05-00-46'),
('women', 'Dresses', 'c:/wamp/tmpphp160.tmp', 'd2', 45666, 'yrsysfysus', '28-06-11 05-00-46'),
('', '', '', '', 0, '', '28-06-11 05-00-50'),
('', '', '', '', 0, '', '28-06-11 05-00-50'),
('', '', '', '', 0, '', '28-06-11 05-02-08'),
('', '', '', '', 0, '', '28-06-11 05-02-08'),
('', '', '', '', 0, '', '28-06-11 05-03-25'),
('', '', '', '', 0, '', '28-06-11 05-03-25'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp166.tmp', 'cs1', 7635635, 'qtyqwtywrtyw', '28-06-11 05-06-40'),
('', '', '', '', 0, '', '28-06-11 05-07-04'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp168.tmp', 'cs2', 53674, 'deuyddydtg', '28-06-11 05-11-33'),
('', '', '', '', 0, '', '28-06-11 05-11-36'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp137.tmp', 'cs1', 355, 'sjksjs', '29-06-11 04-34-39'),
('', '', '', '', 0, '', '29-06-11 04-34-43'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp139.tmp', '33', 444, 'sxxddxd', '29-06-11 04-35-16'),
('', '', '', '', 0, '', '29-06-11 04-35-21'),
('', '', '', '', 0, '', '29-06-11 04-35-25'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp138.tmp', 'cs2', 3434, 'hdgdjgdjg', '29-06-11 04-35-30'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp13B.tmp', '34', 0, 'ddddd', '29-06-11 04-42-31'),
('', '', '', '', 0, '', '29-06-11 04-42-34'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp13C.tmp', '45', 0, 'xxxxxx', '29-06-11 04-43-02'),
('men', 'Casual Shirts', 'c:/wamp/tmpphp13D.tmp', 'cs1', 345, 'sssssssssssss', '29-06-11 04-43-02'),
('', '', '', '', 0, '', '29-06-11 04-43-08'),
('', '', '', '', 0, '', '29-06-11 04-43-08'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp177.tmp', '23', 2333, 'wwwwwwwwwwwwww', '30-06-11 04-56-19'),
('', '', '', '', 0, '', '30-06-11 04-56-21'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp176.tmp', 'cs1', 23, 'aaaaaaaaaaaaa', '30-06-11 04-56-52'),
('1', 'Casual Shirts', 'c:/wamp/tmpphp178.tmp', '34', 0, 'wwwwwwwwwwwwww', '30-06-11 04-56-52'),
('', '', '', '', 0, '', '30-06-11 04-56-58'),
('', '', '', '', 0, '', '30-06-11 04-56-58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);
--
-- Database: `dltest`
--
CREATE DATABASE IF NOT EXISTS `dltest` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `dltest`;
--
-- Database: `dsbtl`
--
CREATE DATABASE IF NOT EXISTS `dsbtl` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `dsbtl`;

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tacgia` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hinhanh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

--
-- Dumping data for table `pma__designer_settings`
--

INSERT INTO `pma__designer_settings` (`username`, `settings_data`) VALUES
('root', '{\"snap_to_grid\":\"off\",\"angular_direct\":\"direct\",\"relation_lines\":\"true\",\"small_big_all\":\">\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

--
-- Dumping data for table `pma__navigationhiding`
--

INSERT INTO `pma__navigationhiding` (`username`, `item_name`, `item_type`, `db_name`, `table_name`) VALUES
('root', 'product', 'table', 'test', '');

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"testmanga\",\"table\":\"chapter\"},{\"db\":\"testmanga\",\"table\":\"manga\"},{\"db\":\"testmanga\",\"table\":\"banner\"},{\"db\":\"testmanga\",\"table\":\"mangacategory\"},{\"db\":\"testmanga\",\"table\":\"link\"},{\"db\":\"testmanga\",\"table\":\"category\"},{\"db\":\"dsbtl\",\"table\":\"sanpham\"},{\"db\":\"ttcn_ngodanghieu\",\"table\":\"tbl_user\"},{\"db\":\"ttcn_ngodanghieu\",\"table\":\"tbl_monan\"},{\"db\":\"ttcn_ngodanghieu\",\"table\":\"tbl_sp\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'bestmvc', 'sanpham', '{\"sorted_col\":\"`sanpham`.`anh`  ASC\"}', '2018-12-04 03:10:22');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-04-08 01:36:50', '{\"Console\\/Mode\":\"collapse\",\"lang\":\"en_GB\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `project_qlbh`
--
CREATE DATABASE IF NOT EXISTS `project_qlbh` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `project_qlbh`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loai`
--

CREATE TABLE `tbl_loai` (
  `id_loai` int(11) NOT NULL,
  `tenloaihang` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sanpham`
--

CREATE TABLE `tbl_sanpham` (
  `id_sp` int(11) NOT NULL,
  `tensanpham` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `giatien` float NOT NULL,
  `soluong` int(10) NOT NULL,
  `luotview` int(10) NOT NULL,
  `id_loai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_loai`
--
ALTER TABLE `tbl_loai`
  ADD PRIMARY KEY (`id_loai`);

--
-- Indexes for table `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  ADD PRIMARY KEY (`id_sp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_loai`
--
ALTER TABLE `tbl_loai`
  MODIFY `id_loai` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sanpham`
--
ALTER TABLE `tbl_sanpham`
  MODIFY `id_sp` int(11) NOT NULL AUTO_INCREMENT;
--
-- Database: `project_qlmh`
--
CREATE DATABASE IF NOT EXISTS `project_qlmh` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `project_qlmh`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_giangvien`
--

CREATE TABLE `tbl_giangvien` (
  `ma_gv` int(11) NOT NULL,
  `ten_gv` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_giangvien`
--

INSERT INTO `tbl_giangvien` (`ma_gv`, `ten_gv`) VALUES
(1, 'thuy'),
(2, 'duong');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_monhoc`
--

CREATE TABLE `tbl_monhoc` (
  `ma_mh` int(11) NOT NULL,
  `ten_mh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `so_tc` int(11) NOT NULL,
  `ma_gv` int(11) NOT NULL,
  `ky_hoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_monhoc`
--

INSERT INTO `tbl_monhoc` (`ma_mh`, `ten_mh`, `so_tc`, `ma_gv`, `ky_hoc`) VALUES
(1, 'toan', 2, 1, '1'),
(2, 'ly', 2, 2, '2'),
(3, 'sinh', 3, 1, '3'),
(4, 'hoa', 4, 2, '4');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` int(11) NOT NULL,
  `level` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `level`) VALUES
(1, 'thuy', 111, 0),
(2, 'admin', 111, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_giangvien`
--
ALTER TABLE `tbl_giangvien`
  ADD PRIMARY KEY (`ma_gv`);

--
-- Indexes for table `tbl_monhoc`
--
ALTER TABLE `tbl_monhoc`
  ADD PRIMARY KEY (`ma_mh`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_giangvien`
--
ALTER TABLE `tbl_giangvien`
  MODIFY `ma_gv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_monhoc`
--
ALTER TABLE `tbl_monhoc`
  MODIFY `ma_mh` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `testmanga`
--
CREATE DATABASE IF NOT EXISTS `testmanga` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `testmanga`;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `ID` int(11) NOT NULL,
  `Link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`ID`, `Link`) VALUES
(1, 'http://192.168.43.25/AppTruyen/image/nen.jpg'),
(2, 'http://192.168.43.25/AppTruyen/image/WEL.jpg'),
(3, 'http://192.168.43.25/AppTruyen/image/welcom.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `Name`) VALUES
(1, 'Comedy'),
(2, 'Ecchi'),
(3, 'Historical'),
(4, 'Manhwa'),
(5, 'Medical'),
(6, 'Romance'),
(7, 'Shoujo'),
(8, 'Slice of life'),
(9, 'Tragedy'),
(10, 'Cooking'),
(11, 'Action'),
(12, 'Fantasy'),
(13, 'Horror'),
(14, 'Martial arts'),
(15, 'Mystery'),
(16, 'School life'),
(17, 'Shoujo a'),
(18, 'Smut'),
(19, 'Webtoons'),
(20, 'Adult'),
(21, 'Doujinshi'),
(22, 'Gender bender'),
(23, 'Jose'),
(24, 'Mature'),
(25, 'One shot'),
(26, 'Sci fi'),
(27, 'Shounen'),
(28, 'Sports'),
(29, 'Yaoi'),
(30, 'Adventure'),
(31, 'Drama'),
(32, 'Harem'),
(33, 'Manhua'),
(34, 'Mecha'),
(35, 'Psychological'),
(36, 'Seinen'),
(37, 'Shounen ai'),
(38, 'Supernatural'),
(39, 'Yuri'),
(40, 'Top Read'),
(41, 'Completed'),
(42, 'Newest'),
(43, 'Ongoing'),
(44, 'Latest'),
(45, 'Drop'),
(46, 'Superhero');

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `MangaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapter`
--

INSERT INTO `chapter` (`ID`, `Name`, `MangaID`) VALUES
(3, 'Chapter 1 : Bloomers and the Monkey King', 1),
(4, 'Chapter 2 : No Balls!!', 1),
(7, 'Chapter 3 : Sea Monkeys', 1),
(8, 'Chapter 4 : They Call Him the Turtle Hermit!', 1),
(9, 'Chapter 5 : Oo! Oo! Oolong!', 1),
(10, 'Chapter 6 : So Longm OoLong!!', 1),
(11, 'Chapter 7 :Yamcha and Pu\'ar', 1),
(12, 'Chapter 8 : One, Two,Yamcha-cha', 1),
(13, 'Vol.1 Chapter 1 : All The Way From A Future World', 3),
(14, 'Vol 0 chapter 1.1', 3),
(15, 'Vol.1 chapter 2 : Prophecy Of Doraemon', 3),
(16, 'Vol.1 chapter 3 : Transforming Biscuit', 3),
(17, 'Vol.1 chapter 4 : Operation: Secret Spy', 3),
(18, 'Vol.1 chapter 5 : Kobe Abe', 3),
(19, 'Vol.1 chapter 6 : Antique Competition', 3),
(20, 'Vol.1 chapter 7 : Peko Peko Grasshopper', 3),
(23, 'Vol.1 chapter 8 : Chin Up To The Ancestors', 3),
(24, 'Vol.1 chapter 9 : Hunting Shades', 3),
(27, 'Vol.1 chapter 10 : Flattering Lipsticks', 3),
(28, 'Vol.1 chapter 11 : Full Points For Once In A Life Time', 3),
(29, 'Doraemon vol.1 chapter 12 : Operation: Propose', 3),
(30, 'Vol.1 chapter 13 : OO Will ^ ^ With XX', 3),
(31, 'Vol.1 chapter 14 : Hot Hot In The Snow', 3),
(32, 'Vol.1 chapter 15 : A Ghost Of The Lamp\'s Smoke', 3),
(35, 'Doraemon vol.1 chapter 16 : Run! Uma-Take', 3),
(36, 'Vol.2 chapter 17 : Test Memorizing Toast', 3);

-- --------------------------------------------------------

--
-- Table structure for table `link`
--

CREATE TABLE `link` (
  `ID` int(11) NOT NULL,
  `Link` text NOT NULL,
  `ChapterID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `link`
--

INSERT INTO `link` (`ID`, `Link`, `ChapterID`) VALUES
(1, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/2.jpg', 13),
(2, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/3.jpg', 13),
(3, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/4.jpg', 13),
(4, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/5.jpg', 13),
(5, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/6.jpg', 13),
(6, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/7.jpg', 13),
(7, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/8.jpg', 13),
(8, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/9.jpg', 13),
(9, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/10.jpg', 13),
(10, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/11.jpg', 13),
(11, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/12.jpg', 13),
(12, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/13.jpg', 13),
(13, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/14.jpg', 13),
(14, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/15.jpg', 13),
(15, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/14.jpg', 13),
(16, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/17.jpg', 13),
(17, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/18.jpg', 13),
(18, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/19.jpg', 13),
(19, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol1_chapter_1_all_the_way_from_a_future_world/20.jpg', 13),
(21, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol0_chapter_11/2.jpg', 14),
(22, 'https://s8.mkklcdnv8.com/mangakakalot/d2/doraemon/vol0_chapter_11/3.jpg', 14);

-- --------------------------------------------------------

--
-- Table structure for table `manga`
--

CREATE TABLE `manga` (
  `ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manga`
--

INSERT INTO `manga` (`ID`, `Name`, `Image`) VALUES
(1, 'Dragon Ball', 'https://avt.mkklcdnv3.com/avatar_225/3326-read_dragon_ball_manga_online_for_free2.jpg'),
(2, 'The Amazing Spider-Man (1963)', 'https://2.bp.blogspot.com/UyIClw5KWvyrIHioRjGeqaX3BdNRLF0jdlZTHesIxLZy6zX9zOwY26UrF6w5j_v5rGakyQxdPfoi=s1600'),
(3, 'Doraemon', 'https://avt.mkklcdnv3.com/avatar_225/1279-doraemon.jpg'),
(4, 'Spider-Man', 'https://avt.mkklcdnv3.com/avatar_225/11297-spiderman.jpg'),
(5, 'The Invincible Iron Man', 'https://cdn.shopify.com/s/files/1/0882/5118/products/Invincible-Iron-Man-Number-1-2137789_1024x1024.jpeg?v=1442250415'),
(6, 'Ant-Man & The Wasp', 'https://i.pinimg.com/originals/66/41/b1/6641b10b731f0140a90c5a7fa641daf9.jpg'),
(7, 'Marvel Zombies', 'http://1.bp.blogspot.com/-vNUqD-HUcdQ/Vp5GXqrP7fI/AAAAAAAAIEE/OSIFYvS3D7k/s1600/0.jpg'),
(8, 'Super Hero Adventures', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKWBY9fuCKhnDI-wwoXwJ6zF1O6x9ELBaE7Y4YwAK1LahojieB'),
(9, 'Cable', 'https://images-na.ssl-images-amazon.com/images/S/cmx-images-prod/Item/494347/494347._SX1280_QL80_TTD_.jpg'),
(10, 'X-Force', 'https://ss-images.catscdn.vn/2018/05/31/2921811/x-men_92_vol_1_3_textless.jpg'),
(11, 'Avengers', 'https://www.librairiezbookstore.com/40046-large_default/marvel-comics-digest-7-ant-man.jpg'),
(12, 'Thor', 'https://i1.wp.com/graphicpolicy.com/wp-content/uploads/2017/10/MarvelComicsDigest_03-1.jpg?resize=736%2C991&ssl=1'),
(13, 'X-men Wolverine', 'https://darksidecomics.s3.us-east-2.amazonaws.com/previews/AUG181583.jpg?lastmod=1533154926'),
(14, 'DC Essential Graphic Novels 2016', 'https://images-na.ssl-images-amazon.com/images/S/cmx-images-prod/Item/332255/332255._SX1280_QL80_TTD_.jpg'),
(15, 'Aqua Man', 'https://d1466nnw0ex81e.cloudfront.net/n_iv/600/3723215.jpg'),
(16, 'Variant Covers', 'https://insightcomics.com/wp-content/uploads/2018/09/76348-64734-cover.jpg'),
(17, 'Batman', 'http://4.bp.blogspot.com/-UVWO6oyjJqU/U_3jLJzL3MI/AAAAAAAEnhQ/_SyLqkLRvVo/s1600/-000.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mangacategory`
--

CREATE TABLE `mangacategory` (
  `MangaID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mangacategory`
--

INSERT INTO `mangacategory` (`MangaID`, `CategoryID`) VALUES
(1, 11),
(1, 30),
(2, 11),
(2, 30),
(2, 46),
(3, 1),
(3, 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `MangaID` (`MangaID`);

--
-- Indexes for table `link`
--
ALTER TABLE `link`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ChapterID` (`ChapterID`);

--
-- Indexes for table `manga`
--
ALTER TABLE `manga`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mangacategory`
--
ALTER TABLE `mangacategory`
  ADD PRIMARY KEY (`MangaID`,`CategoryID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `link`
--
ALTER TABLE `link`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `manga`
--
ALTER TABLE `manga`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chapter`
--
ALTER TABLE `chapter`
  ADD CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`MangaID`) REFERENCES `manga` (`ID`);

--
-- Constraints for table `link`
--
ALTER TABLE `link`
  ADD CONSTRAINT `link_ibfk_1` FOREIGN KEY (`ChapterID`) REFERENCES `chapter` (`ID`);

--
-- Constraints for table `mangacategory`
--
ALTER TABLE `mangacategory`
  ADD CONSTRAINT `mangacategory_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`ID`),
  ADD CONSTRAINT `mangacategory_ibfk_2` FOREIGN KEY (`MangaID`) REFERENCES `manga` (`ID`);
--
-- Database: `tkgd`
--
CREATE DATABASE IF NOT EXISTS `tkgd` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `tkgd`;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(255) NOT NULL,
  `html` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `html`) VALUES
(1, '<span style=\"font-size:36px;cursor:default\" class=\"l_31\" >Tiệm b&aacute;n h&agrave;ng<br />\r\n</span>');

-- --------------------------------------------------------

--
-- Table structure for table `binh_luan_lllll`
--

CREATE TABLE `binh_luan_lllll` (
  `id` int(11) NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `loai_menu` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi_so` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `so_lan_xoa` int(255) NOT NULL,
  `ngay_binh_luan` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE `footer` (
  `id` int(255) NOT NULL,
  `html` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`id`, `html`) VALUES
(1, '<style type=\"text/css\">a.llll:hover{color:red;}</style><br />\r\n<table border=\"0\" width=\"990\">\r\n    <tbody>\r\n        <tr>\r\n            <td style=\"text-align: right;\" width=\"445\"><strong>Email :</strong></td>\r\n            <td width=\"445\">Email g&igrave; đ&oacute;</td>\r\n        </tr>\r\n        <tr>\r\n            <td style=\"text-align: right;\"><strong>Điện thoại :</strong></td>\r\n            <td>Số điện thoại g&igrave; đ&oacute;</td>\r\n        </tr>\r\n        <tr>\r\n            <td style=\"text-align: right;\"><strong>Địa chỉ :</strong></td>\r\n            <td>Địa chỉ g&igrave; đ&oacute;</td>\r\n        </tr>\r\n        <tr>\r\n            <td style=\"text-align:right\"><strong>T&ecirc;n code web : </strong></td>\r\n            <td><a href=\"http://lamwebbanhang.blogspot.com/2017/07/code-web-ban-hang-e-lo-code-php.html\" target=\"_blank\" class=\"llll\">Code web b&aacute;n h&agrave;ng E lờ</a></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<br />');

-- --------------------------------------------------------

--
-- Table structure for table `hinh_anh_knl`
--

CREATE TABLE `hinh_anh_knl` (
  `id` int(11) NOT NULL,
  `ten` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thuoc_san_pham` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thuoc_bai_viet` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hinh_anh_knl`
--

INSERT INTO `hinh_anh_knl` (`id`, `ten`, `thuoc_san_pham`, `thuoc_bai_viet`) VALUES
(6, '66.gif', '', ''),
(7, 'at-a4.gif', '', ''),
(11, 'e36.jpg', '', ''),
(10, 'qn.jpg', '', ''),
(12, 'l_l_l_l_l.gif', '', ''),
(18, '98.gif', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `khung_html`
--

CREATE TABLE `khung_html` (
  `id` int(11) NOT NULL,
  `vi_tri` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ten` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khung_html`
--

INSERT INTO `khung_html` (`id`, `vi_tri`, `ten`, `noi_dung`) VALUES
(1, '1', 'Thông tin liên hệ', 'Nội dung th&ocirc;ng tin li&ecirc;n hệ<br />'),
(2, '2', 'Hướng dẫn mua hàng', 'Nội dung hướng dẫn mua h&agrave;ng <br />'),
(3, '3', 'Khung html 3', 'Nội dung khung html 3'),
(4, '4', 'Liên kết web', '<style type=\"text/css\" >\r\na.lll:hover{color:red;}\r\n</style>\r\nBạn có thể tải code web bán hàng <b>E lờ</b> tại liên kết tải code phía dưới : <br><br>\r\n\r\n<a href=\"http://lamwebbanhang.blogspot.com/2017/07/code-web-ban-hang-e-lo-code-php.html\" target=\"_blank\" class=\"lll\" >Liên kết tải code</a>');

-- --------------------------------------------------------

--
-- Table structure for table `luot_truy_cap`
--

CREATE TABLE `luot_truy_cap` (
  `id` int(255) NOT NULL,
  `luot_truy_cap` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mo_ta` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `moc_thoi_gian` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `luot_truy_cap`
--

INSERT INTO `luot_truy_cap` (`id`, `luot_truy_cap`, `mo_ta`, `moc_thoi_gian`, `thoi_gian`) VALUES
(1, '0', 'Tổng truy cập', '', ''),
(2, '0', 'Trong ngày', '1500447879', '16'),
(3, '59', 'Trong 3 ngày', '1500443383', ''),
(4, '59', 'Trong 10 ngày', '1500443383', ''),
(5, '0', 'Trong tháng', '1500443383', '8'),
(6, '0', 'Trong năm', '', '2017');

-- --------------------------------------------------------

--
-- Table structure for table `menu_ngang`
--

CREATE TABLE `menu_ngang` (
  `id` int(255) NOT NULL,
  `ten` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `loai` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thuoc_menu` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung_mo_ta` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `sap_xep` int(255) NOT NULL,
  `bat_tat_binh_luan` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu_ngang`
--

INSERT INTO `menu_ngang` (`id`, `ten`, `link`, `loai`, `thuoc_menu`, `noi_dung_mo_ta`, `noi_dung`, `sap_xep`, `bat_tat_binh_luan`) VALUES
(1, 'Giới thiệu', '', 'bai_viet_mot_tin', '', '', '<br />\r\nNội dung phần giới thiệu<br />\r\n<br />\r\nNội dung phần giới thiệu <br />\r\n<br />\r\nNội dung phần giới thiệu <br />\r\n<br />\r\nNội dung phần giới thiệu <br />\r\n<br />', 0, 'bat'),
(4, 'Quần áo nam', '', 'san_pham', '', 'Nội dung mô tả danh mục quần áo nam', '', 0, ''),
(5, 'Giầy dép', '', 'san_pham', '', '', '', 0, ''),
(14, 'Hướng dẫn mua hàng', '', 'bai_viet_mot_tin', '', '', 'Nội dung hướng dẫn mua h&agrave;ng c110<br />', 0, 'bat'),
(20, 'Tin tức', '', 'tin_tuc', '', 'Nội dung mô tả menu tin tức', '', 0, ''),
(21, 'Áo nam', '', 'san_pham', '4', '', '', 1, ''),
(22, 'Quần nam', '', 'san_pham', '4', '', '', 2, ''),
(23, 'Kiểu 1', '', 'san_pham', '5', '', '', 0, ''),
(24, 'Kiểu 2', '', 'san_pham', '5', '', '', 0, ''),
(25, 'Áo thun', '', 'san_pham', '4', '', '', 0, ''),
(26, 'Kích cỡ nhỏ', '', 'san_pham', '22', '', '', 0, ''),
(27, 'Kích cỡ vừa', '', 'san_pham', '22', '', '', 0, ''),
(29, 'Trong nước', '', 'san_pham', '27', '', '', 0, ''),
(30, 'Nước ngoài', '', 'san_pham', '27', '', '', 0, ''),
(31, 'Trong nước', '', 'san_pham', '24', '', '', 1, ''),
(32, 'Nước ngoài', '', 'san_pham', '24', '', '', 0, ''),
(33, 'Kiểu 1', '', 'san_pham', '21', '', '', 0, ''),
(34, 'Kiểu 2', '', 'san_pham', '21', '', '', 0, ''),
(35, 'Kiểu 3', '', 'san_pham', '21', '', '', 0, ''),
(36, 'Kiểu 1.1', '', 'san_pham', '33', '', '', 0, ''),
(37, 'Kiểu 1.2', '', 'san_pham', '33', '', '', 0, ''),
(48, 'Danh mục 9', '', 'tin_tuc', '20', '', '<br />', 38, ''),
(49, 'Danh mục 10', '', 'tin_tuc', '20', '', '<br />', 49, ''),
(50, 'Quần thun', '', 'san_pham', '4', '', '<br />', 50, '');

-- --------------------------------------------------------

--
-- Table structure for table `quang_cao_phai`
--

CREATE TABLE `quang_cao_phai` (
  `id` int(255) NOT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `rong` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `cao` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `san_pham`
--

CREATE TABLE `san_pham` (
  `id` int(255) NOT NULL,
  `ten` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `hinh_anh` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `gia_ban` int(255) NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `thuoc_menu` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong_mua` int(255) NOT NULL,
  `trang_chu` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sap_xep_trang_chu` int(255) NOT NULL,
  `loai` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ksp1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sx_ksp1` int(255) NOT NULL,
  `ksp2` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sx_ksp2` int(255) NOT NULL,
  `ksp3` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sx_ksp3` int(255) NOT NULL,
  `ksp4` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sx_ksp4` int(255) NOT NULL,
  `loai_gia` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `gb_vb` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung_ngan` longtext COLLATE utf8_unicode_ci NOT NULL,
  `hinh_anh_pnd` longtext COLLATE utf8_unicode_ci NOT NULL,
  `sap_xep` int(255) NOT NULL,
  `bat_tat_binh_luan` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `san_pham`
--

INSERT INTO `san_pham` (`id`, `ten`, `hinh_anh`, `gia_ban`, `noi_dung`, `thuoc_menu`, `so_luong_mua`, `trang_chu`, `sap_xep_trang_chu`, `loai`, `ksp1`, `sx_ksp1`, `ksp2`, `sx_ksp2`, `ksp3`, `sx_ksp3`, `ksp4`, `sx_ksp4`, `loai_gia`, `gb_vb`, `noi_dung_ngan`, `hinh_anh_pnd`, `sap_xep`, `bat_tat_binh_luan`) VALUES
(328, 'Áo nam 5', 'll_l_l.gif', 65000, 'Nội dung &aacute;o nam 5', '21', 0, 'co', 40, 'menu_ngang', '', 0, 'co', 0, '', 0, '', 0, '', '', '<br />', '', 3, 'bat'),
(329, 'Áo nam 6', 'an-6.gif', 75000, 'Nội dung áo nam 6', '21', 0, 'co', 5, 'menu_ngang', '', 0, 'co', 1, '', 0, '', 0, '', '', '', '', 2, 'bat'),
(330, 'Áo nam 7', 'an-7.gif', 85000, 'Nội dung áo nam 7', '21', 0, 'co', 6, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 9, 'bat'),
(339, 'Áo nam 16', 'an-b1.gif', 70000, 'Nội dung sản phẩm áo nam', '36', 0, 'co', 25, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 18, 'bat'),
(340, 'Áo nam 17', 'an-b2.gif', 70000, 'Nội dung sản phẩm &aacute;o nam', '36', 0, 'co', 26, 'menu_ngang', 'co', 0, '', 0, '', 0, '', 0, '', '', '<br />', '', 17, 'bat'),
(342, 'Áo nam 19', 'an-b4.gif', 45000, 'Nội dung sản phẩm &aacute;o nam', '36', 0, 'co', 27, 'menu_ngang', '', 0, 'co', 0, '', 0, '', 0, '', '', '<br />', '', 19, 'bat'),
(343, 'Áo nam 20', 'an-c1.gif', 75000, 'Nội dung sản phẩm áo nam', '37', 0, 'co', 28, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 0, 'bat'),
(344, 'Áo nam 21', 'an-c2.gif', 85000, 'Nội dung sản phẩm áo nam', '37', 0, 'co', 10, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 0, 'bat'),
(345, 'Áo nam 22', 'an-c3.gif', 95000, 'Nội dung sản phẩm áo nam', '37', 0, 'co', 9, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 0, 'bat'),
(346, 'Áo nam 23', 'an-c4.gif', 95000, 'Nội dung sản phẩm áo nam', '37', 0, 'co', 11, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 0, 'bat'),
(347, 'Áo nam 24', 'll_l.gif', 95000, 'Nội dung sản phẩm &aacute;o nam', '35', 0, 'co', 8, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '<br />', '', 0, 'bat'),
(356, 'Quần nam 1', 'qn.jpg', 95000, 'Nội dung quần nam', '4', 0, 'khong', 29, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '<br />', '', 1, 'bat'),
(357, 'Giầy 1', 'gd-a1.gif', 125000, 'Nội dung sản phẩm giầy', '24', 0, 'co', 31, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 1, 'bat'),
(358, 'Giầy 2', 'gd-a2.gif', 125000, 'Nội dung sản phẩm giầy', '24', 0, 'co', 32, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 2, 'bat'),
(359, 'Giầy 3', 'gd-a3.gif', 135000, 'Nội dung sản phẩm giầy', '24', 0, 'co', 33, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 3, 'bat'),
(360, 'Giầy 4', 'gd-a4.gif', 135000, 'Nội dung sản phẩm giầy', '24', 0, 'co', 36, 'menu_ngang', '', 0, '', 0, '', 0, '', 0, '', '', '', '', 4, 'bat'),
(362, 'Áo nam g1', 'g1.gif', 85000, 'nội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung <br />\r\n<br />\r\nnội dung', '4', 0, 'co', 1, '', '', 0, 'co', 0, '', 0, '', 0, '', '', 'Nội dung ngắn g&igrave; đ&oacute; <br />', '', 0, 'bat'),
(366, 'Áo nam g2', 'l_l_l_l_l.gif', 0, '&Aacute;o nam g2<br />\r\n<br />\r\n&Aacute;o nam g2<br />\r\n<br />\r\n&Aacute;o nam g2<br />', '21', 0, 'co', 19, 'menu_ngang', 'co', 366, '', 366, '', 366, '', 366, 'lien_he', '', 'g2<br />', '', 371, 'bat'),
(367, 'Áo thun g3', 'g3.gif', 90000, '&Aacute;o thun g3<br />', '25', 0, 'co', 4, 'menu_ngang', '', 367, '', 367, 'co', 367, '', 367, '', '', 'noi dung ngan gi do<br />', '', 0, 'bat'),
(368, 'Áo nam e1', 'bb3.gif', 80000, '&Aacute;o nam e1<br />\r\n<br />\r\n&Aacute;o nam e1<br />\r\n<br />\r\n&Aacute;o nam e1<br />', '34', 0, 'co', 5, 'menu_ngang', '', 368, '', 368, '', 368, '', 368, '', '', '<br />', '', 0, 'bat'),
(369, 'Áo nam e2', 'e2.gif', 95000, '&Aacute;o nam e2<br />\r\n<br />\r\n&Aacute;o nam e2<br />\r\n<br />\r\n&Aacute;o nam e2<br />', '34', 0, 'co', 17, 'menu_ngang', '', 369, '', 369, '', 369, 'co', 369, 'lien_he', '', 'noi dung ngan gi do<br />', '', 0, 'bat'),
(372, 'Giầy 5', 'gd-a5.gif', 80000, 'nội dung sản phẩm<br />', '24', 0, 'khong', 41, 'menu_ngang', '', 370, '', 370, '', 370, '', 370, '', '', '<br />', '', 370, 'bat');

-- --------------------------------------------------------

--
-- Table structure for table `so_nguoi_online`
--

CREATE TABLE `so_nguoi_online` (
  `id` int(255) NOT NULL,
  `time` int(255) NOT NULL,
  `ky_danh` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `so_nguoi_online`
--

INSERT INTO `so_nguoi_online` (`id`, `time`, `ky_danh`) VALUES
(41, 1500438661, '');

-- --------------------------------------------------------

--
-- Table structure for table `thong_so`
--

CREATE TABLE `thong_so` (
  `id` int(11) NOT NULL,
  `ma` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gia_tri` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `thong_so`
--

INSERT INTO `thong_so` (`id`, `ma`, `gia_tri`) VALUES
(1, 'bo_cuc', '3'),
(2, 'sxcp', 'k_html1[---]ksp1[---]ksp2[---]thong_ke[---]k_html4[---][---][---][---][---]'),
(3, 'ssp_ksp1', '2'),
(4, 'ssp_ksp2', '2'),
(5, 'ssp_ksp3', '2'),
(6, 'ssp_ksp4', '2'),
(7, 'td_a1', 'Hàng tốt'),
(9, 'td_a2', 'Hàng rẻ'),
(10, 'td_a3', 'Hàng gia công'),
(11, 'td_a4', 'Hàng chất lượng cao'),
(12, 'so_dong_splq', '2'),
(13, 'thamso_l', 'sua_thong_ke'),
(14, 'tg_tc_1', '1502889166'),
(15, 'tg_tc_2', '1502889166'),
(16, 'tg_tc_3', '1500465666'),
(17, 'tg_tc_4', '1500465666'),
(18, 'tg_tc_5', '1502889166'),
(19, 'tg_tc_6', '1502889166'),
(20, 'mau_giao_dien', 'xanh'),
(21, 'chuc_nang_binh_luan_san_pham', 'bat'),
(22, 'thoi_gian_xoa_binh_luan_san_pham', '1502882098'),
(23, 'thoi_gian_them_binh_luan_san_pham', '1502882757'),
(24, 'chuc_nang_binh_luan_danh_sach_bai_viet', 'bat'),
(25, 'chuc_nang_binh_luan_bai_viet_mot_tin', 'bat'),
(26, 'tieu_de_web', 'Quần áo'),
(27, 'mo_ta_web', 'Mô tả web'),
(28, 'so_san_pham_tren_dong', '4'),
(40, 'so_binh_luan_toi_da', '30000'),
(29, 'nguoi_tro_chuyen', '56'),
(30, 'tro_chuyen', 'bat'),
(32, 'luot_truy_cap_trong_mot_giay', '0'),
(33, 'thoi_gian_tctmg', '1502272427'),
(34, 'so_tin_nhan_toi_da', '1000'),
(35, 'thoi_diem_nhan_tin_gan_day', '1502883895'),
(36, 'thoi_diem_lay_tin_nhan_moi', '1502288172'),
(37, 'so_lan_lay_tin_nhan_trong_mot_giay', '10'),
(39, 'so_binh_luan_toi_da_trong_ngay', '300'),
(41, 'so_binh_luan_trong_ngay', '14'),
(42, 'ngay_binh_luan_moi', '16'),
(44, 'xoa_binh_luan_khi_dat_toi_gioi_han', 'co'),
(43, 'cach_hien_thi_binh_luan', 'moi_truoc_cu_sau');

-- --------------------------------------------------------

--
-- Table structure for table `tin_tuc`
--

CREATE TABLE `tin_tuc` (
  `id` int(255) NOT NULL,
  `ten` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `hinh_anh` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thuoc_menu` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sap_xep` int(255) NOT NULL,
  `bat_tat_binh_luan` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tin_tuc`
--

INSERT INTO `tin_tuc` (`id`, `ten`, `noi_dung`, `hinh_anh`, `thuoc_menu`, `sap_xep`, `bat_tat_binh_luan`) VALUES
(203, 'Tin tức e35', 'Noi dung tin tuc e35<br />', 'e35.jpg', '20', 101, 'bat'),
(204, 'Tin tức e36', 'Noi dung tin tuc e36<br />', 'e36.jpg', '20', 100, 'bat');

-- --------------------------------------------------------

--
-- Table structure for table `tro_chuyen_lllll`
--

CREATE TABLE `tro_chuyen_lllll` (
  `id` int(11) NOT NULL,
  `noi_dung` longtext COLLATE utf8_unicode_ci NOT NULL,
  `nguoi_tro_chuyen` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian` int(255) NOT NULL,
  `hien_thi` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `binh_luan_lllll`
--
ALTER TABLE `binh_luan_lllll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hinh_anh_knl`
--
ALTER TABLE `hinh_anh_knl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khung_html`
--
ALTER TABLE `khung_html`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `luot_truy_cap`
--
ALTER TABLE `luot_truy_cap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_ngang`
--
ALTER TABLE `menu_ngang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quang_cao_phai`
--
ALTER TABLE `quang_cao_phai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `so_nguoi_online`
--
ALTER TABLE `so_nguoi_online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thong_so`
--
ALTER TABLE `thong_so`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tin_tuc`
--
ALTER TABLE `tin_tuc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tro_chuyen_lllll`
--
ALTER TABLE `tro_chuyen_lllll`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `binh_luan_lllll`
--
ALTER TABLE `binh_luan_lllll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hinh_anh_knl`
--
ALTER TABLE `hinh_anh_knl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `khung_html`
--
ALTER TABLE `khung_html`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `luot_truy_cap`
--
ALTER TABLE `luot_truy_cap`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu_ngang`
--
ALTER TABLE `menu_ngang`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `quang_cao_phai`
--
ALTER TABLE `quang_cao_phai`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `san_pham`
--
ALTER TABLE `san_pham`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=373;

--
-- AUTO_INCREMENT for table `so_nguoi_online`
--
ALTER TABLE `so_nguoi_online`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `thong_so`
--
ALTER TABLE `thong_so`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tin_tuc`
--
ALTER TABLE `tin_tuc`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `tro_chuyen_lllll`
--
ALTER TABLE `tro_chuyen_lllll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Database: `ttcn`
--
CREATE DATABASE IF NOT EXISTS `ttcn` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ttcn`;

-- --------------------------------------------------------

--
-- Table structure for table `loaisanpham`
--

CREATE TABLE `loaisanpham` (
  `id` int(11) NOT NULL,
  `tenloaisanpham` varchar(200) NOT NULL,
  `hinhanhloaisp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loaisanpham`
--

INSERT INTO `loaisanpham` (`id`, `tenloaisanpham`, `hinhanhloaisp`) VALUES
(1, 'Truyện Tranh', 'http://2.bp.blogspot.com/-i9-EZdnR8-Y/ULnnJsDyhFI/AAAAAAAADvE/YgC0BHVufPY/s0/-360kpopMT-_Kyou-_koi_wo_hajimemasu_vol.9_chap_54-vol9ch54pg01.jpg'),
(2, 'Sách Giáo Khoa', 'https://cdn02.static-adayroi.com/0/2017/06/16/1497612328586_5006594.jpg'),
(3, 'Trinh Thám', 'http://anybooks.vn/images/book/image/loi_canh_bao_tieu_thuyet_trinh_tham_1_14_tap_3.jpg'),
(4, 'Khoa Học', 'https://www.fahasa.com/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/8/9/8934974144175.jpg'),
(5, 'Kỹ Thuật', 'http://minhkhai.vn/hinhlon/24259.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `tensanpham` varchar(200) NOT NULL,
  `giasanpham` int(15) NOT NULL,
  `hinhanhsanpham` varchar(200) NOT NULL,
  `motasanpham` mediumtext NOT NULL,
  `idsanpham` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `tensanpham`, `giasanpham`, `hinhanhsanpham`, `motasanpham`, `idsanpham`) VALUES
(1, 'Mộng mơ đầu đời', 20000, 'http://2.bp.blogspot.com/-i9-EZdnR8-Y/ULnnJsDyhFI/AAAAAAAADvE/YgC0BHVufPY/s0/-360kpopMT-_Kyou-_koi_wo_hajimemasu_vol.9_chap_54-vol9ch54pg01.jpg', 'ahihi', 1),
(2, 'Toán 1', 20000, 'https://cdn02.static-adayroi.com/0/2017/06/16/1497612328586_5006594.jpg', 'ahihihi', 2),
(3, 'Lời cảnh báo', 30000, 'http://anybooks.vn/images/book/image/loi_canh_bao_tieu_thuyet_trinh_tham_1_14_tap_3.jpg', 'lời cảnh báo ', 3),
(4, 'Kỹ Thuật 5', 150000, 'http://stbhn.edu.vn/FileUpload/Images/kt.jpg', 'sách kỹ thuật lớp 5', 5),
(5, 'Khoa học 4', 30000, 'http://stbhn.edu.vn/FileUpload/Images/khoahoclop.jpg', 'khoa học 4', 4),
(6, 'tieng anh', 120000, 'http://stbhn.edu.vn/FileUpload/Images/khoahoclop.j...\r\n', 'AFSDF', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loaisanpham`
--
ALTER TABLE `loaisanpham`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `loaisanpham`
--
ALTER TABLE `loaisanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Database: `ttcn_ngodanghieu`
--
CREATE DATABASE IF NOT EXISTS `ttcn_ngodanghieu` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ttcn_ngodanghieu`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_monan`
--

CREATE TABLE `tbl_monan` (
  `id` int(11) NOT NULL,
  `ten_monan` varchar(255) NOT NULL,
  `mota_monan` varchar(255) NOT NULL,
  `gia_monan` int(11) NOT NULL,
  `img_monan` varchar(255) NOT NULL,
  `ma_monan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sp`
--

CREATE TABLE `tbl_sp` (
  `id` int(11) NOT NULL,
  `ten_sp` varchar(255) NOT NULL,
  `sl_sp` int(11) NOT NULL,
  `ngaynhap` date NOT NULL,
  `nhasx` varchar(255) NOT NULL,
  `id_user` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `loai_sp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `namelogin_user` varchar(255) NOT NULL,
  `pass_user` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `name_user` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `namelogin_user`, `pass_user`, `level`, `name_user`) VALUES
(1, 'admin', 'admin', 1, 'Ngo Dang Hieu'),
(2, '1', '1', 2, 'Duong Thi Thuy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_monan`
--
ALTER TABLE `tbl_monan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sp`
--
ALTER TABLE `tbl_sp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_monan`
--
ALTER TABLE `tbl_monan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sp`
--
ALTER TABLE `tbl_sp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
