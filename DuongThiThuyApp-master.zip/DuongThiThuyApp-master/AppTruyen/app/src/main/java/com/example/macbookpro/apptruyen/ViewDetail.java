package com.example.macbookpro.apptruyen;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macbookpro.apptruyen.Adapter.MyChapterAdapter;
import com.example.macbookpro.apptruyen.Adapter.MyViewPadeAdapter;
import com.example.macbookpro.apptruyen.Common.Common;
import com.example.macbookpro.apptruyen.Model.Chapter;
import com.example.macbookpro.apptruyen.Model.Link;
import com.example.macbookpro.apptruyen.Retrofit.IComicAPI;
import com.wajahatkarim3.easyflipviewpager.BookFlipPageTransformer;

import java.util.List;

import dmax.dialog.SpotsDialog;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ViewDetail extends AppCompatActivity {

    IComicAPI iComicAPI;
    ViewPager viewPager;
    CompositeDisposable compositeDisposable = new CompositeDisposable();
    TextView textView;
    View back,next;

    @Override
    protected void onStop() {
        compositeDisposable.clear();
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_detail);
        iComicAPI = Common.getAPI();
        viewPager = (ViewPager) findViewById(R.id.view_page);
        textView = (TextView) findViewById(R.id.txt_title) ;
        back = (View) findViewById(R.id.viewdetail_back) ;
        next = (View) findViewById(R.id.viewdetail_right);

        fetchLink(Common.chapterList.get(Common.chapter_index).getID());
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Common.chapter_index==0){
                    Toast.makeText(ViewDetail.this, "Ban dang doc trang dau", Toast.LENGTH_SHORT).show();
                }else {
                    Common.chapter_index--;
                    fetchLink(Common.chapterList.get(Common.chapter_index).getID());
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Common.chapter_index==Common.chapterList.size()-1){
                    Toast.makeText(ViewDetail.this, "Ban dang doc trang dau", Toast.LENGTH_SHORT).show();
                }else {
                    Common.chapter_index++;
                    fetchLink(Common.chapterList.get(Common.chapter_index).getID());
                }
            }
        });

    }

    private void fetchLink(int id) {
        final android.app.AlertDialog dialog = new SpotsDialog.Builder().setContext(this).setMessage("Xin cho").setCancelable(false).build();
        dialog.show();
        compositeDisposable.add(iComicAPI.getLinkList(id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Link>>() {
                    @Override
                    public void accept(List<Link> links) throws Exception {
                        MyViewPadeAdapter myViewPadeAdapter = new MyViewPadeAdapter(getBaseContext(),links);

                        viewPager.setAdapter(myViewPadeAdapter);
                        BookFlipPageTransformer bookFlipPageTransformer = new BookFlipPageTransformer();
                        bookFlipPageTransformer.setScaleAmountPercent(10f);
                        viewPager.setPageTransformer(true,bookFlipPageTransformer);

                        dialog.dismiss();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dialog.dismiss();
                    }
                })
        );
    }
}
