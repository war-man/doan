package com.example.macbookpro.apptruyen.Retrofit;



import com.example.macbookpro.apptruyen.Model.Banner;
import com.example.macbookpro.apptruyen.Model.Chapter;
import com.example.macbookpro.apptruyen.Model.Comic;
import com.example.macbookpro.apptruyen.Model.Link;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface IComicAPI {
    @GET("banner")
    Observable<List<Banner>> getBannerList();

    @GET("comic")
    Observable<List<Comic>> getComicList();

    @GET("chapter/{comicid}")
    Observable<List<Chapter>> getChapterList(@Path("comicid")int comicid);

//    @GET("tenfile.php")
//    Observable<List<Chapter>> getChapterList(@Query("MangaID") int comicid);


    @GET("links/{chapterid}")
    Observable<List<Link>> getLinkList(@Path("chapterid")int chapterid);
}
