package com.example.macbookpro.apptruyen.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.macbookpro.apptruyen.ChapterActivity;
import com.example.macbookpro.apptruyen.Common.Common;
import com.example.macbookpro.apptruyen.Interface.ItemSetOnClick;
import com.example.macbookpro.apptruyen.Model.Chapter;
import com.example.macbookpro.apptruyen.R;
import com.example.macbookpro.apptruyen.ViewDetail;

import java.util.List;

public class MyChapterAdapter extends RecyclerView.Adapter<MyChapterAdapter.ViewHolder> {
    private ChapterActivity context;
    private List<Chapter> characterList;

    public MyChapterAdapter(ChapterActivity context, List<Chapter> characterList) {
        this.context = context;
        this.characterList = characterList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_chapter,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.textView.setText(new StringBuilder(characterList.get(i).getName()));

        viewHolder.setItemSetOnClick(new ItemSetOnClick() {
            @Override
            public void onClick(View view, int posstion) {
                context.startActivity(new Intent(context,ViewDetail.class));
                Common.selected_chapter=characterList.get(posstion);
                Common.chapter_index = posstion;

            }
        });
    }

    @Override
    public int getItemCount() {
        return characterList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView textView;
        private ItemSetOnClick itemSetOnClick;

        public void setItemSetOnClick(ItemSetOnClick itemSetOnClick) {
            this.itemSetOnClick = itemSetOnClick;
        }

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.txt_chapter_number);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            itemSetOnClick.onClick(v,getAdapterPosition());
        }
    }
}
