package com.example.macbookpro.apptruyen;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macbookpro.apptruyen.Adapter.MyComicAdapter;
import com.example.macbookpro.apptruyen.Adapter.MySliderAdapter;
import com.example.macbookpro.apptruyen.Common.Common;
import com.example.macbookpro.apptruyen.Model.Banner;
import com.example.macbookpro.apptruyen.Model.Comic;
import com.example.macbookpro.apptruyen.Retrofit.IComicAPI;
import com.example.macbookpro.apptruyen.Service.PicassoImageLoadingService;

import java.util.List;

import dmax.dialog.SpotsDialog;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import ss.com.bannerslider.Slider;

public class MainActivity extends AppCompatActivity {
    Slider slider;
    IComicAPI iComicAPI;
    TextView textView;
    CompositeDisposable compositeDisposable = new CompositeDisposable();
    RecyclerView recyclerView;

    @Override
    protected void onStop() {
        compositeDisposable.clear();
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iComicAPI = Common.getAPI();

        slider = (Slider) findViewById(R.id.banner_slider);
        Slider.init(new PicassoImageLoadingService());

        textView = (TextView) findViewById(R.id.txt_comic);

        recyclerView = (RecyclerView) findViewById(R.id.recylectview_comic);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));


        fetchBanner();

        fetchComic();

    }

    private void fetchComic() {
        final android.app.AlertDialog dialog = new SpotsDialog.Builder().setContext(this).setMessage("Xin cho").setCancelable(false).build();
        dialog.show();
        compositeDisposable.add(iComicAPI.getComicList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Comic>>() {
                    @Override
                    public void accept(List<Comic> comics) throws Exception {
                        recyclerView.setAdapter(new MyComicAdapter(MainActivity.this,comics));
                        textView.setText(new StringBuilder("NEW COMIC(").append(comics.size()).append(")"));
                        dialog.dismiss();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dialog.dismiss();
                    }
                })
        );

    }

    private void fetchBanner() {
        compositeDisposable.add(iComicAPI.getBannerList()
            .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Banner>>() {
                    @Override
                    public void accept(List<Banner> banners) throws Exception {
                        slider.setAdapter(new MySliderAdapter(banners));
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {

                    }
                })
        );
    }
}
