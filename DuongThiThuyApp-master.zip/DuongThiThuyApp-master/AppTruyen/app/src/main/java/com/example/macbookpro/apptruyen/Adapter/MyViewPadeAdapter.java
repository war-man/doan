package com.example.macbookpro.apptruyen.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.macbookpro.apptruyen.Model.Link;
import com.example.macbookpro.apptruyen.R;
import com.github.chrisbanes.photoview.PhotoView;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MyViewPadeAdapter extends PagerAdapter {
    Context context;
    List<Link> linkList;
    LayoutInflater inflater;

    public MyViewPadeAdapter(Context context, List<Link> linkList) {
        this.context = context;
        this.linkList = linkList;
        inflater=LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return linkList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view.equals(o);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view_layout = inflater.inflate(R.layout.view_page,container,false);

        PhotoView photoView = (PhotoView)view_layout.findViewById(R.id.photo_view);
        Picasso.get().load(linkList.get(position).getLink()).into(photoView);
        container.addView(view_layout);

        return view_layout;
    }
}
