package com.example.macbookpro.apptruyen.Interface;

import android.view.View;

public interface ItemSetOnClick {
    void onClick(View view,int posstion);
}
