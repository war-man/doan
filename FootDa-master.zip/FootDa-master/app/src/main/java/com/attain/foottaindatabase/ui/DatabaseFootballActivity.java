package com.attain.foottaindatabase.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.adapter.Basic.LeaguesAdapter;
import com.attain.foottaindatabase.model.Leagues;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DatabaseFootballActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    RecyclerView rvLeagues;
    LeaguesAdapter adapter;
    List<Leagues> leaguesList = new ArrayList<>();
    Toolbar toolbar;
    NavigationView navigationView;
    DatabaseReference reference;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_football);
        setTitle("Foottain List");
        rvLeagues = findViewById(R.id.rvLeague);
        preferences = getSharedPreferences("myPref",
                Context.MODE_PRIVATE);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        getLeagueList();
    }

    private void getLeagueList() {
        reference = FirebaseDatabase.getInstance().getReference("Leagues");
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        Leagues leagues = ds.getValue(Leagues.class);
                        leaguesList.add(leagues);
                    }
                    adapter = new LeaguesAdapter(DatabaseFootballActivity.this, leaguesList);
                    rvLeagues.setAdapter(adapter);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(DatabaseFootballActivity.this);
                    rvLeagues.setLayoutManager(layoutManager);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();

        if (id == R.id.navNews) {
            startActivity(new Intent(this, MainGuestActivity.class));
        } else if (id == R.id.navCate) {
            startActivity(new Intent(this, DatabaseFootballActivity.class));
        }
        //else if (id == R.id.navfavourite) {
//            startActivity(new Intent(this,MainActivity.class));
//            setTitle("My Favorites");
//        } else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }
        else if (id == R.id.navLogout) {
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear();
            editor.commit();
            startActivity(new Intent(this, LoginActivity.class));
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public void select(View view) {
        Toast.makeText(this, "Choose a league Below", Toast.LENGTH_SHORT).show();
    }
}
