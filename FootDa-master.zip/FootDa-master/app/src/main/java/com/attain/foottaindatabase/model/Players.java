package com.attain.foottaindatabase.model;

public class Players {
    public String playerName;
    public String playerPosition;
    public String playerStyle;
    public String clubName;
    public long birthday;
    public double marketValue;
    public String playerImage;

    public Players(String playerName, String playerPosition, String playerStyle, String clubName, long birthday, double marketValue, String playerImage) {
        this.playerName = playerName;
        this.playerPosition = playerPosition;
        this.playerStyle = playerStyle;
        this.clubName = clubName;
        this.birthday = birthday;
        this.marketValue = marketValue;
        this.playerImage = playerImage;
    }

    public Players() {
    }


    public String getPlayerImage() {
        return playerImage;
    }

    public void setPlayerImage(String playerImage) {
        this.playerImage = playerImage;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerPosition() {
        return playerPosition;
    }

    public void setPlayerPosition(String playerPosition) {
        this.playerPosition = playerPosition;
    }

    public String getPlayerStyle() {
        return playerStyle;
    }

    public void setPlayerStyle(String playerStyle) {
        this.playerStyle = playerStyle;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public long getBirthday() {
        return birthday;
    }

    public void setBirthday(long birthday) {
        this.birthday = birthday;
    }

    public double getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }
}
