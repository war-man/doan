package com.attain.foottaindatabase.adapter.Basic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.model.Leagues;
import com.bumptech.glide.Glide;

import java.util.List;

public class LeaguesAdapter extends RecyclerView.Adapter<LeaguesAdapter.ViewHolder> {
    List<Leagues> leaguesList;
    Context context;
    public LeaguesAdapter(Context context,List<Leagues> leaguesList){
        this.context=context;
        this.leaguesList=leaguesList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.item_league,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Leagues leagues=leaguesList.get(position);
        holder.tvLname.setText(leagues.getLeagueFullName());
        holder.tvLFoundation.setText("Foundation Year: "+leagues.getFoundationYear());
        Glide.with(context).load(leagues.leagueLogo).into(holder.ivLimage);
        if(leagues.leagueLogo.equals("")){
            holder.ivLimage.setImageResource(R.drawable.bundesliga);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return leaguesList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLname;
        TextView tvLFoundation;
        ImageView ivLimage;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            tvLname=itemView.findViewById(R.id.tvLeagueName);
            tvLFoundation=itemView.findViewById(R.id.tvLeagueFoundation);
            ivLimage=itemView.findViewById(R.id.ivLogoL);
        }
    }
}
