package com.attain.foottaindatabase.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.attain.foottaindatabase.R;

public class NewsDetailsActivity extends AppCompatActivity {
    WebView wv;
    String link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);
        wv=findViewById(R.id.wv);
        Intent intent=this.getIntent();
        link=intent.getStringExtra("link");

        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setLoadsImagesAutomatically(true);
        wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        wv.loadUrl(link);
        wv.setWebViewClient(new WebViewClient());

    }

    public void back(View view) {
        finish();
    }
}
