package com.attain.foottaindatabase.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.model.Guest;
import com.attain.foottaindatabase.ui.admin.MainActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {
    DatabaseReference reference;
    EditText edtgname, edtgpass;
    SharedPreferences preferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtgname = findViewById(R.id.edtgname);
        edtgpass = findViewById(R.id.edtgpass);
        preferences = getSharedPreferences("myPref",
                Context.MODE_PRIVATE);
        if (preferences.getBoolean("check_login", false) == true) {
            startActivity(new Intent(LoginActivity.this, MainGuestActivity.class));
        }
    }

    public void member(View view) {

        final String username = edtgname.getText().toString();
        final String password = edtgpass.getText().toString();
        reference = FirebaseDatabase.getInstance().getReference("Guest").child(username);
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (username.equals("") || password.equals("")) {
                    Toast.makeText(LoginActivity.this, "Không để trống Username và Password", Toast.LENGTH_SHORT).show();
                } else if (dataSnapshot.getValue() == null) {
                    Toast.makeText(LoginActivity.this, "Không tồn tại Username này", Toast.LENGTH_SHORT).show();
                } else {

                    Guest guest = dataSnapshot.getValue(Guest.class);

                    if (guest.password.equals(password)) {

                        Toast.makeText(LoginActivity.this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                        FirebaseInstanceId.getInstance().getInstanceId()
                                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                        if (!task.isSuccessful()) {
                                            return;
                                        } else {
                                            Map<String, Object> id = new HashMap<>();
                                            id.put("fcm", task.getResult().getToken());
                                            reference.updateChildren(id);
                                            Log.e("UPDATE", "fcmid= " + task.getResult().getToken());

                                            SharedPreferences.Editor editor = preferences.edit();
                                            editor.putBoolean("check_login", true);
                                            editor.putString("key_fcm", task.getResult().getToken());
                                            editor.putString("key_user", username);
                                            editor.commit();
                                            Intent intent = new Intent(LoginActivity.this, MainGuestActivity.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    }
                                });
                    } else {
                        Toast.makeText(LoginActivity.this, "Sai mật khẩu", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void admin(View view) {
        String adminUser = edtgname.getText().toString();
        String adminPass = edtgpass.getText().toString();
        if (adminUser.equals("admin") && adminPass.equals("41232912")) {

            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            Toast.makeText(this, "Chào Admin!!!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Bạn không phải Admin!!!", Toast.LENGTH_SHORT).show();
        }
    }

    public void signup(View view) {
        startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
    }
}
