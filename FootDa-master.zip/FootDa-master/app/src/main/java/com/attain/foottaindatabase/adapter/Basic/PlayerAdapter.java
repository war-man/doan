package com.attain.foottaindatabase.adapter.Basic;

public class PlayerAdapter {
}
