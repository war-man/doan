package com.attain.foottaindatabase.ui.admin;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;


import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.adapter.ForAdmin.ListClubAdapter;
import com.attain.foottaindatabase.adapter.ForAdmin.ListLeagueAdapter;
import com.attain.foottaindatabase.model.Clubs;
import com.attain.foottaindatabase.model.Leagues;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DatabaseReference refLeague, refClub, refPlayer, reference;
    DatabaseReference refPlayerRanking;

    List<Leagues> leaguesList = new ArrayList<>();
    List<Clubs> clubsList = new ArrayList<>();
    RecyclerView rvList;
    ListLeagueAdapter adapterL;
    ListClubAdapter adapterC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        reference = FirebaseDatabase.getInstance().getReference("Leagues");
        rvList = findViewById(R.id.rvList);
    }

    public void exit(View view) {
        finish();
    }

    public void listLeagues(View view) {
        refLeague = FirebaseDatabase.getInstance().getReference("Leagues");
        refLeague.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        Leagues leagues = ds.getValue(Leagues.class);
                        leaguesList.add(leagues);
                    }
                    adapterL = new ListLeagueAdapter(MainActivity.this, leaguesList);
                    rvList.setAdapter(adapterL);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                    rvList.setLayoutManager(layoutManager);
                    //adapterL.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void listClubs(View view) {
        refClub = FirebaseDatabase.getInstance().getReference("Clubs");
        refClub.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        Clubs clubs = ds.getValue(Clubs.class);
                        clubsList.add(clubs);
                    }
                    adapterC = new ListClubAdapter(MainActivity.this, clubsList);
                    rvList.setAdapter(adapterC);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
                    rvList.setLayoutManager(layoutManager);
                    //adapterC.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
