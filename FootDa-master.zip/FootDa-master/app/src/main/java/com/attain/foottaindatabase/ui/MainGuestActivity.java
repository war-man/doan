package com.attain.foottaindatabase.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;


import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.adapter.Basic.NewsAdapter;
import com.attain.foottaindatabase.model.News;
import com.google.android.material.navigation.NavigationView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainGuestActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    RecyclerView rvNews;
    List<News> newsList = new ArrayList<>();
    NewsAdapter adapter;
    Toolbar toolbar;
    NavigationView navigationView;
    SharedPreferences preferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_guest);
        setTitle("News");
        preferences = getSharedPreferences("myPref",
                Context.MODE_PRIVATE);

        rvNews = findViewById(R.id.rvNews);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        //https://www.transfermarkt.co.uk/rss/news
        LoadRssFromInternetTask loadRssFromInternetTask = new LoadRssFromInternetTask(MainGuestActivity.this);
        loadRssFromInternetTask.execute("https://www.transfermarkt.co.uk/rss/news");
    }


    public class LoadRssFromInternetTask extends AsyncTask<String, Long, List<News>> {

        private Context context;

        public LoadRssFromInternetTask(Context context) {
            this.context = context;
            Log.e("START", "START");
        }


        @Override
        protected List<News> doInBackground(String... strings) {

            ArrayList<News> newsArrayList = new ArrayList<>();

            try {
                URL url = new URL(strings[0]);

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);
                XmlPullParser xpp = factory.newPullParser();


                xpp.setInput(getInputStream(url), "UTF_8");


                int eventType = xpp.getEventType();
                String text = "";

                News news = null;
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    String nameTag = xpp.getName();
                    switch (eventType) {
                        case XmlPullParser.START_TAG:

                            if (nameTag.equalsIgnoreCase("item")) {
                                news = new News();
                                Log.e("CREATE", "NEWS");
                            }
                            break;

                        case XmlPullParser.TEXT:
                            text = xpp.getText();
                            break;

                        case XmlPullParser.END_TAG:
                            if (nameTag.equals("item"))
                                newsArrayList.add(news);
                            else if (news != null & nameTag.equalsIgnoreCase("title"))
                                news.title = text.trim();
                            else if (news != null & nameTag.equalsIgnoreCase("description"))
                                news.description = text.trim();
                            else if (news != null & nameTag.equalsIgnoreCase("pubDate"))
                                news.pubDate = text.trim();
                            else if (news != null & nameTag.equalsIgnoreCase("link"))
                                news.link = text.trim();
                            else if (news != null & nameTag.equalsIgnoreCase("image"))
                                news.image = text.trim();
                            break;

                        default:
                            break;

                    }
                    eventType = xpp.next(); //move to next element
                }

                Log.e("SIZE", newsArrayList.size() + "");


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return newsArrayList;
        }

        private InputStream getInputStream(URL url) {
            try {
                return url.openConnection().getInputStream();
            } catch (IOException e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(List<News> newsList) {
            adapter = new NewsAdapter(MainGuestActivity.this, newsList);
            rvNews.setAdapter(adapter);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainGuestActivity.this);
            rvNews.setLayoutManager(layoutManager);
            adapter.notifyDataSetChanged();

        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();

        if (id == R.id.navNews) {
            startActivity(new Intent(this, MainGuestActivity.class));
        } else if (id == R.id.navCate) {
            startActivity(new Intent(this, DatabaseFootballActivity.class));
        }
        //else if (id == R.id.navfavourite) {
//            startActivity(new Intent(this,MainActivity.class));
//            setTitle("My Favorites");
//        } else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
//        }else if (id == R.id.navabout) {
//            startActivity(new Intent(this,AboutActivity.class));
        //}
        else if (id == R.id.navLogout) {
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear();
            editor.commit();
            startActivity(new Intent(this, LoginActivity.class));
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return false;
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
