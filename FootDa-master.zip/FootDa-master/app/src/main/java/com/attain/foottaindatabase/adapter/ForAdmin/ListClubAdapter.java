package com.attain.foottaindatabase.adapter.ForAdmin;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.model.Clubs;
import com.attain.foottaindatabase.model.Players;
import com.attain.foottaindatabase.ui.admin.MainActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;

public class ListClubAdapter extends RecyclerView.Adapter<ListClubAdapter.ViewHolder> {
    Context context;
    List<Clubs> clubsList;
    DatabaseReference refLeagues, refPlayers;

    public ListClubAdapter(Context context, List<Clubs> clubsList) {
        this.context = context;
        this.clubsList = clubsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_list_admin, parent, false);
        return new ListClubAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.tvList.setText(clubsList.get(position).clubName);
        holder.tvList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view1 = LayoutInflater.from(context).inflate(R.layout.dialog_add_players, null);
                builder.setView(view1);
                builder.setTitle("Add Player");
                final EditText clname = view1.findViewById(R.id.edtClname);
                final EditText playerN = view1.findViewById(R.id.edtPlayerName);
                final EditText playerS = view1.findViewById(R.id.edtPosition);
                final EditText playerP = view1.findViewById(R.id.edtStyle);
                final EditText marktV = view1.findViewById(R.id.edtMarketValue);
                final EditText birthday = view1.findViewById(R.id.edtBirthday);

                clname.setText(clubsList.get(position).clubName);
                Button btnAdd = view1.findViewById(R.id.btnAdd);
                Button btnDate = view1.findViewById(R.id.btnDate);
                final String league = clubsList.get(position).leagueName;
                final String club = clubsList.get(position).clubName;
                btnDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        int year = calendar.get(Calendar.YEAR);
                        int month = calendar.get(Calendar.MONTH);
                        int dayofMonth = calendar.get(Calendar.DAY_OF_MONTH);
                        DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int day) {
                                        birthday.setText(day + "/" + (month + 1) + "/" + year);
                                    }
                                }, year, month, dayofMonth);
                        datePickerDialog.show();
                    }
                });
                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (playerN.getText().toString().equals("") || playerS.getText().toString().equals("") ||
                                playerP.getText().toString().equals("") || marktV.getText().toString().equals("") ||
                                birthday.getText().toString().equals("") || clname.getText().toString().equals("")) {
                            Toast.makeText(context, "NO EMPTY", Toast.LENGTH_SHORT).show();
                        } else {
                            refLeagues = FirebaseDatabase.getInstance().getReference("Leagues").
                                    child(league).child("Clubs").
                                    child(club).child("Players").
                                    child(playerN.getText().toString());
                            refPlayers = FirebaseDatabase.getInstance().getReference("Players").
                                    child(playerN.getText().toString());

                            refLeagues.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() == null) {
                                        Players players = new Players();
                                        players.playerName = playerN.getText().toString();
                                        players.playerPosition = playerP.getText().toString();
                                        players.playerStyle = playerS.getText().toString();
                                        players.birthday = Long.parseLong(birthday.getText().toString());
                                        players.marketValue = Double.parseDouble(marktV.getText().toString());
                                        players.playerImage = "";

                                        refLeagues.setValue(players, new DatabaseReference.CompletionListener() {
                                            @Override
                                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                                Toast.makeText(context, "Create Succeed", Toast.LENGTH_SHORT).show();
                                                playerN.setText("");
                                                playerP.setText("");
                                                playerS.setText("");
                                                birthday.setText("");
                                                marktV.setText("");
                                            }
                                        });
                                    } else {
                                        Toast.makeText(context, "Club Existed", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });

                            refPlayers.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() == null) {
                                        Players players = new Players();
                                        players.playerName = playerN.getText().toString();
                                        players.playerPosition = playerP.getText().toString();
                                        players.playerStyle = playerS.getText().toString();
                                        players.birthday = Long.parseLong(birthday.getText().toString());
                                        players.marketValue = Double.parseDouble(marktV.getText().toString());
                                        players.playerImage = "";

                                        refPlayers.setValue(players, new DatabaseReference.CompletionListener() {
                                            @Override
                                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                                Toast.makeText(context, "Create Succeed", Toast.LENGTH_SHORT).show();
                                                playerN.setText("");
                                                playerP.setText("");
                                                playerS.setText("");
                                                birthday.setText("");
                                                marktV.setText("");
                                            }
                                        });
                                    } else {
                                        Toast.makeText(context, "Club Existed", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });

                        }
                    }
                });
                builder.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return clubsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvList;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvList = itemView.findViewById(R.id.tvList);
        }
    }
}
