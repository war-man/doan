package com.attain.foottaindatabase.model;

public class Leagues {
    public String leagueName;
    public String leagueFullName;
    public int foundationYear;
    public String leagueLogo;

    public Leagues(String leagueName, String leagueFullName, int foundationYear, String leagueLogo) {
        this.leagueName = leagueName;
        this.leagueFullName = leagueFullName;
        this.foundationYear = foundationYear;
        this.leagueLogo=leagueLogo;
    }

    public Leagues() {

    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }

    public String getLeagueFullName() {
        return leagueFullName;
    }

    public void setLeagueFullName(String leagueFullName) {
        this.leagueFullName = leagueFullName;
    }

    public int getFoundationYear() {
        return foundationYear;
    }

    public void setFoundationYear(int foundationYear) {
        this.foundationYear = foundationYear;
    }

    public String getLeagueLogo() {
        return leagueLogo;
    }

    public void setLeagueLogo(String leagueLogo) {
        this.leagueLogo = leagueLogo;
    }

    @Override
    public String toString() {
        return leagueName ;

    }
}
