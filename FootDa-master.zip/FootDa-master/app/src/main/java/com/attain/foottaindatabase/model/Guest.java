package com.attain.foottaindatabase.model;

public class Guest {
    public String fcm;
    public String username;
    public String password;

}
