package com.attain.foottaindatabase.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.model.Guest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterActivity extends AppCompatActivity {
    EditText edtgname, edtgpass;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edtgname = findViewById(R.id.edtgname);
        edtgpass = findViewById(R.id.edtgpass);
    }

    public void register(View view) {
        final String username = edtgname.getText().toString();
        final String password = edtgpass.getText().toString();
        if (username.equals("") || password.equals("")) {
            Toast.makeText(this, "No Empty!!!", Toast.LENGTH_SHORT).show();
        } else {
            reference = FirebaseDatabase.getInstance().getReference("Guest").child(username);
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue() == null) {
                        Guest guest = new Guest();
                        guest.username = username;
                        guest.password = password;

                        reference.setValue(guest, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                Toast.makeText(RegisterActivity.this, "Register Succeed", Toast.LENGTH_SHORT).show();
                                edtgname.setText("");
                                edtgpass.setText("");
                            }
                        });
                    } else {
                        Toast.makeText(RegisterActivity.this, "Username existed", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

    }

    public void back(View view) {
        finish();
    }
}
