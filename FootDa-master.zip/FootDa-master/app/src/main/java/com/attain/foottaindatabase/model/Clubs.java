package com.attain.foottaindatabase.model;

public class Clubs {
    public String leagueName;
    public String clubName;
    public String nickname;
    public int foundationYear;
    public String clubLogo;

    public Clubs() {

    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        leagueName = leagueName;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getFoundationYear() {
        return foundationYear;
    }

    public void setFoundationYear(int foundationYear) {
        this.foundationYear = foundationYear;
    }

    public String getClubLogo() {
        return clubLogo;
    }

    public void setClubLogo(String clubLogo) {
        this.clubLogo = clubLogo;
    }

    public Clubs(String leagueName, String clubName, String nickname, int foundationYear, String clubLogo) {
        leagueName = leagueName;
        this.clubName = clubName;
        this.nickname = nickname;
        this.foundationYear = foundationYear;
        this.clubLogo = clubLogo;
    }
}
