package com.attain.foottaindatabase.adapter.Basic;

public class ClubAdapter {
}
