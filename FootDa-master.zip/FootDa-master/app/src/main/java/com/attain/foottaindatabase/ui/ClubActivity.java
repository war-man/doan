package com.attain.foottaindatabase.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.attain.foottaindatabase.R;

public class ClubActivity extends AppCompatActivity {
    RecyclerView rvClub;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club);
        rvClub=findViewById(R.id.rvClub);
    }
}
