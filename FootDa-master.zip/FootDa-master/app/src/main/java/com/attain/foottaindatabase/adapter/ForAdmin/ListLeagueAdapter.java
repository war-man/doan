package com.attain.foottaindatabase.adapter.ForAdmin;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.attain.foottaindatabase.R;
import com.attain.foottaindatabase.model.Clubs;
import com.attain.foottaindatabase.model.Leagues;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class ListLeagueAdapter extends RecyclerView.Adapter<ListLeagueAdapter.ViewHolder> {
    Context context;
    List<Leagues> leaguesList;
    DatabaseReference refLeagues, refClubs;

    public ListLeagueAdapter(Context context, List<Leagues> leaguesList) {
        this.context = context;
        this.leaguesList = leaguesList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_list_admin, parent, false);
        return new ListLeagueAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.tvList.setText(leaguesList.get(position).leagueName);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view1 = LayoutInflater.from(context).inflate(R.layout.dialog_add_clubs, null);
                builder.setView(view1);
                builder.setTitle("Add Clubs");
                final EditText leagueName = view1.findViewById(R.id.edtLName);
                final EditText clubName = view1.findViewById(R.id.edtCName);
                final EditText clubNickName = view1.findViewById(R.id.edtCNickname);
                final EditText foundationYear = view1.findViewById(R.id.edtFoundY);

                leagueName.setText(leaguesList.get(position).leagueName);
                final String league = leaguesList.get(position).leagueName;
                Button btnAdd = view1.findViewById(R.id.btnAdd);

                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (clubName.getText().toString().equals("") || foundationYear.getText().toString().equals("")) {
                            Toast.makeText(context, "NO EMPTY", Toast.LENGTH_SHORT).show();
                        } else {
                            refLeagues = FirebaseDatabase.getInstance().getReference("Leagues").
                                    child(league).child("Clubs").
                                    child(clubName.getText().toString());
                            refClubs = FirebaseDatabase.getInstance().getReference("Clubs").child(clubName.getText().toString());
                            refLeagues.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() == null) {
                                        Clubs clubs = new Clubs();
                                        clubs.leagueName = league;
                                        clubs.clubName = clubName.getText().toString();
                                        clubs.nickname = clubNickName.getText().toString();
                                        clubs.clubLogo = "";
                                        clubs.foundationYear = Integer.parseInt(foundationYear.getText().toString());
                                        refLeagues.setValue(clubs, new DatabaseReference.CompletionListener() {
                                            @Override
                                            public void onComplete(@Nullable DatabaseError databaseError,
                                                                   @NonNull DatabaseReference databaseReference) {
                                                Toast.makeText(context, "Create Succeed", Toast.LENGTH_SHORT).show();
                                                clubName.setText("");
                                                clubNickName.setText("");
                                                foundationYear.setText("");
                                            }
                                        });
                                    } else {
                                        Toast.makeText(context, "Club Existed", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                }
                            });
                            refClubs.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.getValue() == null) {
                                        Clubs clubs = new Clubs();
                                        clubs.leagueName = league;
                                        clubs.clubName = clubName.getText().toString();
                                        clubs.nickname = clubNickName.getText().toString();
                                        clubs.clubLogo = "";
                                        clubs.foundationYear = Integer.parseInt(foundationYear.getText().toString());
                                        refClubs.setValue(clubs, new DatabaseReference.CompletionListener() {
                                            @Override
                                            public void onComplete(@Nullable DatabaseError databaseError,
                                                                   @NonNull DatabaseReference databaseReference) {
                                                Toast.makeText(context, "Create Succeed", Toast.LENGTH_SHORT).show();
                                                clubName.setText("");
                                                clubNickName.setText("");
                                                foundationYear.setText("");
                                            }
                                        });
                                    } else {
                                        Toast.makeText(context, "Club Existed", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }
                });
                builder.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return 5;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvList;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvList = itemView.findViewById(R.id.tvList);

        }
    }
}
