package com.nip.newspaper.core.paser;

import com.nip.newspaper.core.base.ArticleDetailBase;

/**
 * Created by nguyenminhthang on 6/13/15.
 */
public abstract class ArticleParserHtml<E extends ArticleDetailBase> extends  ParserHtmlBase<E> {
}
