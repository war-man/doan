package com.nip.newspaper.core;

/**
 * Created by nguyenminhthang on 5/30/15.
 */
public interface IArticleClick {
    void clickArticle(String link);
}
