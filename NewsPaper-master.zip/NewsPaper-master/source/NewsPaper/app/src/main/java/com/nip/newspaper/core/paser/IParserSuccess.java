package com.nip.newspaper.core.paser;

/**
 * Created by Esoft on 5/30/2015.
 */
public interface IParserSuccess<T> {

    void succes(T value);
}
