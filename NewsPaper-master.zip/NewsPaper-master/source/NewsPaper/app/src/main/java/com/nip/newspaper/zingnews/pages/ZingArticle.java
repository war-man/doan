package com.nip.newspaper.zingnews.pages;

import com.nip.newspaper.core.base.ArticleBase;

/**
 * Created by Esoft on 5/29/2015.
 */
public class ZingArticle extends ArticleBase {
}
