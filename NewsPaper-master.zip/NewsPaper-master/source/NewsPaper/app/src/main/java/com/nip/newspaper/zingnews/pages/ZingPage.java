package com.nip.newspaper.zingnews.pages;

import com.nip.newspaper.core.base.PageBase;

/**
 * Created by Esoft on 5/29/2015.
 */
public class ZingPage extends PageBase {
}
