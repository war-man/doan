package com.nip.newspaper.zingnews.pages;

import com.nip.newspaper.core.base.ContentBase;

/**
 * Created by Esoft on 5/29/2015.
 */
public class ZingContent extends ContentBase{
}
