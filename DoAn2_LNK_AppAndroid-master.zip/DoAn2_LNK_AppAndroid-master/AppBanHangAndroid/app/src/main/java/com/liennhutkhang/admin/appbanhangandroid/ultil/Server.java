package com.liennhutkhang.admin.appbanhangandroid.ultil;

/**
 * Created by Nhut Khang on 09/04/2018.
 */

public class Server {
    public static String localhost = "192.168.14.2:81";
    public static String path = "http://" + localhost + "/Dulieudoan2/loaisanpham.php";
    public static String pathNew = "http://" + localhost + "/Dulieudoan2/getsanphammoinhat.php";
    public static String pathPhone = "http://" + localhost + "/dulieudoan2/getsanphamdienthoai.php?page=";
    public static String pathLaptop = "http://" + localhost + "/Dulieudoan2/getsanphamlaptop.php?page=";
    public static String pathOrder = "http://" + localhost + "/Dulieudoan2/thongtinkhachhang.php";
    public static String pathOrderDetail = "http://" + localhost + "/Dulieudoan2/chitietdonhang.php";
}
