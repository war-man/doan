package com.example.myapplication.De_Thi;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.myapplication.models1.Question;

import java.util.ArrayList;

public class AdapterQuestion extends FragmentPagerAdapter {
    final int PAGE_COUNT = 3;
    private ArrayList<Question> _list;
    public AdapterQuestion(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        return QuestionFragment.newInstance(i+1);
    }

    @Override
    public int getCount() {
        return _list.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String tt;
        if(_list.get(position).qId <=9){
            tt = String.valueOf(_list.get(position).qId);
        }else {
            tt = String.valueOf(_list.get(position).qId+"    ");
        }
        tt = String.valueOf(_list.get(position).qId+"    ");
        return tt;
    }
}
