package com.example.myapplication.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.myapplication.models1.Question;
import com.example.myapplication.models1.QuestionExam;

import java.util.List;

@Dao
public interface QuestionExamDao {
    @Query("SELECT * FROM question " +
            "INNER JOIN QuestionExam " +
            "ON question.qId= questionId " +
            "WHERE examId = :eId")
    List<Question> getQuestionInExam(int eId);


    @Insert
    void insertAll(QuestionExam... questionExams);

    @Delete
    void delete(QuestionExam questionExam);
}
