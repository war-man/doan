package com.example.myapplication.models1;


import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;

@Entity(primaryKeys = {"examId","questionId"},
        foreignKeys = {
                @ForeignKey(entity = Question.class,
                        parentColumns = "qId",
                        childColumns = "questionId"),
                @ForeignKey(entity = Exam.class,
                        parentColumns = "id",
                        childColumns = "examId")})
public class QuestionExam {
    public int examId;
    public int questionId;

    public QuestionExam(int examId, int questionId) {
        this.examId = examId;
        this.questionId = questionId;
    }

}
