package com.example.myapplication.De_Thi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.models1.QuestionDetail;

import java.util.ArrayList;

public class AdapterDapAn extends BaseAdapter {
   private Context context;
   private ArrayList<QuestionDetail>_list;

    public AdapterDapAn(Context context, ArrayList<QuestionDetail> _list) {
        this.context = context;
        this._list = _list;
    }

    @Override
    public int getCount() {
        return _list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        QuestionDetail da= _list.get(position);
        AdapterDapAn.ViewHolder viewHolder;
//        if(_list.get(position).getMach()==1){
            if(convertView==null){
                final LayoutInflater layoutInflater = LayoutInflater.from(context);
                convertView = layoutInflater.inflate(R.layout.item_dapan, null);
                viewHolder= new AdapterDapAn.ViewHolder();
                viewHolder.btnLuaChon= (Button)convertView.findViewById(R.id.btnLuachonD);
                viewHolder.txtNoiDungDA=(TextView)convertView.findViewById(R.id.txtNoidungDA);
                convertView.setTag(viewHolder);

            } else {
                viewHolder= (AdapterDapAn.ViewHolder)convertView.getTag();
            }
                int id =da.optionId;
                viewHolder.txtNoiDungDA.setText(da.optContent+" : "+da.questionId);
                if(id==1){
                    viewHolder.btnLuaChon.setText("A");
                }else if(id==2){
                    viewHolder.btnLuaChon.setText("B");
                }else if(id==3){
                    viewHolder.btnLuaChon.setText("C");
                }else if(id==4){
                    viewHolder.btnLuaChon.setText("D");
                }

//        }

        return convertView;
    }
    private class   ViewHolder{
        TextView txtNoiDungDA;
        Button btnLuaChon;
    }
}
