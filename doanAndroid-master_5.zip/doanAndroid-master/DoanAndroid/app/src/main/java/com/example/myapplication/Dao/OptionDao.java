package com.example.myapplication.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.myapplication.models1.Option;

import java.util.List;

@Dao
public interface OptionDao {
    @Query("SELECT * FROM option")
    List<Option> getAll();

    @Query("SELECT *FROM option WHERE optId IN (:optIds)")
    List<Option> findById(int[] optIds);

    @Insert
    void insertAll(Option... options);

    @Delete
    void delete(Option options);
}
