package com.example.myapplication.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.myapplication.models1.Exam;

import java.util.List;

@Dao
public interface ExamDao {
    @Query("SELECT *FROM Exam")
    List<Exam> getAll();

    @Query("SELECT *FROM Exam " +
            "WHERE id IN (:eIds)")
    List<Exam> findById(int[] eIds);

    @Insert
    void insertAll(Exam... exams);

    @Delete
    void delete(Exam exam);
}
