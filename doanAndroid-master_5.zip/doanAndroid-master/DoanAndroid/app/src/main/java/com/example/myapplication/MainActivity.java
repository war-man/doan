package com.example.myapplication;

import android.arch.persistence.room.Room;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.myapplication.De_Thi.AdapterBoDe;
import com.example.myapplication.models1.AppDatabase;
import com.example.myapplication.models1.Exam;

public class MainActivity extends AppCompatActivity {

    public static AppDatabase db;

    private Exam[] _list;
    AdapterBoDe adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.rcvBoDe);

        db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "AppDatabase").allowMainThreadQueries().build();

        if(db.examDao().getAll().size() == 0){
            Exam[] exams = new Exam[]{
                    new Exam(1,"đề 1",60,null),
                    new Exam(2,"đề 2",60,null),
                    new Exam(3,"đề 3",60,null),
                    new Exam(4,"đề 4",60,null),
                    new Exam(5,"đề 5",60,null),
                    new Exam(6,"đề 6",60,null),
            };

            db.examDao().insertAll(exams);
        }

        _list = db.examDao().getAll().toArray(new Exam[0]);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdapterBoDe(_list,this);
        recyclerView.setAdapter(adapter);
    }
}