package com.example.myapplication.models1;


import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;

@Entity(primaryKeys = {"questionId","optionId"},
        foreignKeys = {
                @ForeignKey(entity = Question.class,
                        parentColumns = "qId",
                        childColumns = "questionId"),
                @ForeignKey(entity = Option.class,
                        parentColumns = "optId",
                        childColumns = "optionId")
        })
public class QuestionDetail {
    public int questionId;
    public int optionId;
    public String optContent;
    public boolean isAnswer;

    public QuestionDetail(int questionId, int optionId, String optContent, boolean isAnswer) {
        this.questionId = questionId;
        this.optionId = optionId;
        this.optContent = optContent;
        this.isAnswer = isAnswer;
    }
}
