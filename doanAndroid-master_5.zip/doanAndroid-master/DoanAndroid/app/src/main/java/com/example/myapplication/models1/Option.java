package com.example.myapplication.models1;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class Option {
    @PrimaryKey
    public int optId;

    public String optName;

    public Option(int optId, String optName) {
        this.optId = optId;
        this.optName = optName;
    }
}
