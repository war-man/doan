package com.example.myapplication;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View v, int pos);
}
