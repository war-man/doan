package com.example.myapplication.models1;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import static java.sql.Types.BLOB;

@Entity
public class Question {
    @PrimaryKey
    public int qId;
    public String content;
    @ColumnInfo(typeAffinity = BLOB)
    public String image;

    public Question(){
    }

    public Question(String content, String image) {
        this.content = content;
        this.image = image;
    }
}
