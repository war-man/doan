package com.example.myapplication.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.myapplication.models1.Question;

import java.util.List;

@Dao
public interface QuestionDao {
    @Query("SELECT *FROM question")
    List<Question> getAll();

    @Query("SELECT * FROM question WHERE qId IN(:questionIds)")
    List<Question> findById(int[] questionIds);

    @Insert
    void insertAll(Question... questions);

    @Delete
    void delete(Question question);
}
