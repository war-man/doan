package com.example.myapplication.De_Thi;


        import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
        import android.util.Log;
        import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

        import com.android.volley.Request;
        import com.android.volley.RequestQueue;
        import com.android.volley.Response;
        import com.android.volley.VolleyError;
        import com.android.volley.toolbox.ImageLoader;
        import com.android.volley.toolbox.JsonArrayRequest;
        import com.android.volley.toolbox.Volley;
        import com.example.myapplication.ItemClickListener;
import com.example.myapplication.LayoutThiActivity;
import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.models1.Exam;
        import com.example.myapplication.models1.Option;
        import com.example.myapplication.models1.Question;
        import com.example.myapplication.models1.QuestionDetail;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

public class AdapterBoDe extends RecyclerView.Adapter<AdapterBoDe.BoDeHolder> {
    View v;
    Exam[] _mBode;
    Context context;
    Question[] questions;
    QuestionDetail[] options;

    public AdapterBoDe(Exam[] _mBode, Context context) {
        this._mBode = _mBode;
        this.context = context;
    }

    @NonNull
    @Override
    public BoDeHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        v= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bodethi, viewGroup, false);
        return new AdapterBoDe.BoDeHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BoDeHolder boDeHolder, final int i) {
        _mBode = MainActivity.db.examDao().getAll().toArray(new Exam[0]);
        boDeHolder.txtNameBode.setText(_mBode[i].name);
        boDeHolder.btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAPI();

                MainActivity.db.questionDao().insertAll(questions);
                MainActivity.db.questionDetailDao().insertAll(options);

//                Toast.makeText(context, "đang tải nè" + _mBode[i].id + _mBode[i].name, Toast.LENGTH_SHORT).show();
            }
        });
        boDeHolder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClick(View v, int pos) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Thông báo");
                builder.setMessage("Bạn có muốn thi đề này không");
                builder.setCancelable(true);
                builder.setPositiveButton("Có", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(context, LayoutThiActivity.class);
                                intent.putExtra("mabode",_mBode[i].id);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                context.startActivity(intent);
                            }
                        })
                        .setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }

    private void getAPI() {
        RequestQueue queue= Volley.newRequestQueue(context);
        String url = "http://192.168.43.82/examserver/api/de_thi/1";
        JsonArrayRequest jsonArrayRequest= new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0 ; i<=response.length();i++){
                            try {
                                JSONObject objectRequest= response.getJSONObject(i);

                            questions= new Question[]{};
                                int mach= objectRequest.getInt("Ma_CH");
                                questions[i].qId=mach;
                                questions[i].content=objectRequest.getString("NOI_DUNG_CH");
                                String ch= objectRequest.getString("HINH_ANH_CH");

                                JSONArray jsonArray=objectRequest.getJSONArray("luachon");
                                for (int j=0;j<jsonArray.length();j++){
                                    JSONObject object = jsonArray.getJSONObject(j);
                                    options= new QuestionDetail[]{};
                                    options[j].optionId=object.getInt("MA_LC");
                                    options[j].optContent=object.getString("NOI_DUNG_LC");
                                    options[j].isAnswer=object.getBoolean("LA_DAP_AN");
                                    options[j].questionId=mach;

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }


                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("PointFragment", "onErrorResponse: "+error);
                    }
                });
        queue.add(jsonArrayRequest);

    }

    @Override
    public int getItemCount() {
        return _mBode.length;
    }

    class BoDeHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private ImageView imgAvatar;
        private TextView txtNameBode,txtSoLanThi;
        private ItemClickListener itemClickListener;
        private ImageButton btnLoad;
        private ConstraintLayout item_Bode;


        public BoDeHolder(@NonNull View itemView) {
            super(itemView);
            imgAvatar= (ImageView) itemView.findViewById(R.id.AvatarBode);
            txtNameBode=(TextView) itemView.findViewById(R.id.txtNameBode);
            item_Bode=(ConstraintLayout)itemView.findViewById(R.id.item_bode);
            btnLoad=(ImageButton)itemView.findViewById(R.id.imageButton);

            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            this.itemClickListener.onItemClick(v, getLayoutPosition());
        }
        public void setItemClickListener(ItemClickListener ic) {
            this.itemClickListener = ic;
        }
    }
}
