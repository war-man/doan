package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.widget.TextView;

import com.astuetz.PagerSlidingTabStrip;
import com.example.myapplication.De_Thi.AdapterQuestion;

public class LayoutThiActivity extends AppCompatActivity {
    private ViewPager viewPager;
//    private FloatingActionButton fab;
    private TextView tvPhut, tvGiay;
    private int giay=0;
    private int phut ;
    public static int made;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_thi);
        findviewbyid();
        viewPager.setAdapter(new AdapterQuestion(getSupportFragmentManager()));
        final int pageMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 4, getResources()
                .getDisplayMetrics());
        viewPager.setPageMargin(pageMargin);

        PagerSlidingTabStrip tabsStrip = (PagerSlidingTabStrip) findViewById(R.id.tabs);
        tabsStrip.getTextSize();

        tabsStrip.setViewPager(viewPager);
        Intent intent=getIntent();
        made=intent.getIntExtra("mabode",-1);
        showDialogNotification();
    }

    private void showDialogNotification() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thông báo");
        builder.setMessage("Bạn đã sẳn sàng thi chưa");
        builder.setCancelable(true);
        builder.setPositiveButton("Sẳn Sàng", new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        countTime();
                    }
                })
                .setNegativeButton("Quay Lại", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void countTime() {
        phut= 60;
        CountDownTimer countDownTimer= new CountDownTimer((phut*60*1000),1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                tvGiay.setText(phut+":"+giay);
                giay--;
                if(giay<=0){
                    giay=59;
                    phut =phut-1;
                }
            }
            @Override
            public void onFinish() {

            }
        };
        countDownTimer.start();
    }


    private void findviewbyid() {
//        recyclerView = (RecyclerView) findViewById(R.id.rcvCauHoi);
        tvGiay=(TextView)findViewById(R.id.tvtime);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
    }
}