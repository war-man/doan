package com.example.myapplication.De_Thi;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Picture;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.models1.AppDatabase;
import com.example.myapplication.models1.Question;
import com.example.myapplication.models1.QuestionDetail;
import com.example.myapplication.models1.QuestionExam;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import static com.example.myapplication.LayoutThiActivity.made;

/**
 * A simple {@link Fragment} subclass.
 */
public class QuestionFragment extends Fragment {

    public static AppDatabase db;
    private TextView txtCauHoi,txtNoiDung;
    private ImageView imgHinhAnh;
    private ListView lvDapAn;
    private ArrayList<QuestionExam> _listQuestion;
    private ArrayList<Question>_listCauHoi;
    private ArrayList<QuestionDetail>_listOption;
    private AdapterDapAn item;
    public static final String ARG_PAGE = "ARG_PAGE";
    private View v;
    private int mPage;

    public static QuestionFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        QuestionFragment fragment = new QuestionFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_question, container, false);
        findviewbyid();
        even();
        return v;
    }

    private void even() {
        _listCauHoi = new ArrayList<>(db.questionExamDao().getQuestionInExam(made));
        Question ch = _listCauHoi.get(mPage-1);
        txtCauHoi.setText("Câu :"+_listCauHoi.get(mPage-1).qId);
        txtNoiDung.setText(_listCauHoi.get(mPage-1).content);

        Picasso.with(getContext()).load(_listCauHoi.get(mPage-1).image).fit().centerInside().into(imgHinhAnh);

        _listOption = new ArrayList<>(db.questionDetailDao().findByQuestionId(mPage-1));

        ArrayList<QuestionDetail> mList = new ArrayList<>();
        for (int i=0; i<_listOption.size();i++){
            if(_listOption.get(i).questionId == _listCauHoi.get(mPage-1).qId){
                mList.add(new QuestionDetail(_listOption.get(i).questionId,_listOption.get(i).optionId, _listOption.get(i).optContent,_listOption.get(i).isAnswer));
                item = new AdapterDapAn(getContext(), mList);
                lvDapAn.setAdapter(item);
            }
        }
    }

    private void findviewbyid() {
        txtCauHoi=(TextView) v.findViewById(R.id.txtCauHoi);
        txtNoiDung =(TextView)v.findViewById(R.id.txtNoiDung);
        lvDapAn=(ListView) v.findViewById(R.id.lvDapAn);
        imgHinhAnh =(ImageView)v.findViewById(R.id.imgHInhAnh);
    }

}
