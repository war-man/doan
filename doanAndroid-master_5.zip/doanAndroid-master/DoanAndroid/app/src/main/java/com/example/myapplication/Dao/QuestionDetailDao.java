package com.example.myapplication.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.myapplication.models1.QuestionDetail;

import java.util.List;

@Dao
public interface QuestionDetailDao {
    @Query("SELECT *FROM questiondetail " +
            "WHERE questionId = (:qIds)")
    List<QuestionDetail> findByQuestionId(int qIds);

    @Insert
    void insertAll(QuestionDetail... questionDetails);
    @Delete
    void delete(QuestionDetail questionDetail);
}
