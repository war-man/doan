package com.lavanphat.doanchuyennganh.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lavanphat.doanchuyennganh.CartActivity;
import com.lavanphat.doanchuyennganh.ListProductActivity;
import com.lavanphat.doanchuyennganh.Model.BrandModel;
import com.lavanphat.doanchuyennganh.R;
import com.lavanphat.doanchuyennganh.SQLite.DAO.CartDAO;
import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    ArrayList<CartDTO> cate;
    Context context;
    TextView txtTotal;


    public CartAdapter(ArrayList<CartDTO> cate, Context context) {
        this.cate = cate;
        this.context = context;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_cart_recyclerview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //gán dữ liệu vào item category
        holder.txtNameProduct.setText(cate.get(position).getName());
        int price = cate.get(position).getPrice();
        holder.txtPriceProduct.setText(NumberFormat.getNumberInstance(Locale.US).format(price) + " Đ");
        holder.txtQuality.setText(cate.get(position).getQuality() + "");
        Glide.with(context).load(cate.get(position).getImage()).into(holder.imgImage);
    }

    @Override
    public int getItemCount() {
        //trả về số lượng phần tử trong araylist
        return cate.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //find id những gì đã tạo ở layout item category
        ImageView imgImage;
        TextView txtNameProduct, txtPriceProduct, txtQuality, txtEdit;
        Button btnMinus, btnAdd;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            imgImage = itemView.findViewById(R.id.imgImage);
            txtNameProduct = itemView.findViewById(R.id.txtNameProduct);
            txtPriceProduct = itemView.findViewById(R.id.txtPriceProduct);
            txtQuality = itemView.findViewById(R.id.txtQuality);
            txtEdit = itemView.findViewById(R.id.txtEdit);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnAdd = itemView.findViewById(R.id.btnAdd);

            btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int quality = Integer.parseInt(txtQuality.getText().toString());
                    quality++;

                    updateQuality(quality);

                    int total = 0;
                    for (CartDTO cartDTO : cate) {
                        if (cate.get(getAdapterPosition()).getSlug().equals(cartDTO.getSlug())) {
                            total += cartDTO.getPrice() * quality;
                            cate.get(getAdapterPosition()).setQuality(quality);
                        } else {
                            total += cartDTO.getPrice() * cartDTO.getQuality();
                        }
                    }
                    CartActivity.txtTotal.setText(NumberFormat.getNumberInstance(Locale.US).format(total) + " Đ");
                }
            });

            btnMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int quality = Integer.parseInt(txtQuality.getText().toString());
                    quality--;

                    updateQuality(quality);
                    int total = 0;
                    for (CartDTO cartDTO : cate) {
                        if (cate.get(getAdapterPosition()).getSlug().equals(cartDTO.getSlug())) {
                            total -= cartDTO.getPrice() * quality;
                            cate.get(getAdapterPosition()).setQuality(quality);
                        } else {
                            total -= cartDTO.getPrice() * cartDTO.getQuality();
                        }
                    }
                    total = -total;
                    CartActivity.txtTotal.setText(NumberFormat.getNumberInstance(Locale.US).format(total) + " Đ");
                }
            });

            txtEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    CartDTO cartDTO = new CartDTO();
                    cartDTO.setSlug(cate.get(getAdapterPosition()).getSlug());

                    CartDAO cartDAO = new CartDAO(context);
                    cartDAO.open();

                    cartDAO.deleteCart(cartDTO);
                    cartDAO.close();

                    cate.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());

                    int total=0;
                    for (CartDTO dto : cate) {
                        total+=dto.getPrice()*dto.getQuality();
                    }
                    CartActivity.txtTotal.setText(NumberFormat.getNumberInstance(Locale.US).format(total) + " Đ");

                    Toast.makeText(context, "Đã xóa sản phẩm !!!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void updateQuality(int quality) {
            CartDTO cartDTO = new CartDTO();
            cartDTO.setQuality(quality);

            CartDAO cartDAO = new CartDAO(context);
            cartDAO.open();

            cartDAO.updateCart(cate.get(getAdapterPosition()).getSlug(), cartDTO);
            txtQuality.setText(quality + "");
            cartDAO.close();
        }
    }
}
