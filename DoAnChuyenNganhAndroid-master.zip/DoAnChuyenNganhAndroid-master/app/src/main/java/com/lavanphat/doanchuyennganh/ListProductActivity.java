package com.lavanphat.doanchuyennganh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.lavanphat.doanchuyennganh.Adapter.FeaturedAdapter;
import com.lavanphat.doanchuyennganh.Model.BrandModel;
import com.lavanphat.doanchuyennganh.Model.CategoryModel;
import com.lavanphat.doanchuyennganh.Model.FeaturedModel;
import com.lavanphat.doanchuyennganh.Model.ImageProduct;
import com.lavanphat.doanchuyennganh.Retrofit.ApiCilent;
import com.lavanphat.doanchuyennganh.Retrofit.ApiInterface;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListProductActivity extends AppCompatActivity {
    String TAG = "ListProductActivity";
    Toolbar toolbar;
    MaterialSearchView search;
    TextView txtListName;

    ApiInterface apiInterface;

    RecyclerView rcvListProduct;
    FeaturedAdapter featuredAdapter;

    CategoryModel categoryModel;
    BrandModel brandModel;

    List<FeaturedModel> featuredModelList;
    List<ImageProduct> imageProductList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_product);

        addControl();
        addEvent();
    }

    private void addEvent() {

    }

    private void addControl() {
        toolbar = findViewById(R.id.toolbar);
        search = findViewById(R.id.search);
        rcvListProduct = findViewById(R.id.rcvListProduct);
        txtListName = findViewById(R.id.txtNameList);

        //hiển thị toolbar
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //màu chữ cho toolbar
        toolbar.setTitleTextColor(Color.parseColor("#FF000000"));

        //kết nối tới server
        apiInterface = ApiCilent.getApiCilent().create(ApiInterface.class);
        //lấy dữ liệu list sản phẩm
        Intent intent = getIntent();
        String slugCategory = intent.getStringExtra("slugCategory");
        String titleCategory = intent.getStringExtra("titleCategory");
        String slugBrand = intent.getStringExtra("slugBrand");
        String titleBrand = intent.getStringExtra("titleBrand");
        if (titleCategory != null && slugCategory != null) {
            getListProductCategory(slugCategory, titleCategory);
        } else {
            getListProductBrand(slugBrand, titleBrand);
        }
    }

    private void getListProductBrand(String slug, String title) {
        txtListName.setText("Sản phẩm theo " + title);
        Call<BrandModel> call = apiInterface.getBrandProduct(slug);
        call.enqueue(new Callback<BrandModel>() {
            @Override
            public void onResponse(Call<BrandModel> call, Response<BrandModel> response) {
                brandModel = response.body();
                featuredModelList = brandModel.getProduct();
                for (int i = 0; i < featuredModelList.size(); i++) {
                    imageProductList = featuredModelList.get(i).getImageProduct();
                }
                featuredAdapter = new FeaturedAdapter((ArrayList<FeaturedModel>) featuredModelList, getApplication());
                GridLayoutManager layoutManager = new GridLayoutManager(getApplication(), 2);
//                layoutManager.setStackFromEnd(true);
                rcvListProduct.setHasFixedSize(true);
                rcvListProduct.setLayoutManager(layoutManager);
                rcvListProduct.setAdapter(featuredAdapter);
            }

            @Override
            public void onFailure(Call<BrandModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getListProductCategory(String slug, String title) {
        txtListName.setText("Sản phẩm theo " + title);
        Call<CategoryModel> call = apiInterface.getListProduct(slug);
        call.enqueue(new Callback<CategoryModel>() {
            @Override
            public void onResponse(Call<CategoryModel> call, Response<CategoryModel> response) {
                categoryModel = response.body();
                featuredModelList = categoryModel.getProduct();
                for (int i = 0; i < featuredModelList.size(); i++) {
                    imageProductList = featuredModelList.get(i).getImageProduct();
                }

                featuredAdapter = new FeaturedAdapter((ArrayList<FeaturedModel>) featuredModelList, getApplication());
                GridLayoutManager layoutManager = new GridLayoutManager(getApplication(), 2);
//                layoutManager.setStackFromEnd(true);
                rcvListProduct.setHasFixedSize(true);
                rcvListProduct.setLayoutManager(layoutManager);
                rcvListProduct.setAdapter(featuredAdapter);
            }

            @Override
            public void onFailure(Call<CategoryModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        search.setMenuItem(menuItem);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent intent = new Intent(getApplication(), CartActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}
