package com.lavanphat.doanchuyennganh.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.lavanphat.doanchuyennganh.CartActivity;
import com.lavanphat.doanchuyennganh.R;
import com.lavanphat.doanchuyennganh.SQLite.DAO.CartDAO;
import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class ProductPayAdapter extends RecyclerView.Adapter<ProductPayAdapter.ViewHolder> {
    ArrayList<CartDTO> cate;
    Context context;


    public ProductPayAdapter(ArrayList<CartDTO> cate, Context context) {
        this.cate = cate;
        this.context = context;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_pay_recyclerview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //gán dữ liệu vào item category
        holder.txtNameProduct.setText(cate.get(position).getName());
        int price = cate.get(position).getPrice();
        holder.txtPriceProduct.setText(NumberFormat.getNumberInstance(Locale.US).format(price) + " Đ");
        holder.txtQuality.setText(cate.get(position).getQuality() + "");
        Glide.with(context).load(cate.get(position).getImage()).into(holder.imgImage);
    }

    @Override
    public int getItemCount() {
        //trả về số lượng phần tử trong araylist
        return cate.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //find id những gì đã tạo ở layout item category
        ImageView imgImage;
        TextView txtNameProduct, txtPriceProduct, txtQuality;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            imgImage = itemView.findViewById(R.id.imgImage);
            txtNameProduct = itemView.findViewById(R.id.txtNameProduct);
            txtPriceProduct = itemView.findViewById(R.id.txtPriceProduct);
            txtQuality = itemView.findViewById(R.id.txtQuality);
        }
    }
}