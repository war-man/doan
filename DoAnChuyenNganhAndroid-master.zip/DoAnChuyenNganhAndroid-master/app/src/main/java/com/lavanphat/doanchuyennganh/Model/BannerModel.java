package com.lavanphat.doanchuyennganh.Model;

public class BannerModel {
    private String id,image,number;

    public BannerModel() {
    }

    @Override
    public String toString() {
        return "id='" + id + '\n' +
                "image='" + image + '\n' +
                "number='" + number + '\n';
    }

    public BannerModel(String id, String image, String number) {
        this.id = id;
        this.image = image;
        this.number = number;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
