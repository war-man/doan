package com.lavanphat.doanchuyennganh.SQLite.DTO;

public class CartDTO {
    private int id,quality,price;
    private String name,slug,image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuality() {
        return quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public CartDTO() {
    }

    public CartDTO(int id, int quality, int price, String name, String slug, String image) {
        this.id = id;
        this.quality = quality;
        this.price = price;
        this.name = name;
        this.slug = slug;
        this.image = image;
    }
}
