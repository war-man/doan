package com.lavanphat.doanchuyennganh.SQLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class OilDatabase extends SQLiteOpenHelper {
    public static final String DB = "OilDatabase";
    public static final int DB_VERSION = 1;

    //table Cart
    public static final String CART= "Cart";
    public static final String CART_ID= "id";
    public static final String CART_NAME= "name_product";
    public static final String CART_SLUG= "slug_product";
    public static final String CART_IMAGE= "image_product";
    public static final String CART_QUALITY= "quality";
    public static final String CART_PRICE= "price";


    public OilDatabase(@Nullable Context context) {
        super(context, DB, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
            String createTableCart = "CREATE TABLE IF NOT EXISTS Cart (" +
                    "    id integer PRIMARY KEY AUTOINCREMENT," +
                    "    name_product text ," +
                    "    slug_product text ," +
                    "    image_product text ," +
                    "    quality integer ," +
                    "    price integer " +
                    ");";
        sqLiteDatabase.execSQL(createTableCart);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Cart");
        onCreate(sqLiteDatabase);
    }
}
