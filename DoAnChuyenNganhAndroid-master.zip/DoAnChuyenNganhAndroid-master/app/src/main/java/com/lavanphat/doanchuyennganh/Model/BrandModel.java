package com.lavanphat.doanchuyennganh.Model;

import android.graphics.Bitmap;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BrandModel {
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("Image_URL")
    @Expose
    private String Image_URL;
    @SerializedName("product")
    @Expose
    private List<FeaturedModel> product = null;

    public BrandModel() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<FeaturedModel> getProduct() {
        return product;
    }

    public void setProduct(List<FeaturedModel> product) {
        this.product = product;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public BrandModel(String title, String slug, String image_URL, List<FeaturedModel> product) {
        this.title = title;
        this.slug = slug;
        Image_URL = image_URL;
        this.product = product;
    }

    public String getImage_URL() {
        return Image_URL;
    }

    public void setImage_URL(String image_URL) {
        Image_URL = image_URL;
    }
}
