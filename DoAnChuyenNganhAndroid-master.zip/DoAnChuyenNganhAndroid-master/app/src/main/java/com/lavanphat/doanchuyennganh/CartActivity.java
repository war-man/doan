package com.lavanphat.doanchuyennganh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lavanphat.doanchuyennganh.Adapter.CartAdapter;
import com.lavanphat.doanchuyennganh.SQLite.DAO.CartDAO;
import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CartActivity extends AppCompatActivity {
    String TAG = "CartActivity";
    Toolbar toolbar;
    Button btnBuy;
    TextView txtEdit;

    RecyclerView rcvCart;
    List<CartDTO> cartDTOList;
    CartAdapter adapter;

    public static TextView txtTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        addControl();
        addEvent();
    }

    private void addEvent() {
        btnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplication(),PayActivity.class));
            }
        });

    }

    private void addControl() {
        toolbar = findViewById(R.id.toolbar);
        rcvCart = findViewById(R.id.rcvCart);
        txtTotal = findViewById(R.id.txtTotal);
        btnBuy = findViewById(R.id.btnBuy);

        displayToolbar();
        displayItemCart();
    }

    private void displayItemCart() {
        CartDAO cartDAO = new CartDAO(getApplication());
        cartDAO.open();

        cartDTOList = cartDAO.getCart();
        cartDAO.close();

        int total = 0;
        for (CartDTO cartDTO : cartDTOList) {
            total += cartDTO.getPrice() * cartDTO.getQuality();
        }
        txtTotal.setText(NumberFormat.getNumberInstance(Locale.US).format(total) + " Đ");

        adapter = new CartAdapter((ArrayList<CartDTO>) cartDTOList, getApplication());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplication(), LinearLayoutManager.VERTICAL, true);
        layoutManager.setStackFromEnd(true);
        rcvCart.setHasFixedSize(true);
        rcvCart.setLayoutManager(layoutManager);
        rcvCart.setAdapter(adapter);

    }

    private void displayToolbar() {
        //hiển thị toolbar
        setSupportActionBar(toolbar);
        //đặt tiêu đề cho toolbar
        getSupportActionBar().setTitle("Giỏ hàng");
        //màu chữ cho toolbar
        toolbar.setTitleTextColor(Color.parseColor("#FF000000"));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}
