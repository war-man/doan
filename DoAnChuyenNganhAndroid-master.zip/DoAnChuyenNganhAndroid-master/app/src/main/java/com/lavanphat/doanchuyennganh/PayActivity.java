package com.lavanphat.doanchuyennganh;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.lavanphat.doanchuyennganh.Adapter.CartAdapter;
import com.lavanphat.doanchuyennganh.Adapter.ProductPayAdapter;
import com.lavanphat.doanchuyennganh.Model.BillModel;
import com.lavanphat.doanchuyennganh.Model.BillProductModel;
import com.lavanphat.doanchuyennganh.Model.VoucherModel;
import com.lavanphat.doanchuyennganh.Retrofit.ApiCilent;
import com.lavanphat.doanchuyennganh.Retrofit.ApiInterface;
import com.lavanphat.doanchuyennganh.SQLite.DAO.CartDAO;
import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PayActivity extends AppCompatActivity {
    Toolbar toolbar;
    String TAG = "PayActivity";

    RecyclerView rcvProductPay;
    List<CartDTO> cartDTOList;
    ProductPayAdapter adapter;

    TextView txtTotal, txtSale, txtInputSale, txtNameKH, txtPhoneKH, txtAddressKH, txtTotalPay;
    Button btnSale, btnPay;

    ApiInterface apiInterface;
    LinearLayout lnSaleError, lnAddres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        addControl();
        addEvent();
    }

    private void addEvent() {
        btnSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getVoucher();
            }
        });

        lnAddres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setInfoClient();
            }
        });

        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postNewBill();
            }
        });
    }

    private void postNewBill() {
        final BillModel billModel = new BillModel();

        billModel.setTotalMoney(txtTotal.getText().toString());
        billModel.setSale(Integer.parseInt(txtSale.getText().toString()));
        billModel.setAddress(txtAddressKH.getText().toString());
        billModel.setPhone(txtPhoneKH.getText().toString());
        billModel.setActive(true);
        billModel.setStatusBill("processing");

        Call<BillModel> call = apiInterface.postNewBill(billModel);
        call.enqueue(new Callback<BillModel>() {
            @Override
            public void onResponse(Call<BillModel> call, Response<BillModel> response) {
                if (response.isSuccessful()) {

                    BillModel billModel = response.body();

                    for (CartDTO cartDTO : cartDTOList) {
                        BillProductModel billProductModel = new BillProductModel();

                        billProductModel.setBill(billModel.getId());
                        billProductModel.setQuality(cartDTO.getQuality());
                        billProductModel.setProduct(cartDTO.getId());

                        Call<BillProductModel> call1 = apiInterface.postNewBillProduct(billProductModel);
                        call1.enqueue(new Callback<BillProductModel>() {
                            @Override
                            public void onResponse(Call<BillProductModel> call, Response<BillProductModel> response) {
                                if (response.isSuccessful()) {
                                    Log.e(TAG, "onResponse: thanh cong");
                                }
                            }

                            @Override
                            public void onFailure(Call<BillProductModel> call, Throwable t) {
                                Toast.makeText(getApplication(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
                                Log.d(TAG, "onFailure: " + t);
                            }
                        });
                    }
                    startActivity(new Intent(getApplication(), CompletePayActivity.class));
                } else {
                    try {
                        Log.e(TAG, "onResponse: " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<BillModel> call, Throwable t) {
                Toast.makeText(getApplication(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "onFailure: " + t);
            }
        });
        finish();
    }

    private void setInfoClient() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Địa chỉ nhận hàng");

        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.info_client_dialog, null);
        builder.setView(view);

        final EditText txtNameClient = view.findViewById(R.id.txtNameClient);
        final EditText txtPhoneClient = view.findViewById(R.id.txtPhoneClient);
        final EditText txtAddressClient = view.findViewById(R.id.txtAddressClient);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                txtNameKH.setText(txtNameClient.getText().toString());
                txtPhoneKH.setText(txtPhoneClient.getText().toString());
                txtAddressKH.setText(txtAddressClient.getText().toString());
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void getVoucher() {
        Call<List<VoucherModel>> call = apiInterface.getVoucher();
        call.enqueue(new Callback<List<VoucherModel>>() {
            @Override
            public void onResponse(Call<List<VoucherModel>> call, Response<List<VoucherModel>> response) {
                List<VoucherModel> voucherModelList = response.body();
                String voucher = txtInputSale.getText().toString();
                for (VoucherModel voucherModel : voucherModelList) {
                    if (voucher.equals(voucherModel.getCode())) {
                        txtSale.setText("-" + voucherModel.getSale());
                        lnSaleError.setVisibility(View.GONE);

                        int total = Integer.parseInt(txtTotal.getText().toString());
                        int sale = Integer.parseInt(txtSale.getText().toString());
                        txtTotalPay.setText(total + sale+"");
                        break;
                    } else {
                        lnSaleError.setVisibility(View.VISIBLE);
                        txtSale.setText("0");
                    }
                }
            }

            @Override
            public void onFailure(Call<List<VoucherModel>> call, Throwable t) {
                Toast.makeText(getApplication(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addControl() {
        toolbar = findViewById(R.id.toolbar);
        rcvProductPay = findViewById(R.id.rcvProductPay);
        txtTotal = findViewById(R.id.txtTotal);
        txtSale = findViewById(R.id.txtSale);
        txtInputSale = findViewById(R.id.txtInputSale);
        btnSale = findViewById(R.id.btnSale);
        lnSaleError = findViewById(R.id.lnSaleError);
        lnAddres = findViewById(R.id.lnAddres);
        txtNameKH = findViewById(R.id.txtNameKH);
        txtPhoneKH = findViewById(R.id.txtPhoneKH);
        txtAddressKH = findViewById(R.id.txtAddressKH);
        btnPay = findViewById(R.id.btnPay);
        txtTotalPay = findViewById(R.id.txtTotalPay);

        apiInterface = ApiCilent.getApiCilent().create(ApiInterface.class);

        displayToolbar();
        displayProductPay();


    }

    private void displayProductPay() {
        CartDAO cartDAO = new CartDAO(getApplication());
        cartDAO.open();

        cartDTOList = cartDAO.getCart();
        cartDAO.close();

        adapter = new ProductPayAdapter((ArrayList<CartDTO>) cartDTOList, getApplication());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplication(), LinearLayoutManager.VERTICAL, true);
        layoutManager.setStackFromEnd(true);
        rcvProductPay.setHasFixedSize(true);
        rcvProductPay.setLayoutManager(layoutManager);
        rcvProductPay.setAdapter(adapter);

        int total = 0;
        for (CartDTO cartDTO : cartDTOList) {
            total += cartDTO.getPrice() * cartDTO.getQuality();
        }
        txtTotal.setText(total + "");
    }

    private void displayToolbar() {
        //hiển thị toolbar
        setSupportActionBar(toolbar);
        //đặt tiêu đề cho toolbar
        getSupportActionBar().setTitle("Giỏ hàng");
        //màu chữ cho toolbar
        toolbar.setTitleTextColor(Color.parseColor("#FF000000"));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

}
