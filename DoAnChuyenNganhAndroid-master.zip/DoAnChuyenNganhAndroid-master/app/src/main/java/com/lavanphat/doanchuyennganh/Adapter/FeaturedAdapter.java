package com.lavanphat.doanchuyennganh.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.lavanphat.doanchuyennganh.Model.CategoryModel;
import com.lavanphat.doanchuyennganh.Model.FeaturedModel;
import com.lavanphat.doanchuyennganh.Model.ImageProduct;
import com.lavanphat.doanchuyennganh.ProductDetailActivity;
import com.lavanphat.doanchuyennganh.R;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class FeaturedAdapter extends RecyclerView.Adapter<FeaturedAdapter.ViewHolder> {
    ArrayList<FeaturedModel> cate;
    Context context;

    public FeaturedAdapter(ArrayList<FeaturedModel> cate, Context context) {
        this.cate = cate;
        this.context = context;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_featured_recyclerview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtName.setText(cate.get(position).getTitle());

        int price = Integer.parseInt(cate.get(position).getPriceNew());
        holder.txtPrice.setText(NumberFormat.getNumberInstance(Locale.US).format(price) + " Đ");

        if (cate.get(position).getImageProduct().get(0).getImage() != null) {
            Glide.with(context).load(cate.get(position).getImageProduct().get(0).getImage()).into(holder.imgImageFeatured);
        } else {
            Glide.with(context).load(cate.get(position).getImageProduct().get(0).getImageURL()).into(holder.imgImageFeatured);

        }
    }

    @Override
    public int getItemCount() {
        //trả về số lượng phần tử trong araylist
        return cate.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //find id những gì đã tạo ở layout item category
        ImageView imgImageFeatured;
        TextView txtName, txtPrice;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgImageFeatured = itemView.findViewById(R.id.imgImageFeatured);
            txtName = itemView.findViewById(R.id.txtName);
            txtPrice = itemView.findViewById(R.id.txtPrice);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, ProductDetailActivity.class);
                    intent.putExtra("slugProduct", cate.get(getAdapterPosition()).getSlug());
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }
    }
}
