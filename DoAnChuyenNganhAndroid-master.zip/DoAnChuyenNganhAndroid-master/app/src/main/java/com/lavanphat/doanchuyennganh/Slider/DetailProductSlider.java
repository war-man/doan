package com.lavanphat.doanchuyennganh.Slider;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.lavanphat.doanchuyennganh.Model.ImageProduct;
import com.lavanphat.doanchuyennganh.R;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.List;

public class DetailProductSlider extends SliderViewAdapter<DetailProductSlider.SliderAdapterVH> {
    Context context;
    List<ImageProduct> imageProductList;

    public DetailProductSlider(Context context, List<ImageProduct> imageProductList) {
        this.context = context;
        this.imageProductList = imageProductList;
    }

    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_detail_product_slider_item, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, int position) {
        if (imageProductList.get(position).getImageURL() != null){
            Glide.with(context)
                    .load(imageProductList.get(position).getImageURL())
                    .into(viewHolder.imgDetail);
        }
        if (imageProductList.get(position).getImage() != null) {
            Glide.with(context)
                    .load(imageProductList.get(position).getImage())
                    .into(viewHolder.imgDetail);
        }
    }

    @Override
    public int getCount() {
        return imageProductList.size();
    }

    public class SliderAdapterVH extends SliderViewAdapter.ViewHolder {
        ImageView imgDetail;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            imgDetail = itemView.findViewById(R.id.imgDetail);
        }
    }
}
