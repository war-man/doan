package com.lavanphat.doanchuyennganh.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ImageProduct {

    @SerializedName("Image")
    @Expose
    private String image;
    @SerializedName("Image_URL")
    @Expose
    private String imageURL;

    /**
     * No args constructor for use in serialization
     *
     */
    public ImageProduct() {
    }

    /**
     *
     * @param image
     * @param imageURL
     */
    public ImageProduct(String image, String imageURL) {
        super();
        this.image = image;
        this.imageURL = imageURL;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

}
