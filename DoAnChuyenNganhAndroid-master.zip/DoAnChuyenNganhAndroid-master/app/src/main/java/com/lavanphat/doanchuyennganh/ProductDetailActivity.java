package com.lavanphat.doanchuyennganh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.lavanphat.doanchuyennganh.Model.FeaturedModel;
import com.lavanphat.doanchuyennganh.Model.ImageProduct;
import com.lavanphat.doanchuyennganh.Retrofit.ApiCilent;
import com.lavanphat.doanchuyennganh.Retrofit.ApiInterface;
import com.lavanphat.doanchuyennganh.SQLite.DAO.CartDAO;
import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;
import com.lavanphat.doanchuyennganh.Slider.DetailProductSlider;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import com.smarteist.autoimageslider.SliderView;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {
    Toolbar toolbar;
    MaterialSearchView search;
    ApiInterface apiInterface;
    String TAG = "ProductDetailActivity";
    int quality, price;
    String slug, image;

    TextView txtNameProduct, txtPrice, txtDecription, txtQuality;
    Button btnMinus, btnAdd, btnBuy;
    ImageButton btnCart;
    SliderView imgImageProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        addControl();
        addEvent();
    }

    private void addEvent() {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quality++;
                txtQuality.setText(String.valueOf(quality));
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quality--;
                txtQuality.setText(String.valueOf(quality));
            }
        });

        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveProductInCart();
            }
        });
    }

    private void saveProductInCart() {
        CartDAO cartDAO = new CartDAO(getApplication());
        cartDAO.open();

        CartDTO cart = new CartDTO();
        cart.setName(txtNameProduct.getText().toString());
        cart.setSlug(slug);
        cart.setQuality(Integer.parseInt(txtQuality.getText().toString()));
        cart.setPrice(price);
        cart.setImage(image);

        List<CartDTO> cartList = cartDAO.getCart();
        boolean kq = false;
        boolean trung = false;
        if (cartList.size() > 0) {
            for (CartDTO cartDTO : cartList) {
                if (cart.getSlug().equals(cartDTO.getSlug())) {
                    int quality = cartDTO.getQuality() + Integer.parseInt(txtQuality.getText().toString());
                    cart.setQuality(quality);
                    kq = cartDAO.updateCart(slug, cart);
                    trung = true;
                }
            }
            if (!trung) {
                kq = cartDAO.addCart(cart);
            }
            if (kq) {
                Toast.makeText(getApplication(), "Đã thêm sản phẩm vào giỏ hàng !!!", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(getApplication(), "Thêm sản phẩm thất bại", Toast.LENGTH_SHORT).show();
        } else {
            kq = cartDAO.addCart(cart);
            if (kq) {
                Toast.makeText(getApplication(), "Đã thêm sản phẩm vào giỏ hàng !!!", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(getApplication(), "Thêm sản phẩm thất bại", Toast.LENGTH_SHORT).show();
        }
        cartDAO.close();
    }

    private void addControl() {
        toolbar = findViewById(R.id.toolbar);
        search = findViewById(R.id.search);

        txtNameProduct = findViewById(R.id.txtNameProduct);
        txtDecription = findViewById(R.id.txtDecription);
        txtPrice = findViewById(R.id.txtPrice);
        txtQuality = findViewById(R.id.txtQuality);

        btnAdd = findViewById(R.id.btnAdd);
        btnMinus = findViewById(R.id.btnMinus);
        btnBuy = findViewById(R.id.btnBuy);
        btnCart = findViewById(R.id.btnCart);

        imgImageProduct = findViewById(R.id.imgImageProduct);

        //hiển thị toolbar
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        apiInterface = ApiCilent.getApiCilent().create(ApiInterface.class);
        getProductDetails();

        quality = Integer.parseInt(txtQuality.getText().toString());

    }

    private void getProductDetails() {
        Intent intent = getIntent();
        slug = intent.getStringExtra("slugProduct");

        Call<FeaturedModel> call = apiInterface.getDetailsProduct(slug);
        call.enqueue(new Callback<FeaturedModel>() {
            @Override
            public void onResponse(Call<FeaturedModel> call, Response<FeaturedModel> response) {
                FeaturedModel featuredModel = response.body();
                List<ImageProduct> imageProductList = featuredModel.getImageProduct();

                txtNameProduct.setText(featuredModel.getTitle());
                price = Integer.parseInt(featuredModel.getPriceNew());
                txtPrice.setText(NumberFormat.getNumberInstance(Locale.US).format(price) + " Đ");
                txtDecription.setText(featuredModel.getDecription());

                DetailProductSlider adapter = new DetailProductSlider(getApplication(), imageProductList);
                imgImageProduct.setSliderAdapter(adapter);

                if (imageProductList.get(0).getImage() != null) {
                    image = imageProductList.get(0).getImage();
                } else {
                    image = imageProductList.get(0).getImageURL();
                }
            }

            @Override
            public void onFailure(Call<FeaturedModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        search.setMenuItem(menuItem);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent intent = new Intent(getApplication(), CartActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}
