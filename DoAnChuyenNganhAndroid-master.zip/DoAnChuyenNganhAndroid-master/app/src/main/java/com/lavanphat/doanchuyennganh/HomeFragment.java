package com.lavanphat.doanchuyennganh;


import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.lavanphat.doanchuyennganh.Adapter.BrandAdapter;
import com.lavanphat.doanchuyennganh.Adapter.CategoryAdapter;
import com.lavanphat.doanchuyennganh.Adapter.FeaturedAdapter;
import com.lavanphat.doanchuyennganh.Model.BrandModel;
import com.lavanphat.doanchuyennganh.Model.CategoryModel;
import com.lavanphat.doanchuyennganh.Model.FeaturedModel;
import com.lavanphat.doanchuyennganh.Model.ImageProduct;
import com.lavanphat.doanchuyennganh.Retrofit.ApiCilent;
import com.lavanphat.doanchuyennganh.Retrofit.ApiInterface;
import com.lavanphat.doanchuyennganh.Slider.SliderAdapterExample;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    View myview;
    ApiInterface apiInterface;
    RecyclerView rcvCategory, rcvFeatured, rcvBrand;

    List<CategoryModel> categoryModels;
    CategoryAdapter categoryAdapter;

    List<BrandModel> brandModels;
    BrandAdapter brandAdapter;

    List<FeaturedModel> featuredModelList;
    List<ImageProduct> imageProductList;
    FeaturedAdapter featuredAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        myview = inflater.inflate(R.layout.fragment_home, container, false);

        addControl();
        addEvents();

        return myview;
    }

    private void addControl() {
        //        <--Tạo Banner-->
        SliderView sliderView = myview.findViewById(R.id.imageSlider);

        SliderAdapterExample adapter = new SliderAdapterExample(getActivity());

        sliderView.setSliderAdapter(adapter);

        sliderView.setIndicatorAnimation(IndicatorAnimations.WORM); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setIndicatorSelectedColor(Color.WHITE);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(4);//set scroll delay in seconds :
        sliderView.startAutoCycle();
//        <------------------------------------------------->
        rcvCategory = myview.findViewById(R.id.rcvCategory);
        rcvFeatured = myview.findViewById(R.id.rcvFeatured);
        rcvBrand = myview.findViewById(R.id.rcvBrand);

        //kết nối tới server
        apiInterface = ApiCilent.getApiCilent().create(ApiInterface.class);
        //lấy dữ liệu category từ server load lên màn hình
        getCategory();
        //lấy dữ liệu brand từ server load lên màn hình
        getBrand();
        //lấy dữ liệu sản phẩm mới nhất từ server load lên màn hình
        getFeatured();

    }

    private void getFeatured() {
        Call<List<FeaturedModel>> call = apiInterface.getFeatured();
        call.enqueue(new Callback<List<FeaturedModel>>() {
            @Override
            public void onResponse(Call<List<FeaturedModel>> call, Response<List<FeaturedModel>> response) {
                imageProductList = new ArrayList<>();
//                for (int i = 0; i < response.body().size(); i++) {
//                    FeaturedModel a=new FeaturedModel();
//                    a.setTitle(response.body().get(i).getTitle());
//                    a.setPrice_New(response.body().get(i).getPrice_New());
//                    featuredModelList.add(a);
//                    Log.d("retrofit",);
//                }
                featuredModelList = response.body();
//                for (int i = 0; i < featuredModelList.size(); i++) {
//                    if (!featuredModelList.get(i).getImageProduct().isEmpty()) {
//                        ImageProduct imageProduct = new ImageProduct();
//                        imageProduct.setImage(featuredModelList.get(i).getImageProduct().get(0).getImage());
//                        imageProduct.setImageURL(featuredModelList.get(i).getImageProduct().get(0).getImageURL());
//                        imageProductList.add(imageProduct);
////                        Log.d("retrofit", String.valueOf(featuredModelList.get(i).getImageProduct().get(0).getImageURL()));
//                    }
//                }

                featuredAdapter = new FeaturedAdapter((ArrayList<FeaturedModel>) featuredModelList, getActivity());
                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, true);
                layoutManager.setStackFromEnd(true);
                rcvFeatured.setHasFixedSize(true);
                rcvFeatured.setLayoutManager(layoutManager);
                rcvFeatured.setAdapter(featuredAdapter);
            }

            @Override
            public void onFailure(Call<List<FeaturedModel>> call, Throwable t) {
                Toast.makeText(getActivity(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getBrand() {
        Call<List<BrandModel>> call = apiInterface.getBrand();
        call.enqueue(new Callback<List<BrandModel>>() {
            @Override
            public void onResponse(Call<List<BrandModel>> call, Response<List<BrandModel>> response) {
                brandModels = response.body();
                brandAdapter = new BrandAdapter((ArrayList<BrandModel>) brandModels, getActivity());
                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, true);
                layoutManager.setStackFromEnd(true);
                rcvBrand.setHasFixedSize(true);
                rcvBrand.setLayoutManager(layoutManager);
                rcvBrand.setAdapter(brandAdapter);
            }

            @Override
            public void onFailure(Call<List<BrandModel>> call, Throwable t) {
                Toast.makeText(getActivity(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
                Log.d("loi", t.toString());
            }
        });
    }


    private void addEvents() {

    }

    private void getCategory() {
        Call<List<CategoryModel>> call = apiInterface.getCategory();
        call.enqueue(new Callback<List<CategoryModel>>() {
            @Override
            public void onResponse(Call<List<CategoryModel>> call, Response<List<CategoryModel>> response) {
                categoryModels = response.body();
                categoryAdapter = new CategoryAdapter((ArrayList<CategoryModel>) categoryModels, getActivity());
                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, true);
                layoutManager.setStackFromEnd(true);
                rcvCategory.setHasFixedSize(true);
                rcvCategory.setLayoutManager(layoutManager);
                rcvCategory.setAdapter(categoryAdapter);

            }
            @Override
            public void onFailure(Call<List<CategoryModel>> call, Throwable t) {
                Toast.makeText(getActivity(), "Lỗi kết nối !!!", Toast.LENGTH_SHORT).show();
                Log.d("loi", t.toString());
            }
        });
    }


}
