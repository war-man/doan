package com.lavanphat.doanchuyennganh.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BillProductModel {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("Bill")
    @Expose
    private Integer bill;
    @SerializedName("Product")
    @Expose
    private Integer product;
    @SerializedName("Quality")
    @Expose
    private Integer quality;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBill() {
        return bill;
    }

    public void setBill(Integer bill) {
        this.bill = bill;
    }

    public Integer getProduct() {
        return product;
    }

    public void setProduct(Integer product) {
        this.product = product;
    }

    public Integer getQuality() {
        return quality;
    }

    public void setQuality(Integer quality) {
        this.quality = quality;
    }

    public BillProductModel(Integer id, Integer bill, Integer product, Integer quality) {
        this.id = id;
        this.bill = bill;
        this.product = product;
        this.quality = quality;
    }

    public BillProductModel() {
    }
}
