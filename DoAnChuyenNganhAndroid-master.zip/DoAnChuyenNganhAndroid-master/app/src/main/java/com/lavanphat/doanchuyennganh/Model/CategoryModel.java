package com.lavanphat.doanchuyennganh.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CategoryModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("slug")
    @Expose
    private String slug;

    @SerializedName("product")
    @Expose
    private List<FeaturedModel> product = null;

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return title;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public List<FeaturedModel> getProduct() {
        return product;
    }

    public void setProduct(List<FeaturedModel> product) {
        this.product = product;
    }

    public CategoryModel(String id, String title, String slug, List<FeaturedModel> product) {
        this.id = id;
        this.title = title;
        this.slug = slug;
        this.product = product;
    }

    public CategoryModel() {
    }
}
