package com.lavanphat.doanchuyennganh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    HomeFragment fmHome;
    UserFragment fmUser;
    Toolbar toolbar;
    MaterialSearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addControl();
        addEvents();
    }

    private void addEvents() {
        //sự kiện chọn icon để đổi màn hình bottomNavigation Bar
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem menuItem) {
                //đặt sự kiến click cho nút home và tôi
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        setOurFragment(fmHome);
                        getSupportActionBar().setTitle("Đồ Án Chuyên Ngành");
                        toolbar.setBackground(new ColorDrawable(getResources().getColor(android.R.color.white)));
                        break;
                    case R.id.user:
                        setOurFragment(fmUser);
                        toolbar.setBackground(new ColorDrawable(getResources().getColor(R.color.blue)));
                        getSupportActionBar().setTitle("");
                        break;
                }
            }
        });
    }

    private void addControl() {
        bottomNavigationView = findViewById(R.id.btNavBar);

        toolbar = findViewById(R.id.toolbar);
        //hiển thị toolbar
        setSupportActionBar(toolbar);
        //đặt tiêu đề cho toolbar
        getSupportActionBar().setTitle("Đồ Án Chuyên Ngành");
        //màu chữ cho toolbar
        toolbar.setTitleTextColor(Color.parseColor("#FF000000"));

        searchView = findViewById(R.id.search);

        fmHome = new HomeFragment();
        fmUser = new UserFragment();
        //đặt fmHome làm mặc định khi chạy app lên
        setOurFragment(fmHome);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        searchView.setMenuItem(menuItem);
        return true;
    }

    private void setOurFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.mainframe, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent intent = new Intent(getApplication(), CartActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}
