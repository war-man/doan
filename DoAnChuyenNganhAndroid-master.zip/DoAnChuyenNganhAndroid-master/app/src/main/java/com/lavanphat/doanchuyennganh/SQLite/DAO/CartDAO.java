package com.lavanphat.doanchuyennganh.SQLite.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.lavanphat.doanchuyennganh.SQLite.DTO.CartDTO;
import com.lavanphat.doanchuyennganh.SQLite.OilDatabase;

import java.util.ArrayList;
import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class CartDAO {
    SQLiteDatabase database;
    OilDatabase oilDatabase;

    public CartDAO(Context context) {
        oilDatabase = new OilDatabase(context);
    }

    public void open() {
        database = oilDatabase.getWritableDatabase();
    }

    public void close() {
        oilDatabase.close();
    }

    public boolean addCart(CartDTO cart) {
        ContentValues cv = new ContentValues();
        cv.put(OilDatabase.CART_NAME, cart.getName());
        cv.put(OilDatabase.CART_SLUG, cart.getSlug());
        cv.put(OilDatabase.CART_IMAGE, cart.getImage());
        cv.put(OilDatabase.CART_QUALITY, cart.getQuality());
        cv.put(OilDatabase.CART_PRICE, cart.getPrice());

        long kq = database.insert(OilDatabase.CART, null, cv);
        if (kq != 0)
            return true;
        else
            return false;
    }

    public List<CartDTO> getCart() {
        List<CartDTO> cartList = new ArrayList<>();

        Cursor cursor = database.query(OilDatabase.CART, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            CartDTO sv = new CartDTO();

            int id = cursor.getInt(0);
            int price = cursor.getInt(5);
            int quality = cursor.getInt(4);
            String name = cursor.getString(1);
            String slug = cursor.getString(2);
            String image = cursor.getString(3);

            sv.setId(id);
            sv.setName(name);
            sv.setSlug(slug);
            sv.setImage(image);
            sv.setPrice(price);
            sv.setQuality(quality);

            cartList.add(sv);
            cursor.moveToNext();
        }
        return cartList;
    }

    public boolean updateCart(String slug, CartDTO cartDTO) {
        ContentValues cv = new ContentValues();
        cv.put(OilDatabase.CART_QUALITY, cartDTO.getQuality());

        long kq = database.update(OilDatabase.CART, cv, OilDatabase.CART_SLUG + "=" + "\"" + slug + "\"", null);
        if (kq != 0)
            return true;
        else
            return false;
    }

    public boolean deleteCart(CartDTO cartDTO) {
        int kq = database.delete(OilDatabase.CART, OilDatabase.CART_SLUG + "=" + "\"" + cartDTO.getSlug() + "\"", null);
        if (kq != 0) {
            return true;
        } else
            return false;
    }

    public boolean deleteAllCart(){
        int kq=database.delete(OilDatabase.CART,null,null);
        if (kq != 0) {
            return true;
        } else
            return false;
    }
}
