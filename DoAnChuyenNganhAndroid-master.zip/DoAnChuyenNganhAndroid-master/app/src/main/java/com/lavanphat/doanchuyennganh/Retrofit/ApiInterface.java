package com.lavanphat.doanchuyennganh.Retrofit;

import com.lavanphat.doanchuyennganh.Model.BillModel;
import com.lavanphat.doanchuyennganh.Model.BillProductModel;
import com.lavanphat.doanchuyennganh.Model.BrandModel;
import com.lavanphat.doanchuyennganh.Model.CategoryModel;
import com.lavanphat.doanchuyennganh.Model.FeaturedModel;
import com.lavanphat.doanchuyennganh.Model.VoucherModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiInterface {

    @GET("category/")
    Call<List<CategoryModel>> getCategory();

    @GET("brand/")
    Call<List<BrandModel>> getBrand();

    @GET("product-featured/")
    Call<List<FeaturedModel>> getFeatured();

    @GET("category/{slug}/")
    Call<CategoryModel> getListProduct(@Path("slug") String slug);

    @GET("brand/{slug}/")
    Call<BrandModel> getBrandProduct(@Path("slug") String slug);

    @GET("product-all/{slug}/")
    Call<FeaturedModel> getDetailsProduct(@Path("slug") String slug);

    @GET("voucher/")
    Call<List<VoucherModel>> getVoucher();

    @POST("bill/")
    Call<BillModel> postNewBill(@Body BillModel bill);

    @POST("bill-product/")
    Call<BillProductModel> postNewBillProduct(@Body BillProductModel billProduct);
}
