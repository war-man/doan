package com.lavanphat.doanchuyennganh.Model;

import android.graphics.Bitmap;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FeaturedModel {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("Price_New")
    @Expose
    private String priceNew;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("Decription")
    @Expose
    private String decription;
    @SerializedName("image_product")
    @Expose
    private List<ImageProduct> imageProduct = null;

    @Override
    public String toString() {
        return "FeaturedModel{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", priceNew='" + priceNew + '\'' +
                ", imageProduct=" + imageProduct +
                '}';
    }

    /**
     * No args constructor for use in serialization
     *
     */
    public FeaturedModel() {
    }

    /**
     *
     * @param priceNew
     * @param id
     * @param title
     * @param imageProduct
     * @param slug
     * @param decription
     */
    public FeaturedModel(Integer id, String title, String slug, String decription, String priceNew, List<ImageProduct> imageProduct) {
        super();
        this.id = id;
        this.title = title;
        this.slug = slug;
        this.decription = decription;
        this.priceNew = priceNew;
        this.imageProduct = imageProduct;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPriceNew() {
        return priceNew;
    }

    public void setPriceNew(String priceNew) {
        this.priceNew = priceNew;
    }

    public List<ImageProduct> getImageProduct() {
        return imageProduct;
    }

    public void setImageProduct(List<ImageProduct> imageProduct) {
        this.imageProduct = imageProduct;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getDecription() {
        return decription;
    }

    public void setDecription(String decription) {
        this.decription = decription;
    }
}