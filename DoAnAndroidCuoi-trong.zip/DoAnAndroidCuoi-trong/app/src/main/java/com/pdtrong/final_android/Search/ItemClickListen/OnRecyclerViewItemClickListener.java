package com.pdtrong.final_android.Search.ItemClickListen;

public interface OnRecyclerViewItemClickListener {

    public void onRecyclerViewItemClicked(int position,int id);
}
