package com.pdtrong.final_android.ChuyenTabLogin_TabSignUp;

import android.support.v4.app.Fragment;

public interface ChuyenTabLogin_SignUp {
    void chuyebTabLogin_SignUP( Fragment fragment);
}
