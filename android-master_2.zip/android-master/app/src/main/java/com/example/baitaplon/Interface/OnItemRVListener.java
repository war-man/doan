package com.example.baitaplon.Interface;

public interface OnItemRVListener {
    public void onClick(int position,String action);
}
