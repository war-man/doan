package com.example.baitaplon.Interface;

public interface OnClickTest {
    void onClick(String string);
}
