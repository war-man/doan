package com.example.baitaplon.Interface;

import android.os.Bundle;

public interface FragmentListener {
    void onAction(String action, int data);
}
