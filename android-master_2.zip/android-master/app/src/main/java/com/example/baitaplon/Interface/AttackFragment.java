package com.example.baitaplon.Interface;

public interface AttackFragment {
    void onClick(String action);
}
