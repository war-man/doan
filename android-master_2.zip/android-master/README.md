# android
Bài tập lớn Android quản lý nhà hàng. <br/>
Vì lưu trong database nên khi sang máy khác phải tự thêm dữ liệu vào.  <br/>
Với 2 tài khoản đăng nhập.  <br/>
Tài khoản đăng nhâp: +Quản lý: admin - 123  <br/>
+Nhân Viên: nhanvien - 123   <br/>
App quản lý nhà hàng nếu chưa đăng nhập sẽ chuyển sang trang đăng nhập.  <br/>
-Nếu đăng nhập với tài khoản quản trị viên. Ta có thể thực hiện tất cả chức năng quản lý:  <br/>
+Với quản lý món ăn: có thể thực hiện thêm, sửa, xóa món ăn.  <br/>
+với quản lý bàn ăn: Có thể thực hiện chức năng thêm bàn, xóa bàn nếu bàn trống(Không có ai đang đặt). Trạng thái bàn trống thì bàn có màu xanh là cây còn bàn có người là màu đỏ. Nếu bàn có người. Bấm vào thanh toán để thanh toán tiền.
Hoạt động thanh toán sẽ được lưu vào CSDL.
+Chức năng thống kê doanh thu: thống kê theo từng món theo số lượng và tổng tiền.  <br/>
Thống kê tổng số món và thống kê món nào được đặt nhiều nhất để quản lý được biết và từ đó có thể yêu cầu làm nhiều món đó hơn. <br/>
-Nếu đăng nhập với tài khoản nhân viên:  <br/>
+Nhân viên chỉ có 1 chức năng duy nhất là đặt bàn và chờ khách yêu cầu thanh toán.  <br/>
Các ảnh minh họa  <br/>
<img src="https://i.imgur.com/PbQVQQv.png" width="200"/> <br/>
<img src="https://i.imgur.com/vnAmqU6.png" width="200"/> <br/>
<img src="https://i.imgur.com/HKsSMbK.png" width="200"/> <br/>
<img src="https://i.imgur.com/j2Gj9e2.png" width="200"/> <br/>
<img src="https://i.imgur.com/MMg7Daw.png" width="200"/> <br/>
<img src="https://i.imgur.com/pja2hjx.png" width="200"/> <br/>
<img src="https://i.imgur.com/4m3krP7.png" width="200"/> <br/>
<img src="https://i.imgur.com/hJNzM5o.png" width="200"/> <br/>
<img src="https://i.imgur.com/AzH6k7o.png" width="200"/> <br/>
<img src="https://i.imgur.com/kCS84ZP.png" width="200"/> <br/>
<img src="https://i.imgur.com/p54VGos.png" width="200"/> <br/>
<img src="https://i.imgur.com/s6z6v2h.png" width="200"/> <br/>
<img src="https://i.imgur.com/VDIupTE.png" width="200"/> <br/>
<img src="https://i.imgur.com/C9eO7Xj.png" width="200"/> <br/>
<img src="https://i.imgur.com/eRRAbK3.png" width="200"/> <br/>
