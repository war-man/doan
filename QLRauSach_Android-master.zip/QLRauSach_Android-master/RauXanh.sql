
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 19, 2017 at 02:57 AM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `u904898350_rau`
--

-- --------------------------------------------------------

--
-- Table structure for table `CT_DONDATHANG`
--

CREATE TABLE IF NOT EXISTS `CT_DONDATHANG` (
  `MADONHANG` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MASP` int(11) NOT NULL,
  `SOLUONG` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `CT_DONDATHANG`
--

INSERT INTO `CT_DONDATHANG` (`MADONHANG`, `MASP`, `SOLUONG`) VALUES
('DH2520171211092544', 10, 1),
('DH2520171211092623', 9, 1),
('DH2520171211092623', 10, 1),
('DH2520171211092350', 11, 1),
('DH2520171211092350', 10, 1),
('DH2520171211092350', 13, 1),
('DH2520171211092350', 12, 1),
('DH1220171211140446', 9, 1),
('DH1220171211140446', 10, 2),
('DH1220171211140534', 4, 1),
('DH1220171211140534', 6, 1),
('DH1220171211140655', 7, 1),
('DH1220171211140733', 10, 1),
('DH1220171211140821', 13, 1),
('DH1220171211140821', 6, 1),
('DH2620171213152513', 13, 1),
('DH2620171213152513', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `CT_SP_NCC`
--

CREATE TABLE IF NOT EXISTS `CT_SP_NCC` (
  `MANCC` int(11) NOT NULL,
  `MASP` int(11) NOT NULL,
  PRIMARY KEY (`MASP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `CT_SP_NCC`
--

INSERT INTO `CT_SP_NCC` (`MANCC`, `MASP`) VALUES
(1, 1),
(2, 2),
(1, 3),
(2, 4),
(1, 5),
(2, 6),
(1, 7),
(2, 8),
(1, 9),
(2, 10),
(1, 11),
(2, 12),
(1, 13),
(2, 14),
(1, 41),
(2, 42);

-- --------------------------------------------------------

--
-- Table structure for table `DONDATHANG`
--

CREATE TABLE IF NOT EXISTS `DONDATHANG` (
  `TRANGTHAI` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `MAKH` int(11) NOT NULL,
  `MADONHANG` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DC_TINH` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_QUANHUYEN` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_PHUONGXA` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_SONHA_DUONG` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `THOIGIANGIAO` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHIVANCHUYEN` int(11) DEFAULT NULL,
  `GIODAT` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TONGTIEN` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `DONDATHANG`
--

INSERT INTO `DONDATHANG` (`TRANGTHAI`, `MAKH`, `MADONHANG`, `DC_TINH`, `DC_QUANHUYEN`, `DC_PHUONGXA`, `DC_SONHA_DUONG`, `THOIGIANGIAO`, `PHIVANCHUYEN`, `GIODAT`, `TONGTIEN`) VALUES
('Chưa giao', 25, 'DH2520171211092544', 'TP.Hồ Chí Minh', 'Quận 1', 'Bến Nghé', '72 Lê Thánh Tôn', 'null', 20000, '2017/12/11 09:25:44', 170000),
('Đã giao', 25, 'DH2520171211092623', 'TP.Hồ Chí Minh', 'Tân Phú', 'Tây Thạnh', '30 Lê Trọng Tấn', 'null', 20000, '2017/12/11 09:26:23', 195000),
('Chưa giao', 25, 'DH2520171211092350', 'TP.Hồ Chí Minh', 'Tân Phú', 'Sơn Kỳ', '30 Bờ Bao Tân Thắng', 'null', 20000, '2017/12/11 09:23:50', 380000),
('Chưa giao', 12, 'DH1220171211140446', 'TP.Hồ Chí Minh', 'Bình Tân', 'Bình Trị Đông B', 'Số 1 đường số 17A, khu phố 11', 'null', 20000, '2017/12/11 14:04:46', 625000),
('Đã huỷ', 12, 'DH1220171211140534', 'TP.Hồ Chí Minh', 'Quận 1', 'Bến Nghé', '72 Lê Thánh Tôn', 'null', 20000, '2017/12/11 14:05:34', 1010000),
('Đã giao', 12, 'DH1220171211140655', 'TP.Hồ Chí Minh', 'Quận 1', 'Bến Nghé', '72 Lê Thánh Tôn', 'null', 20000, '2017/12/11 14:06:55', 20000),
('Chưa giao', 12, 'DH1220171211140733', 'TP.Hồ Chí Minh', 'Quận 12', 'tân hưng thuận', '1 Tô ký', 'null', 20000, '2017/12/11 14:07:33', 150000),
('Đã giao', 12, 'DH1220171211140821', 'TP.Hồ Chí Minh', 'Thủ Đức', 'Hiệp Bình Chánh', 'Chùa An Lạc', 'null', 20000, '2017/12/11 14:08:21', 1100000);

-- --------------------------------------------------------

--
-- Table structure for table `LOAISP`
--

CREATE TABLE IF NOT EXISTS `LOAISP` (
  `MALOAI` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `TENLOAI` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CACHBAOQUAN` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HINHANH` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `LOAISP`
--

INSERT INTO `LOAISP` (`MALOAI`, `TENLOAI`, `CACHBAOQUAN`, `HINHANH`) VALUES
('RauXanh', 'Rau xanh', 'Ăn trong ngày hoặc để tủ lạnh', 'http://vfa.gov.vn/data/2016/3_157817.jpg'),
('Nam', 'Nấm', 'Để tủ lạnh để bảo quản lâu hơn', 'https://previews.123rf.com/images/chic2view/chic2view1308/chic2view130800001/21632685-healthy-mushroom-mascot-cartoon-vector-Stock-Photo.jpg'),
('TraiCay', 'Trái cây', 'Ăn trong vài ngày và để tủ lạnh', 'http://vanhoamientay.com/wp-content/uploads/2015/02/chon-trai-cay-ngon.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `NGUOIDUNG`
--

CREATE TABLE IF NOT EXISTS `NGUOIDUNG` (
  `USERNAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOAITK` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USERNAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `NGUOIDUNG`
--

INSERT INTO `NGUOIDUNG` (`USERNAME`, `PASSWORD`, `EMAIL`, `LOAITK`) VALUES
('admin', 'admin', 'auduongvanhieu@gmail.com', 'Admin'),
('hieu', '123456', 'hieu@gmail.com', 'Khách hàng'),
('hieu6789', '123456', 'auduongvanhieu@gmail.com', 'Nhà cung cấp'),
('hieukh', '123456', 'a@gmail.com', 'Khách hàng'),
('loc', '123456', 'loc@gmail.com', 'Khách hàng'),
('123456', '123456', 'dggff', 'Khách hàng'),
('loc6789', '123456', 'locdh@cntp.com', 'Nhà cung cấp');

-- --------------------------------------------------------

--
-- Table structure for table `SANPHAM`
--

CREATE TABLE IF NOT EXISTS `SANPHAM` (
  `MASP` int(20) NOT NULL AUTO_INCREMENT,
  `TENSP` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MOTA` text COLLATE utf8_unicode_ci,
  `DONGIA` int(11) DEFAULT NULL,
  `NGAYSX` datetime DEFAULT NULL,
  `DVT` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINKHINH` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MALOAI` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`MASP`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

--
-- Dumping data for table `SANPHAM`
--

INSERT INTO `SANPHAM` (`MASP`, `TENSP`, `MOTA`, `DONGIA`, `NGAYSX`, `DVT`, `LINKHINH`, `MALOAI`) VALUES
(1, 'Cải xà lách', 'Xà lách là món ăn phổ biến trong mùa đông, chứa rất nhiều muối khoáng với các nguyên tố kiềm, mang lại sự tỉnh táo tinh thần và tránh được nhiều bệnh tật.', 20000, '2017-10-15 10:31:32', 'Bó', 'http://www.chuatribenhtri.info/wp-content/uploads/2015/08/rau-diep.jpg', 'RauXanh'),
(2, 'Rau Muống', 'Anh đi anh nhớ quê nhà,\r\n\r\n''Nhớ canh rau muống, nhớ cà dầm tương.\r\n\r\n''Nhớ người một nắng hai sương,\r\n\r\n''Nhớ ai tát nước bên đường hôm nao''.', 15000, '2017-10-14 17:43:34', 'Bó', 'http://xmedia.nguoiduatin.vn/2016/10/1/9637/rau-muong-phunutodayvn-1475320282.jpg', 'RauXanh'),
(3, 'Nấm rơm', 'Nấm rơm là loại nấm khá quen thuộc với nhân dân ta. Nấm thường mọc trên nguyên liệu phổ biến là rơm nên có tên chung là nấm rơm (Straw mushrooom), tên khoa học là Volvariella volvacea.', 6000, '2017-10-14 07:21:22', 'Gam', 'http://www.vuonrauviet.com/data/news/89/58.jpg', 'Nam'),
(4, 'Nấm đông cô', 'Nấm đông cô có dạng như cái ô, đường kính 4-10 cm, màu nâu nhạt, khi chín chuyển thành nâu sậm. Trên mặt nấm có những vảy nhỏ màu trắng. Thịt nấm màu trắng, cuống hình trụ. Nấm mọc ký sinh trên những cây có lá to và thay lá mỗi mùa như dẻ, sồi, phong. Loài thực vật này mọc hoang nhiều ở Việt Nam, Trung Quốc, Nhật Bản, Hàn Quốc. Ở Mỹ, nông dân trồng nấm hương tại các trang trại. Mỗi khúc gỗ có thể cho nấm ký sinh 3-7 năm.', 10000, '2017-10-18 05:28:26', 'Gam', 'http://www.namtuoi.biz/wp-content/uploads/2015/06/dac-diem-va-cong-dung-nam-dong-co.jpg', 'Nam'),
(5, 'Rau mồng tơi', 'Mồng tơi là loại rau phổ biến, được sử dụng để chế biến trong bữa ăn hàng ngày. Canh mồng tơi là món ăn lý tưởng để giải nhiệt. Không chỉ là món rau thông thường, trong dân gian rau mồng tơi còn các tác dụng chữa bệnh.', 30000, '2017-10-17 00:00:00', 'Ký', 'http://images.vov.vn/w490/uploaded/thuthuy/2015_08_24/rau_mong_toi_xldy.jpg', 'RauXanh'),
(6, 'Đông trùng hạ thảo', 'Nhiều người cho rằng, đông trùng hạ thảo là sinh vật đặc biệt, ở dạng côn trùng vào mùa đông, còn mùa hè thì hóa thành cây cỏ nên mới có tên như vậy. Tuy nhiên theo giới khoa học, đông trùng hạ thảo là tên gọi chung cho một nhóm nấm ký sinh và gây bệnh trên côn trùng. Cuối mùa thu đầu đông, chúng ký sinh gây bệnh trên côn trùng. Đến mùa hạ, khi nhiệt độ tăng lên, nấm phát sinh thành quả, mọc thành dạng cây cỏ.', 1000000, '2017-10-05 00:00:00', 'Ký', 'https://i-vnexpress.vnecdn.net/2014/11/10/dongtrunghathao3-7595-1415608532.jpg', 'Nam'),
(7, 'Rau càng cua', 'Rau càng cua (danh pháp hai phần: Peperomia pellucida) là một loài rau thuộc họ Hồ tiêu (Piperaceae).[1] Đây là loại rau hoang dại, mọc nhiều nơi, sống trong vòng một năm, phân bố ở những khu vực có khí hậu nhiệt đới. Rau khi ăn sống hơi chua giòn ngon, có giá trị về dinh dưỡng.', 20000, '2017-10-20 00:00:00', 'Ký', 'https://upload.wikimedia.org/wikipedia/commons/9/90/Mashi_Chedi.jpg', 'RauXanh'),
(8, 'Rau nhút', 'Rau nhút là một trong những loại rau bổ dưỡng,thanh mát mà mọi người thường dùng trong mùa hè,nó sống ở bề mặt ao hồ,sau đây chúng ta hãy tìm hiểu Những tác dụng của cây rau nhút nhé! ', 30000, '2017-10-27 00:00:00', 'Ký', 'https://tacdungcuacay.com/wp-content/uploads/2016/10/nhung-doi-tuong-tuyet-doi-khong-an-rau-rut-rau-nhut.jpg', 'RauXanh'),
(9, 'Rau cần nước', 'Rau cần chứa  tinh dầu, acid hữu cơ, caroten, vitamin P, C, đạm, đường, canxi, phôtpho, sắt... Nghiên cứu dược lý cho thấy, loại rau này có tác dụng giảm ho, chống viêm, long đờm, kháng nấm, hạ huyết áp, giảm đường và mỡ máu.', 25000, '2017-10-31 00:00:00', 'Ký', 'http://media.tinmoi.vn/2015/11/09/rau-can-nuoc-va-cong-dung-chua-benh-it-nguoi-biet2.jpg', 'RauXanh'),
(10, 'Nấm bào ngư ', 'Nấm bào ngư là loại nấm tươi giàu dinh dưỡng và dược tính nên được gây trồng trên rơm rạ, bã mía, mùn cưa… Loại nấm này có công dụng giải độc và bảo vệ các tế bào gan, có thể kháng ung thư và kháng virus, giảm nguy cơ các bệnh về tim mạch…', 150000, '2017-10-31 00:00:00', 'Ký', 'https://i.ytimg.com/vi/ruxSPHGJm24/maxresdefault.jpg', 'Nam'),
(11, 'Nấm mối ', 'Tên gọi nấm mối vì nấm chỉ xuất hiện ở nơi có nhiều mối sinh sống. mối ở đây là loại mối đất chứ không phải mối sống trên cây. Mối đất làm ổ to như trái dừa khô, hình dáng từng hốc đất, ổ mối đất màu trắng hoặc hơi ngả vàng. nấm mối xuất hiện vào đàu mùa mưa, khoảng từ tháng 4 đến tháng 6 hàng năm. Thường nấm mối xuất hiện ở nơi đất cao vì mối không thể làm ổ ở nơi đất quá ẩm ướt. Nấm mối màu trắng, gốc hơi ngả vàng. Muốn biết chắc chắn đó có phải nấm mối hay không thì chỉ cần đào khoảng đất nhỏ xung quanh, nếu thấy có mối đất sinh sống thì chắc chắn đó là nấm mối.', 80000, '2017-10-30 00:00:00', 'Ký', 'https://znews-photo-td.zadn.vn/w480/Uploaded/pgi_xvauqbnau/2014_08_26/NTYNnam_moi_HEJEjpg.jpg', 'Nam'),
(12, 'Chôm chôm vàng', ' Bề ngoài giống như loại chôm chôm nhãn, nhưng bên trong thịt quả lại có màu vàng bóng nhìn chẳng khác gì lòng đỏ trứng muối, khi ăn có vị chua… loại chôm chôm rừng đang khiến nhiều người xôn xào, tò mò mua về ăn thử.', 30000, '2017-11-28 00:00:00', 'Ký', 'http://imgs.vietnamnet.vn/Images/2017/05/26/19/20170526190605-chom-chom-5.jpg', 'TraiCay'),
(13, 'Sầu riêng Thái Lan ', '– Sầu riêng Monthong là giống sầu riêng cơm vàng hạt lép được trồng theo phương pháp ghép từ chính những dòng cây giống đầu dòng có chất lượng tốt nhất.\r\n– Giống có khả năng thích nghi ở nhiều điều kiện sinh thái khác nhau. Những vùng có độ cao dưới 1200 m so với mặt nước biển và có độ ẩm không khí khoảng từ 75 đến 80%, lượng mưa đạt 1500 mm/năm là những vùng có khí hậu thích hợp nhất đối với giống sầu riêng Monthong. Những vùng Đông Nam Bộ và đồng bằng Sông Cưu Long là một trong những vùng khí hậu thích hợp cho việc trồng giống sầu riêng Monthong.\r\n– Giống sầu riêng Monthong có khả năng phát triển mạnh, tuổi thọ của cây đạt từ 25 đến 30 năm. Cây có cành khá thưa, tán thoáng. Cành thường phát triển vuông góc với thân cây.\r\n– Trái thường có dạng hình trứng hoặc hình chữ nhật. Gai dày khoảng 1,25 cm. Phần cuống dài khoảng 5 đến 8 cm. Thông thường một trái sẽ nặng từ 2 đến 4,5 kg. Vỏ trái mỏng và có màng.', 100000, '2017-11-28 00:00:00', 'Ký', 'https://dailygiong.com/wp-content/uploads/2017/03/sau-rieng-monthong.jpg', 'TraiCay'),
(14, 'Cam sành', 'Một số do đặc điểm vận chuyển khó khan, khó bảo quản vì chúng có thể bị dập nát hay mất ngon trong quá trình vận chuyển.\r\nDo đó, những loại trái cây này được thu hoạch khi còn hơi xanh và cần có quá trình “chín sau”. Ngoài ra một số loại củ quả khác vì lý do dinh dưỡng cũng nên được để qua đêm hay vài ngày rồi mới sử dụng là tốt nhất.', 80000, '2017-11-28 00:00:00', 'Ký', 'http://sohanews.mediacdn.vn/thumb_w/640/2015/camsanhvietnam-1437765962573-39-0-294-500-crop-1437766214452.jpg', 'TraiCay');

-- --------------------------------------------------------

--
-- Table structure for table `TRANGTHAI_DONDATHANG`
--

CREATE TABLE IF NOT EXISTS `TRANGTHAI_DONDATHANG` (
  `MATRANGTHAI` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `DON_MATRANGTHAI` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `TRANGTHAI` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `USER_GIAOHANG`
--

CREATE TABLE IF NOT EXISTS `USER_GIAOHANG` (
  `MANGUOIGIAOHANG` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `USERNAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SDT1` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT2` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PHUONGTIEN` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BIENSOXE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGAYSINH` datetime DEFAULT NULL,
  `GIOITINH` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `USER_KHACHHANG`
--

CREATE TABLE IF NOT EXISTS `USER_KHACHHANG` (
  `MAKH` int(11) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `HOTEN` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_TINH` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_QUANHUYEN` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_PHUONGXA` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DC_SONHA_DUONG` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NGAYSINH` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GIOITINH` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MAKH`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `USER_KHACHHANG`
--

INSERT INTO `USER_KHACHHANG` (`MAKH`, `USERNAME`, `HOTEN`, `SDT`, `DC_TINH`, `DC_QUANHUYEN`, `DC_PHUONGXA`, `DC_SONHA_DUONG`, `NGAYSINH`, `GIOITINH`) VALUES
(9, 'hieu', 'trần đại lộc', '900', 'TP.Hồ Chí Minh', 'Quận 1', 'Hiệp Bình Chánh', '25 Phạm Văn Đồng', '18/11/2017', 'Nam'),
(12, 'loc', 'Trần Đại Lộc', '01667855307', 'TP.Hồ Chí Minh', 'Tân Phú', 'Tây Thạnh', '30 Lê Trọng Tấn', '18/11/2017', 'Nữ'),
(25, 'hieukh', 'lộc trần', '900', 'TP.Hồ Chí Minh', 'Thủ Đức', 'Hiệp Bình Chánh', 'Chùa An Lạc', '23/12/1996', 'Nam');

-- --------------------------------------------------------

--
-- Table structure for table `USER_NHACUNGCAP`
--

CREATE TABLE IF NOT EXISTS `USER_NHACUNGCAP` (
  `MANCC` int(11) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TENNHACUNGCAP` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT_CODINH` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SDT_DIDONG` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIACHI_NCC` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAMTHANHLAP` int(11) DEFAULT NULL,
  `WEBSITE` char(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `THONGTINCT` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK_ANH` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`MANCC`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `USER_NHACUNGCAP`
--

INSERT INTO `USER_NHACUNGCAP` (`MANCC`, `USERNAME`, `TENNHACUNGCAP`, `SDT_CODINH`, `SDT_DIDONG`, `DIACHI_NCC`, `NAMTHANHLAP`, `WEBSITE`, `THONGTINCT`, `LINK_ANH`) VALUES
(1, 'hieu6789', 'Ahihi company\n', '113', '114', '140 Lê Trọng Tấn', 1996, 'auduongvanhieu.xyz', 'Là một cty lớn nhất việt nam trong lĩnh vực it và cung cấp nông sản sạch', 'https://scontent.fsgn2-2.fna.fbcdn.net/v/t1.0-9/22853454_1399553976820613_9062337507231495626_n.jpg?_nc_eui2=v1%3AAeE9p2BGBq8PExMp81mAuog-khhUUJpH8piw3VPs-trolvfQr7vnvsuTH_IZcZ4ItcBDEdP3U9IzU4KUzQSWR8gwUZYGLEE7WJwRs0XM3Af_Eg&oh=56987b35ae95ffa3cb8c7088c71f4ed7&oe=5AD34639'),
(2, 'loc6789', 'Loc Combo', '900', '901', '140 Lê Trọng Tấn', 1996, 'locwebsite.com', 'Là một công ty uy tính hàng đầu việt năm trong lĩnh vực rau sạch', 'https://scontent.fsgn2-2.fna.fbcdn.net/v/t1.0-9/23755444_1609064849159454_3821681866976161107_n.jpg?oh=28af586bf76092e5a28ec23fca4dbb7b&oe=5AD55983');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
