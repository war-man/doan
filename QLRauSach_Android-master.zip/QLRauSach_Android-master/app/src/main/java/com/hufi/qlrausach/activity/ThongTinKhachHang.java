package com.hufi.qlrausach.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.CTDonHang;
import com.hufi.qlrausach.model.DonHang;
import com.hufi.qlrausach.model.UserKhachHang;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.Server;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ThongTinKhachHang extends AppCompatActivity {

    EditText edt_Ten,edt_Sdt,edt_Phuong,edt_SoNha,edt_NgaySinh;
    Spinner spinner_TP,spinner_Quan,spinner_GioiTinh;
    Button btn_ChonNgay,btn_XacNhan,btn_BoQua;
    Calendar cal;
    Date date;
    UserKhachHang userKhachHang;
    List<String> list_Quan;
    List<String> list_GioiTinh;
    ProgressDialog pDialog;
    public static boolean TinhTien;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin_khach_hang);

        AnhXa();
        XuLyCacNut();
        if (MainActivity.NguoiCMNDung!=null)
        {
            new GetTTKH().execute();
        }
    }

    private void XuLyCacNut() {
        btn_BoQua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Restart();
            }
        });
        btn_ChonNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Xử lý chọn ngày
                //Set ngày giờ hiện tại khi mới chạy lần đầu
                cal= Calendar.getInstance();
                SimpleDateFormat dft=null;
                //Định dạng kiểu ngày / tháng /năm
                dft=new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                String strDate=dft.format(cal.getTime());
                //hiển thị lên giao diện
                edt_NgaySinh.setText(strDate);
                date = cal.getTime();
                DatePickerDialog.OnDateSetListener callback=new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Set text cho textView
                        edt_NgaySinh.setText(dayOfMonth + "/" + (month+1) + "/" + year);
                        //Lưu vết lại ngày mới cập nhật
                        cal.set(year, month, dayOfMonth);
                        date = cal.getTime();
                    }
                };
                String s=edt_NgaySinh.getText()+"";
                //Lấy ra chuỗi của textView Date
                String strArrtmp[]=s.split("/");
                int ngay=Integer.parseInt(strArrtmp[0]);
                int thang=Integer.parseInt(strArrtmp[1]) - 1;
                int nam=Integer.parseInt(strArrtmp[2]);
                //Hiển thị ra Dialog
                DatePickerDialog pic=new DatePickerDialog(ThongTinKhachHang.this, callback, nam, thang, ngay);
                pic.setTitle("Chọn ngày hoàn thành");
                pic.show();
            }
        });

        btn_XacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String hoten=edt_Ten.getText().toString();
                final String sdt=edt_Sdt.getText().toString();
                final String tp=spinner_TP.getSelectedItem().toString();
                final String quan=spinner_Quan.getSelectedItem().toString();
                final String phuong=edt_Phuong.getText().toString();
                final String sonha=edt_SoNha.getText().toString();
                final String ngaysinh=edt_NgaySinh.getText().toString();
                final String gioitinh=spinner_GioiTinh.getSelectedItem().toString();
                //Lưu vào bảng User_NguoiDung
                RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
                String duongdan= Server.DuongDanUpDateUserKhachHang;
                StringRequest stringRequest=new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            int kq;
                            JSONObject jsonObject=new JSONObject(response);
                            kq =jsonObject.getInt("success");
                            if (kq ==1) {
                                CheckConnection.ShowToast_Short(getApplicationContext(), "Cập nhật thành công");
                            }
                            else {
                                CheckConnection.ShowToast_Short(getApplicationContext(), "Cập nhật thất bại");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> para=new HashMap<String,String>();
                        para.put("username",MainActivity.NguoiCMNDung.getUsername());
                        para.put("hoten",hoten);
                        para.put("sdt",sdt);
                        para.put("tp",tp);
                        para.put("quan",quan);
                        para.put("phuong",phuong);
                        para.put("sonha",sonha);
                        para.put("ngaysinh",ngaysinh);
                        para.put("gioitinh",gioitinh);
                        return para;
                    }
                };
                requestQueue.add(stringRequest);

                //Thêm vào bảng Đơn hàng
                if (TinhTien!=true) {
                    Restart();
                }
                else {
                    LuuVaoDonHang();
                }
            }
        });
    }

    void  LuuVaoDonHang()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String giodat=dateFormat.format(date).toString();
        String hesodonhang1=giodat.replace(" ","");
        String hesodonhang2=hesodonhang1.replace("/","");
        String hesodonhang=hesodonhang2.replace(":","");
        String madonhang="DH"+userKhachHang.getMakh()+hesodonhang;
        String tp=spinner_TP.getSelectedItem().toString();
        String quan=spinner_Quan.getSelectedItem().toString();
        String phuong=edt_Phuong.getText().toString();
        String sonha=edt_SoNha.getText().toString();
        int makh=userKhachHang.getMakh();
        int TongTien=0;
        for (int i=0;i<MainActivity.arrGioHang.size();i++)
        {
            TongTien+=(MainActivity.arrGioHang.get(i).getGia()*MainActivity.arrGioHang.get(i).getSoLuong());
        }
        TongTien+=20000;
        DonHang donHang=new DonHang(makh,madonhang,tp,quan,phuong,sonha,20000,giodat,TongTien);
        new ThemDonHang(donHang).execute();

        List<CTDonHang> ctDonHangs =new ArrayList<>();
        for (int i=0;i< MainActivity.arrGioHang.size();i++)
        {
            CTDonHang ctDonHang=new CTDonHang(madonhang,Integer.parseInt(MainActivity.arrGioHang.get(i).getMaSP()),MainActivity.arrGioHang.get(i).getSoLuong());
            ctDonHangs.add(ctDonHang);
        }
        new ThemCTDonHang(ctDonHangs).execute();

    }

    private void AnhXa() {
        edt_NgaySinh=(EditText) findViewById(R.id.edt_NgaySinh_TTKH_TTKH);
        edt_Phuong=(EditText) findViewById(R.id.edt_Phuong_TTKH);
        edt_Sdt=(EditText) findViewById(R.id.edt_Sdt_TTKH);
        edt_SoNha=(EditText) findViewById(R.id.edt_SoNha_TTKH);
        edt_Ten=(EditText) findViewById(R.id.edt_TenKH_TTKH);
        spinner_TP=(Spinner) findViewById(R.id.spinner_TP_TTKH);
        spinner_Quan=(Spinner) findViewById(R.id.spinner_Quan_TTKH);
        spinner_GioiTinh=(Spinner) findViewById(R.id.spinner_GioiTinh_TTKH);
        btn_ChonNgay= (Button) findViewById(R.id.btn_ChonNgay_TTKH);
        btn_XacNhan= (Button) findViewById(R.id.btn_XacNhan_TTKH);
        btn_BoQua= (Button) findViewById(R.id.btn_BoQua_TTKH);

        //Đổ dữ liệu cho Thành phố
        List<String> list_TP=new ArrayList<String>();
        list_TP.add("TP.Hồ Chí Minh");
        ArrayAdapter<String> adapter_TP=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,list_TP);
        adapter_TP.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_TP.setAdapter(adapter_TP);

        //Đổ dữ liệu cho Quận
        list_Quan=new ArrayList<String>();
        list_Quan.add("Quận 1"); list_Quan.add("Quận 2"); list_Quan.add("Quận 3"); list_Quan.add("Quận 4"); list_Quan.add("Quận 5");
        list_Quan.add("Quận 6"); list_Quan.add("Quận 7"); list_Quan.add("Quận 8"); list_Quan.add("Quận 9"); list_Quan.add("Quận 10");
        list_Quan.add("Quận 11"); list_Quan.add("Quận 12"); list_Quan.add("Quận Thủ Đức"); list_Quan.add("Quận Gò Vấp"); list_Quan.add("Quận Bình Thạnh");
        list_Quan.add("Quận Tân Bình"); list_Quan.add("Quận Tân Phú"); list_Quan.add("Quận Phú Nhuận"); list_Quan.add("Quận Bình Tân"); list_Quan.add("Huyện Củ Chi");
        list_Quan.add("Huyện Hóc Môn"); list_Quan.add("Huyện Bình Chánh"); list_Quan.add("Huyện Nhà Bè"); list_Quan.add("Huyện Cần Giờ");
        ArrayAdapter<String> adapter_Quan=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,list_Quan);
        adapter_Quan.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_Quan.setAdapter(adapter_Quan);

        //Đổ dữ liệu cho Giới tính
        list_GioiTinh=new ArrayList<String>();
        list_GioiTinh.add("Nam"); list_GioiTinh.add("Nữ");
        ArrayAdapter<String> adapter_GioiTinh=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,list_GioiTinh);
        adapter_GioiTinh.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_GioiTinh.setAdapter(adapter_GioiTinh);

    }

    public void Restart()
    {
        Intent i = getBaseContext().getPackageManager()
                .getLaunchIntentForPackage( getBaseContext().getPackageName() );
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public void getData()
    {
        edt_Ten.setText(userKhachHang.getHoten());
        edt_Sdt.setText(userKhachHang.getSdt());
        edt_Phuong.setText(userKhachHang.getDcphuongxa());
        edt_SoNha.setText(userKhachHang.getDcsonhaduong());
        edt_NgaySinh.setText(userKhachHang.getNgaysinh());

        spinner_Quan.setSelection(list_Quan.indexOf(userKhachHang.getDctinh()));
        spinner_GioiTinh.setSelection(list_GioiTinh.indexOf(userKhachHang.getGioitinh()));

    }

    public class GetTTKH extends AsyncTask<Object,Object,Object> {

        @Override
        protected Object doInBackground(Object[] params) {
            MyService jsonParser = new MyService();
            String duongdan=Server.DuongDanDisplayUserKhachHang+MainActivity.NguoiCMNDung.getUsername();
            String json = jsonParser.callService(duongdan, MyService.GET);
            if (json != null) {
                try {
                    json=json.replace("\uFEFF","");
                    JSONArray jsonArray = new JSONArray(json);
                    if (jsonArray != null) {
                        JSONObject jsonObject =jsonArray.getJSONObject(0);
                        int makh=jsonObject.getInt("makh");
                        String username=jsonObject.getString("username");
                        String hoten=jsonObject.getString("hoten");
                        String sdt=jsonObject.getString("sdt");
                        String dctinh=jsonObject.getString("dctinh");
                        String dcquanhuyen=jsonObject.getString("dcquanhuyen");
                        String dcphuongxa=jsonObject.getString("dcphuongxa");
                        String dcsonhaduong=jsonObject.getString("dcsonhaduong");
                        String ngaysinh=jsonObject.getString("ngaysinh");
                        String gioitinh=jsonObject.getString("gioitinh");
                        userKhachHang=new UserKhachHang(makh,username,hoten,sdt,dctinh,dcquanhuyen,dcphuongxa,dcsonhaduong,ngaysinh,gioitinh);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
            return null;
        }


        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(ThongTinKhachHang.this);
            pDialog.setMessage("Loading..");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected void onPostExecute(Object o) {

            super.onPostExecute(o);

            if (pDialog.isShowing())
                pDialog.dismiss();
            getData();
        }
    }

    class ThemDonHang extends AsyncTask {
        DonHang donHang;

        public ThemDonHang(DonHang donHang) {
            this.donHang = donHang;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            /*
            pDialog = new ProgressDialog(ThongTinKhachHang.this);
            pDialog.setMessage("Creating đơn hàng");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            */
        }

        @Override
        protected Object doInBackground(Object[] params) {

            // Tạo danh sách tham số gửi đến máy chủ
            List<NameValuePair> args = new ArrayList<>();
            args.add(new BasicNameValuePair("makh", donHang.getMakh()+""));
            args.add(new BasicNameValuePair("madonhang", donHang.getMadonhang()));
            args.add(new BasicNameValuePair("dctp", donHang.getDctp()));
            args.add(new BasicNameValuePair("dcquan", donHang.getDcquan()));
            args.add(new BasicNameValuePair("dcphuong", donHang.getDcphuong()));
            args.add(new BasicNameValuePair("dcsonha", donHang.getDcsonha()));
            args.add(new BasicNameValuePair("giodat", donHang.getGiodat()));
            args.add(new BasicNameValuePair("phivanchuyen", donHang.getPhivanchuyen()+""));
            args.add(new BasicNameValuePair("tongtien", donHang.getTongtien()+""));



            // Lấy đối tượng JSON
            MyService sh=new MyService();
            String json = sh.callService(Server.DuongDanCreateDonHang, MyService.POST, args);
            if (json != null) {
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    int success = jsonObject.getInt("success");
                    if (success == 1) {

                    } else {
                    }
                } catch (JSONException e) {
                    Log.d("Error...", e.toString());
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            //pDialog.dismiss();
        }
    }

    class ThemCTDonHang extends AsyncTask {
        List<CTDonHang> ctDonHangs;

        public ThemCTDonHang(List<CTDonHang> ctDonHangs) {
                this.ctDonHangs=ctDonHangs;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(ThongTinKhachHang.this);
            pDialog.setMessage("Tạo đơn hàng...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            for (int i=0;i<ctDonHangs.size();i++) {
                // Tạo danh sách tham số gửi đến máy chủ
                List<NameValuePair> args = new ArrayList<>();
                args.add(new BasicNameValuePair("madonhang", ctDonHangs.get(i).getMadonhang()));
                args.add(new BasicNameValuePair("masp", ctDonHangs.get(i).getMasp()+""));
                args.add(new BasicNameValuePair("soluong", ctDonHangs.get(i).getSoluong()+""));

                // Lấy đối tượng JSON
                MyService sh = new MyService();
                String json = sh.callService(Server.DuongDanCreateCTDonHang, MyService.POST, args);
                if (json != null) {
                    try {
                        JSONObject jsonObject = new JSONObject(json);
                        int success = jsonObject.getInt("success");
                        if (success == 1) {

                        } else {
                        }
                    } catch (JSONException e) {
                        Log.d("Error...", e.toString());
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            pDialog.dismiss();
            MainActivity.arrGioHang=null;
            Restart();
        }
    }

}
