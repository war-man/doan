package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 12/13/2017.
 */

public class ChiTietDH {
    SanPham sanpham;
    int soluong;

    public ChiTietDH() {}

    public ChiTietDH(SanPham sanpham, int soluong) {
        this.sanpham = sanpham;
        this.soluong = soluong;
    }

    public SanPham getSanpham() {
        return sanpham;
    }

    public void setSanpham(SanPham sanpham) {
        this.sanpham = sanpham;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }
}
