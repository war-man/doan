package com.hufi.qlrausach.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.model.UserNCC;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.Server;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.text.DecimalFormat;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChiTietSanPham extends AppCompatActivity {
    Toolbar toolbar_ChiTietSP;
    CircleImageView imageView_ChiTietSP;
    TextView txt_Ten,txt_Gia,txt_MoTa,txt_Dvt,txt_NCC;
    Button btn_ThemGioHang;
    Spinner spinner;
    String MaSP="";
    String TenSP="";
    String MoTa="";
    Integer DonGia=0;
    String NgaySX="";
    String DVT="";
    String LinkHinh="";
    String MaLoai="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_san_pham);

        AnhXa();
        ActionToolBar();
        GetInformation();
        CatchEventSpinner();
        EventButton();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_GioHang:
                Intent intent=new Intent(getApplicationContext(),GioHangActivity.class);
                startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    private void EventButton() {
        btn_ThemGioHang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.arrGioHang.size()>0){
                    int soluong=Integer.parseInt(spinner.getSelectedItem().toString());
                    boolean exist=false;
                    for (int i=0;i<MainActivity.arrGioHang.size();i++)
                    {
                        if (MainActivity.arrGioHang.get(i).getMaSP().compareTo(MaSP)==0){
                            MainActivity.arrGioHang.get(i).setSoLuong(MainActivity.arrGioHang.get(i).getSoLuong()+soluong);
                            //MainActivity.arrGioHang.get(i).setGia(MainActivity.arrGioHang.get(i).getSoLuong()*DonGia);
                            exist=true;
                        }
                    }
                    if(exist==false)
                    {
                        long Gia=soluong*DonGia;
                        MainActivity.arrGioHang.add(new GioHang(MaSP,TenSP,Gia,LinkHinh,soluong));
                    }
                }
                else {
                    int soluong=Integer.parseInt(spinner.getSelectedItem().toString());
                    long Gia=soluong*DonGia;
                    MainActivity.arrGioHang.add(new GioHang(MaSP,TenSP,Gia,LinkHinh,soluong));
                }
                Intent intent=new Intent(getApplicationContext(),GioHangActivity.class);
                startActivity(intent);
            }
        });
        imageView_ChiTietSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplication(),XemAnhActivity.class);
                intent.putExtra("linkHinh",LinkHinh);
                startActivity(intent);
            }
        });
    }

    private void CatchEventSpinner() {
        Integer soluong[] =  {1,2,3,4,5,6,7,8,9,10};
        ArrayAdapter<Integer> arrayAdapter=new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_dropdown_item,soluong);
        spinner.setAdapter(arrayAdapter);
    }

    private void GetInformation() {
        SanPham sanPham= (SanPham) getIntent().getSerializableExtra("thongtinsanpham");
        MaSP=sanPham.getMaSP();
        TenSP=sanPham.getTenSP();
        MoTa=sanPham.getMoTa();
        DonGia=sanPham.getDonGia();
        NgaySX=sanPham.getNgaySX();
        DVT=sanPham.getDVT();
        LinkHinh=sanPham.getLinkHinh();
        MaLoai=sanPham.getMaLoai();
        txt_Ten.setText(TenSP);
        DecimalFormat decimalFormat=new DecimalFormat("###,###,###");
        txt_Gia.setText("Giá: "+decimalFormat.format(DonGia)+" Đ");
        txt_MoTa.setText(MoTa);
        Picasso.with(getApplicationContext()).load(LinkHinh)
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(imageView_ChiTietSP);
        txt_Dvt.setText(DVT);
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        String duongdan=Server.DuongDanDisplayCTSPNCC+MaSP;
        StringRequest request=new StringRequest(Request.Method.GET, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                UserNCC userNCC=new UserNCC();
                try {
                    String json = response.replace("\uFEFF", "");
                    json = json.replace("ï»¿ï»¿", "");
                    JSONArray jsonArray = new JSONArray(json);
                    if (jsonArray != null) {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        int mancc = jsonObject.getInt("mancc");
                        String username = jsonObject.getString("username");
                        String tenncc = jsonObject.getString("tennhacungcap");
                        String sdtcodinh = jsonObject.getString("sdt_codinh");
                        String sdtdidong = jsonObject.getString("sdt_didong");
                        String diachi = jsonObject.getString("diachi_ncc");
                        String namthanhlap = jsonObject.getString("namthanhlap");
                        String website = jsonObject.getString("website");
                        String thongtinct = jsonObject.getString("thongtinct");
                        String linkhinh = jsonObject.getString("link_anh");
                        userNCC = new UserNCC(mancc, username, tenncc, sdtcodinh, sdtdidong, diachi, namthanhlap, website, thongtinct, linkhinh);
                    }
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
                txt_NCC.setText(userNCC.getTenncc());
                final UserNCC finalUserNCC = userNCC;
                txt_NCC.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent(getApplication(),ThongTinNCC.class);
                        intent.putExtra("thongtinncc", finalUserNCC);
                        startActivity(intent);
                    }
                });
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(request);

    }

    private void ActionToolBar() {
        setSupportActionBar(toolbar_ChiTietSP);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar_ChiTietSP.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void AnhXa() {
        toolbar_ChiTietSP=(Toolbar) findViewById(R.id.toolbar_ChiTietSP);
        imageView_ChiTietSP=(CircleImageView) findViewById(R.id.imageView_ChiTietSP);
        txt_Ten = (TextView)  findViewById(R.id.tv_Ten_ChiTietSP);
        txt_Gia=(TextView) findViewById(R.id.tv_Gia_ChiTietSP);
        txt_MoTa=(TextView) findViewById(R.id.tv_MoTa_ChiTietSP);
        btn_ThemGioHang=(Button) findViewById(R.id.btn_ThemGioHang_ChiTietSP);
        spinner=(Spinner) findViewById(R.id.spinner_ChiTietSP);
        txt_Dvt= (TextView) findViewById(R.id.tv_Dvt_ChiTietSP);
        txt_NCC= (TextView) findViewById(R.id.tv_NCC_ChiTietSP);
    }

}
