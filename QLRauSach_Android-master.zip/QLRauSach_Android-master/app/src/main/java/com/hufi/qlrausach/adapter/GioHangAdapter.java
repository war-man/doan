package com.hufi.qlrausach.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.hufi.qlrausach.R;
import com.hufi.qlrausach.activity.GioHangActivity;
import com.hufi.qlrausach.activity.MainActivity;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.model.GioHang;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Created by HieuPC on 11/1/2017.
 */

public class GioHangAdapter extends BaseAdapter {
    Context context;
    ArrayList<GioHang> arrGioHang;

    public GioHangAdapter(Context context, ArrayList<GioHang> arrGioHang) {
        this.context = context;
        this.arrGioHang = arrGioHang;
    }

    @Override
    public int getCount() {
        return arrGioHang.size();
    }

    @Override
    public Object getItem(int position) {
        return arrGioHang.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder
    {
        TextView txt_Ten_GioHang,txt_Gia_GioHang;
        ImageView imageView_GioHang;
        Button btn_Cong,btn_Tru,btn_SoLuong;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        GioHangAdapter.ViewHolder viewHolder=null;
        if(convertView==null)
        {
            viewHolder=new GioHangAdapter.ViewHolder();
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.dong_giohang,null);
            viewHolder.txt_Ten_GioHang= (TextView) convertView.findViewById(R.id.tv_Ten_DongGioHang);
            viewHolder.txt_Gia_GioHang= (TextView) convertView.findViewById(R.id.tv_Gia_DongGioHang);
            viewHolder.imageView_GioHang=(ImageView) convertView.findViewById(R.id.imageView_DongGioHang);
            viewHolder.btn_Cong=(Button) convertView.findViewById(R.id.btn_Cong_DongGioHang);
            viewHolder.btn_Tru=(Button) convertView.findViewById(R.id.btn_Tru_DongGioHang);
            viewHolder.btn_SoLuong=(Button) convertView.findViewById(R.id.btn_SoLuong_DongGioHang);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder=(GioHangAdapter.ViewHolder) convertView.getTag();
        }
        GioHang GioHang=(GioHang) getItem(position);
        viewHolder.txt_Ten_GioHang.setText(GioHang.getTenSP());
        DecimalFormat decimalFormat=new DecimalFormat("###,###,###");
        viewHolder.txt_Gia_GioHang.setText("Giá: "+decimalFormat.format(GioHang.getGia())+" Đ");
        viewHolder.btn_SoLuong.setText(GioHang.getSoLuong()+"");

        Picasso.with(context).load(GioHang.getHinh())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(viewHolder.imageView_GioHang);
        int sl=Integer.parseInt(viewHolder.btn_SoLuong.getText().toString());
        if(sl<=1)
        {
            viewHolder.btn_Tru.setVisibility(View.INVISIBLE);
        }
        else {
            viewHolder.btn_Tru.setVisibility(View.VISIBLE);
        }
        final ViewHolder finalViewHolder = viewHolder;
        viewHolder.btn_Cong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int slmoi=Integer.parseInt(finalViewHolder.btn_SoLuong.getText().toString())+1;
                MainActivity.arrGioHang.get(position).setSoLuong(slmoi);
                GioHangActivity.EventUltil();
                finalViewHolder.btn_SoLuong.setText(String.valueOf(slmoi));
                finalViewHolder.btn_Tru.setVisibility(View.VISIBLE);
            }
        });
        viewHolder.btn_Tru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int slmoi=Integer.parseInt(finalViewHolder.btn_SoLuong.getText().toString())-1;
                MainActivity.arrGioHang.get(position).setSoLuong(slmoi);
                GioHangActivity.EventUltil();
                if (slmoi<2)
                {
                    finalViewHolder.btn_Tru.setVisibility(View.INVISIBLE);
                }
                else {
                    finalViewHolder.btn_Tru.setVisibility(View.VISIBLE);
                }
                finalViewHolder.btn_SoLuong.setText(String.valueOf(slmoi));
            }
        });

        return convertView;
    }
}
