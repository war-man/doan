package com.hufi.qlrausach.model;

import java.io.Serializable;

/**
 * Created by HieuPC on 12/3/2017.
 */

public class UserNCC implements Serializable {
    int mancc;
    String username,tenncc,sdtcodinh,sdtdidong,diachi,namthanhlap,website,thongtinct,linkhinh;
    public int getMancc() {
        return mancc;
    }

    public UserNCC() {
    }

    public UserNCC(int mancc, String username, String tenncc, String sdtcodinh, String sdtdidong, String diachi, String namthanhlap, String website, String thongtinct, String linkhinh) {
        this.mancc = mancc;
        this.username = username;
        this.tenncc = tenncc;
        this.sdtcodinh = sdtcodinh;
        this.sdtdidong = sdtdidong;
        this.diachi = diachi;
        this.namthanhlap = namthanhlap;
        this.website = website;
        this.thongtinct = thongtinct;
        this.linkhinh = linkhinh;
    }

    public void setMancc(int mancc) {
        this.mancc = mancc;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTenncc() {
        return tenncc;
    }

    public void setTenncc(String tenncc) {
        this.tenncc = tenncc;
    }

    public String getSdtcodinh() {
        return sdtcodinh;
    }

    public void setSdtcodinh(String sdtcodinh) {
        this.sdtcodinh = sdtcodinh;
    }

    public String getSdtdidong() {
        return sdtdidong;
    }

    public void setSdtdidong(String sdtdidong) {
        this.sdtdidong = sdtdidong;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getNamthanhlap() {
        return namthanhlap;
    }

    public void setNamthanhlap(String namthanhlap) {
        this.namthanhlap = namthanhlap;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getThongtinct() {
        return thongtinct;
    }

    public void setThongtinct(String thongtinct) {
        this.thongtinct = thongtinct;
    }

    public String getLinkhinh() {
        return linkhinh;
    }

    public void setLinkhinh(String linkhinh) {
        this.linkhinh = linkhinh;
    }

}
