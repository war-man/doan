package com.hufi.qlrausach.activity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.hufi.qlrausach.R;
import com.hufi.qlrausach.adapter.GioHangAdapter;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.ultil.CheckConnection;

import java.text.DecimalFormat;

public class GioHangActivity extends AppCompatActivity {

    ListView lv_GioHang;
    TextView txt_ThongBao;
    static TextView txt_TongTien;
    Button btn_ThanhToan,btn_TiepTucMua;
    Toolbar toolbar_GioHang;
    GioHangAdapter giohangAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gio_hang);

        AnhXa();
        ActionToolBar();
        CheckData();
        EventUltil();
        CatchOnItemListview();
        ButtonEvent();
    }

    public void LuuGioHangVaoDB()
    {
        SQLiteDatabase myDB;
        myDB=openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        myDB.execSQL(
                "CREATE TABLE IF NOT EXISTS GioHang (MaSP VARCHAR(30) PRIMARY KEY,TenSP NVARCHAR(200),Gia int,Hinh NVARCHAR(500),SoLuong int )"
        );
        myDB.execSQL(
                "delete from GioHang"
        );
        for (int i=0;i<MainActivity.arrGioHang.size();i++)
        {
            try {
                GioHang gio=MainActivity.arrGioHang.get(i);
                ContentValues row1 = new ContentValues();
                row1.put("MaSP",gio.getMaSP());
                row1.put("TenSP",gio.getTenSP());
                row1.put("Gia",gio.getGia());
                row1.put("Hinh",gio.getHinh());
                row1.put("SoLuong",gio.getSoLuong());
                myDB.insert("GioHang", null, row1);
            }
            catch (Exception e)
            {

            }
        }
    }

    private void ButtonEvent() {
        btn_ThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(MainActivity.arrGioHang.size()>0)
                {
                    if (MainActivity.NguoiCMNDung!=null) {
                        Intent intent = new Intent(getApplicationContext(), ThongTinKhachHang.class);
                        startActivity(intent);
                        ThongTinKhachHang.TinhTien=true;
                    }
                    else {
                        Intent intent = new Intent(getApplicationContext(), DangNhapActivity.class);
                        startActivity(intent);
                    }
                }
                else {
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Giỏ hàng không có sản phẩm để thanh toán");
                }
            }
        });

        btn_TiepTucMua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void CatchOnItemListview() {
        lv_GioHang.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder=new AlertDialog.Builder(GioHangActivity.this);
                builder.setTitle("Xác nhận xóa sản phẩm");
                builder.setMessage("Bạn có chắc muốn xóa sản phẩm?");
                builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(MainActivity.arrGioHang.size()<=0)
                        {
                            txt_ThongBao.setVisibility(View.VISIBLE);
                        }
                        else {
                            MainActivity.arrGioHang.remove(position);
                            giohangAdapter.notifyDataSetChanged();
                            EventUltil();
                            if(MainActivity.arrGioHang.size()<=0)
                            {
                                txt_ThongBao.setVisibility(View.VISIBLE);
                            }
                            else {
                                txt_ThongBao.setVisibility(View.INVISIBLE);
                                giohangAdapter.notifyDataSetChanged();
                                EventUltil();
                            }
                        }
                    }
                });
                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        giohangAdapter.notifyDataSetChanged();
                        EventUltil();
                    }
                });
                builder.show();
                return true;
            }
        });
    }

    public static void EventUltil() {
        long TongTien=0;
        for (int i=0;i<MainActivity.arrGioHang.size();i++)
        {
            TongTien+=(MainActivity.arrGioHang.get(i).getGia()*MainActivity.arrGioHang.get(i).getSoLuong());
        }
        TongTien+=20000;
        DecimalFormat decimalFormat=new DecimalFormat("###,###,###");
        if (TongTien==20000)
            txt_TongTien.setText("0 Đ");
        else
            txt_TongTien.setText(decimalFormat.format(TongTien)+" Đ");
    }

    private void CheckData() {
        if (MainActivity.arrGioHang.size()<=0)
        {
            giohangAdapter.notifyDataSetChanged();
            txt_ThongBao.setVisibility(View.VISIBLE);
            lv_GioHang.setVisibility(View.INVISIBLE);
        }
        else {
            giohangAdapter.notifyDataSetChanged();
            txt_ThongBao.setVisibility(View.INVISIBLE);
            lv_GioHang.setVisibility(View.VISIBLE);
        }
    }

    private void ActionToolBar() {
        setSupportActionBar(toolbar_GioHang);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar_GioHang.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void AnhXa() {
        lv_GioHang=(ListView) findViewById(R.id.lv_GioHang);
        txt_ThongBao=(TextView) findViewById(R.id.tv_ThongBao_GioHang);
        txt_TongTien=(TextView) findViewById(R.id.tv_TongTien_GioHang);
        btn_ThanhToan=(Button) findViewById(R.id.btn_ThanhToan_GioHang);
        btn_TiepTucMua=(Button) findViewById(R.id.btn_TiepTuc_GioHang);
        toolbar_GioHang=(Toolbar) findViewById(R.id.toolbar_GioHang);
        giohangAdapter=new GioHangAdapter(GioHangActivity.this,MainActivity.arrGioHang);
        lv_GioHang.setAdapter(giohangAdapter);

    }


    @Override
    protected void onPause() {
        super.onPause();
        LuuGioHangVaoDB();
    }

}
