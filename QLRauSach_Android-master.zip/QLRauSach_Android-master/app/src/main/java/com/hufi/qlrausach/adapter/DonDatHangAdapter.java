package com.hufi.qlrausach.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.activity.ChiTietDonHangActivity;
import com.hufi.qlrausach.activity.MainActivity;
import com.hufi.qlrausach.activity.MapsActivity;
import com.hufi.qlrausach.model.DonDatHang;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by HieuPC on 12/11/2017.
 */

public class DonDatHangAdapter extends BaseAdapter {
    Context context;
    ArrayList<DonDatHang> arrDDH;

    public DonDatHangAdapter(Context context, ArrayList<DonDatHang> arr) {
        this.context = context;
        this.arrDDH = arr;
    }
    @Override
    public int getCount() {
        return arrDDH.size();
    }

    @Override
    public Object getItem(int position) {
        return arrDDH.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder=null;
        if(convertView==null)
        {
            viewHolder=new ViewHolder();
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.dong_donhang,null);
            viewHolder.txt_MaDH= (TextView) convertView.findViewById(R.id.tv_MaDonHang_dong_donhang);
            viewHolder.txt_TongTien= (TextView) convertView.findViewById(R.id.tv_TongTien_dong_donhang);
            viewHolder.txt_TenKH= (TextView) convertView.findViewById(R.id.tv_TenKH_dong_donhang);
            viewHolder.txt_DiaChi= (TextView) convertView.findViewById(R.id.tv_DiaChiGiao_dong_donhang);
            viewHolder.txt_Sdt= (TextView) convertView.findViewById(R.id.tv_SDT_dong_donhang);
            viewHolder.imv_GioiTinh= (ImageView) convertView.findViewById(R.id.imv_dong_donghang);
            viewHolder.checkB_TrangThai= (CheckBox) convertView.findViewById(R.id.checkB_TrangThai_dong_donhang);
            viewHolder.txt_DaGiao= (TextView) convertView.findViewById(R.id.tv_DaGiao_dong_donhang);


            convertView.setTag(viewHolder);
        }
        else {
            viewHolder=(ViewHolder) convertView.getTag();
        }
        final DonDatHang donDatHang=(DonDatHang) getItem(position);
        viewHolder.txt_MaDH.setText(donDatHang.getMadonhang());
        DecimalFormat decimalFormat=new DecimalFormat("###,###,###");
        viewHolder.txt_TongTien.setText("Tổng tiền: "+decimalFormat.format(donDatHang.getTongtien())+" đ");
        viewHolder.txt_TenKH.setText("Tên KH: "+donDatHang.getHoten());
        viewHolder.txt_DiaChi.setText("ĐC: "+donDatHang.getDiachi());
        viewHolder.txt_Sdt.setText("Sđt:"+donDatHang.getSdt());
        if (donDatHang.getGioitinh().compareTo("Nam")==0)
            viewHolder.imv_GioiTinh.setImageResource(R.drawable.boy);
        else
            viewHolder.imv_GioiTinh.setImageResource(R.drawable.girl);
        final ViewHolder finalViewHolder = viewHolder;
        viewHolder.imv_GioiTinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final PopupMenu popupMenu=new PopupMenu(context, finalViewHolder.txt_TongTien);
                popupMenu.getMenuInflater().inflate(R.menu.menu_popup,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId())
                        {
                            case R.id.popup_GoiDien:
                                intentCall(donDatHang.getSdt());
                                break;
                            case R.id.popup_ChiDuong:
                                Intent intent=new Intent(context, MapsActivity.class);
                                intent.putExtra("DiaChi",donDatHang.getDiachi());
                                context.startActivity(intent);
                                break;
                            case R.id.popup_DaGiao:
                                finalViewHolder.checkB_TrangThai.setChecked(true);
                                upDatTrangThaiDonHang(context,donDatHang.getMadonhang(),"Đã giao");
                                break;
                            case R.id.popup_HuyDon:
                                finalViewHolder.checkB_TrangThai.setVisibility(View.INVISIBLE);
                                finalViewHolder.txt_DaGiao.setVisibility(View.INVISIBLE);
                                upDatTrangThaiDonHang(context,donDatHang.getMadonhang(),"Đã huỷ");
                                break;
                            case R.id.popup_ChiTiet:
                                Intent intent1=new Intent(context, ChiTietDonHangActivity.class);
                                intent1.putExtra("ctdh",donDatHang);
                                context.startActivity(intent1);
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        if (donDatHang.getTrangthai().compareTo("Đã giao")==0)
            viewHolder.checkB_TrangThai.setChecked(true);
        else {
            if (donDatHang.getTrangthai().compareTo("Chưa giao")==0)
                viewHolder.checkB_TrangThai.setChecked(false);
            else {
                viewHolder.checkB_TrangThai.setVisibility(View.INVISIBLE);
                viewHolder.txt_DaGiao.setVisibility(View.INVISIBLE);
            }
        }
        return convertView;
    }

    public class ViewHolder
    {
        TextView txt_MaDH,txt_TongTien,txt_TenKH,txt_DiaChi,txt_Sdt,txt_DaGiao;
        ImageView imv_GioiTinh;
        CheckBox checkB_TrangThai;
    }
    private void intentCall(String sdt) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + sdt));
        context.startActivity(intent);
    }

    void upDatTrangThaiDonHang(final Context context, final String madonhang, final String trangthai)
    {
        RequestQueue requestQueue= Volley.newRequestQueue(context);
        String duongdan= Server.DuongDanUpDateDonHang;
        StringRequest stringRequest=new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    int kq;
                    JSONObject jsonObject=new JSONObject(response);
                    kq =jsonObject.getInt("success");
                    if (kq ==1) {
                        CheckConnection.ShowToast_Short(context, "Cập nhật thành công");
                    }
                    else {
                        CheckConnection.ShowToast_Short(context, "Cập nhật thất bại");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> para=new HashMap<String,String>();
                para.put("madonhang", madonhang);
                para.put("trangthai", trangthai);
                return para;
            }
        };
        requestQueue.add(stringRequest);
    }
}
