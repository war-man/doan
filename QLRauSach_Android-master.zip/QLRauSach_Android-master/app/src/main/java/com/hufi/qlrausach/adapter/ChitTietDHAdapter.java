package com.hufi.qlrausach.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.ChiTietDH;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by HieuPC on 12/13/2017.
 */

public class ChitTietDHAdapter extends BaseExpandableListAdapter {
    Context context;
    List<ChiTietDH> arrCTDH;

    public ChitTietDHAdapter(Context context, List<ChiTietDH> arrCTDH) {
        this.context = context;
        this.arrCTDH = arrCTDH;
    }

    @Override
    public int getGroupCount() {
        return arrCTDH.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return arrCTDH.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return arrCTDH.get(groupPosition).getSanpham();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=inflater.inflate(R.layout.group_ctdh_view,null);
        ImageView imv_SP= (ImageView) convertView.findViewById(R.id.imv_group_ctdh);
        TextView tv_TenSP= (TextView) convertView.findViewById(R.id.tv_TenSP_group_ctdh);
        TextView tv_SoLuong= (TextView) convertView.findViewById(R.id.tv_SoLuong_group_ctdh);
        //Đổ  dữ liệu lên các control
        Picasso.with(context).load(arrCTDH.get(groupPosition).getSanpham().getLinkHinh())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(imv_SP);
        tv_TenSP.setText(arrCTDH.get(groupPosition).getSanpham().getTenSP());
        tv_SoLuong.setText("Số lượng: "+arrCTDH.get(groupPosition).getSoluong());
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=inflater.inflate(R.layout.child_ctdh_view,null);
        TextView tv_MaSP= (TextView) convertView.findViewById(R.id.tv_MaSP_child_ctdh);
        TextView tv_DonGia= (TextView) convertView.findViewById(R.id.tv_DonGia_child_ctdh);
        TextView tv_DVT= (TextView) convertView.findViewById(R.id.tv_DonViTinh_child_ctdh);
        TextView tv_NgaySX= (TextView) convertView.findViewById(R.id.tv_NgaySanXuat_child_ctdh);
        //Đổ  dữ liệu lên các control
        tv_MaSP.setText("Mã sản phẩm: "+arrCTDH.get(groupPosition).getSanpham().getMaSP());
        tv_DonGia.setText("Đơn giá: "+arrCTDH.get(groupPosition).getSanpham().getDonGia());
        tv_DVT.setText("Đơn vị tính: "+arrCTDH.get(groupPosition).getSanpham().getDVT());
        tv_NgaySX.setText("Ngày sản xuất: "+arrCTDH.get(groupPosition).getSanpham().getNgaySX());
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
