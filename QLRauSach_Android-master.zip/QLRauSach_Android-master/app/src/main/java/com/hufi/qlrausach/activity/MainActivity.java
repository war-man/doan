package com.hufi.qlrausach.activity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ViewFlipper;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.adapter.LoaiSPAdapter;
import com.hufi.qlrausach.adapter.SanPhamAdapter;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.model.LoaiSP;
import com.hufi.qlrausach.model.NguoiDung;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.Server;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    ViewFlipper viewFlipper;
    RecyclerView recyclerView;
    NavigationView navigationView;
    ListView listView;
    DrawerLayout drawerLayout;
    ArrayList<LoaiSP> mangloaisp;
    ArrayList<LoaiSP> mangloaisp_main;
    LoaiSPAdapter loaiSPAdapter;
    String MaLoaiSP="";
    String TenLoaiSP="";
    String HinhAnhLoaiSP="";
    String CachBaoQuanLoaiSP;
    ArrayList<SanPham> mangSP;
    SanPhamAdapter sanPhamAdapter;
    public  static  ArrayList<GioHang> arrGioHang;
    SQLiteDatabase myDB;
    public static boolean Mo=false;
    public static NguoiDung NguoiCMNDung;
    String jsonSPMoi=null;
    String jsonLoaiSP=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AnhXa();
        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
        {
            ActionBar();
            ActionViewFlipper();
            new GetSPMoi().execute();
            CatchOnItemListView();
        }
        else
        {
            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nói nhé!");
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_GioHang:
                if (NguoiCMNDung==null||NguoiCMNDung.getLoaitk().compareTo("Khách hàng")==0) {
                    Intent intent = new Intent(getApplicationContext(), GioHangActivity.class);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(getApplicationContext(), DangSanPham.class);
                    startActivity(intent);
                }

        }

        return super.onOptionsItemSelected(item);
    }

    private void CatchOnItemListView() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            Restart();
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 1:
                        if (MainActivity.NguoiCMNDung==null) {
                            if (CheckConnection.haveNetworkConnection(getApplicationContext())) {
                                Intent intent = new Intent(MainActivity.this, DangNhapActivity.class);
                                startActivity(intent);
                            } else {
                                CheckConnection.ShowToast_Short(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối mạng");
                            }
                        }
                        else {
                            XoaUserTrongDB();
                            MainActivity.NguoiCMNDung=null;
                            Restart();
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 2:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            /*

                            */
                            PopupMenu popupMenu=new PopupMenu(MainActivity.this, toolbar);
                            popupMenu.getMenuInflater().inflate(R.menu.menu_sanpham,popupMenu.getMenu());
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                                @Override
                                public boolean onMenuItemClick(MenuItem item) {
                                    switch (item.getItemId())
                                    {
                                        case R.id.menu_RauXanh: {
                                            Intent intent = new Intent(MainActivity.this, RauXanhActivity.class);
                                            intent.putExtra("MaLoaiSP", mangloaisp_main.get(0).getMaLoaiSP());
                                            intent.putExtra("TenLoaiSP", mangloaisp_main.get(0).getTenLoaiSP());
                                            startActivity(intent);
                                            break;
                                        }
                                        case R.id.menu_Nam: {
                                            Intent intent = new Intent(MainActivity.this, RauXanhActivity.class);
                                            intent.putExtra("MaLoaiSP", mangloaisp_main.get(1).getMaLoaiSP());
                                            intent.putExtra("TenLoaiSP", mangloaisp_main.get(1).getTenLoaiSP());
                                            startActivity(intent);
                                            break;
                                        }
                                        case R.id.menu_TraiCay: {
                                            Intent intent = new Intent(MainActivity.this, RauXanhActivity.class);
                                            intent.putExtra("MaLoaiSP", mangloaisp_main.get(2).getMaLoaiSP());
                                            intent.putExtra("TenLoaiSP", mangloaisp_main.get(2).getTenLoaiSP());
                                            startActivity(intent);
                                            break;
                                        }
                                    }
                                    return false;
                                }
                            });
                            popupMenu.show();

                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 3:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            Intent intent = new Intent(MainActivity.this,LienHeActivity.class);
                            startActivity(intent);
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 4:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            Intent intent = new Intent(MainActivity.this,ThongTinActivity.class);
                            startActivity(intent);
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 5:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            if (NguoiCMNDung==null)
                            {
                                CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn chưa đăng nhập");
                            }
                            else
                            {
                                if (NguoiCMNDung.getLoaitk().compareTo("Khách hàng")==0) {
                                    Intent intent = new Intent(MainActivity.this, ThongTinKhachHang.class);
                                    startActivity(intent);
                                }
                                else
                                {
                                    if (NguoiCMNDung.getLoaitk().compareTo("Nhà cung cấp")==0) {
                                        Intent intent = new Intent(MainActivity.this, ThongTinNCC.class);
                                        startActivity(intent);
                                    }
                                    else
                                        CheckConnection.ShowToast_Short(getApplicationContext(),"Admin không được sửa");
                                }
                            }
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 6:
                        myDB.execSQL(
                                "delete from GioHang"
                        );
                        for (int i=0;i<arrGioHang.size();i++)
                        {
                            try {
                                GioHang gio=arrGioHang.get(i);
                                ContentValues row1 = new ContentValues();
                                row1.put("MaSP",gio.getMaSP());
                                row1.put("TenSP",gio.getTenSP());
                                row1.put("Gia",gio.getGia());
                                row1.put("Hinh",gio.getHinh());
                                row1.put("SoLuong",gio.getSoLuong());
                                myDB.insert("GioHang", null, row1);
                            }
                            catch (Exception e)
                            {

                            }
                        }
                        finish();
                        System.exit(0);
                        break;
                    case 7:
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                        {
                            Intent intent = new Intent(MainActivity.this,DonDatHangActivity.class);
                            startActivity(intent);
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                }
            }
        });
    }

    private void GetDuLieuSPMoiNhat() {
        jsonSPMoi=jsonSPMoi.replace("\uFEFF","");
        if (jsonSPMoi!=null) {
            JSONArray response = null;
            try {
                response = new JSONArray(jsonSPMoi);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (response != null) {
                String MaSP = "";
                String TenSP = "";
                String MoTa = "";
                Integer DonGia = 0;
                String NgaySX = "";
                String DVT = "";
                String LinkHinh = "";
                String MaLoai = "";
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        MaSP = jsonObject.getString("masp");
                        TenSP = jsonObject.getString("tensp");
                        MoTa = jsonObject.getString("mota");
                        DonGia = jsonObject.getInt("dongia");
                        NgaySX = jsonObject.getString("ngaysanxuat");
                        DVT = jsonObject.getString("dvt");
                        LinkHinh = jsonObject.getString("linkhinh");
                        MaLoai = jsonObject.getString("maloai");
                        mangSP.add(new SanPham(MaSP, TenSP, MoTa, DonGia, NgaySX, DVT, LinkHinh, MaLoai));
                        sanPhamAdapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void GetDuLieuLoaiSP() {
        jsonLoaiSP=jsonLoaiSP.replace("\uFEFF","");
        if (jsonSPMoi!=null) {
            JSONArray response = null;
            try {
                response = new JSONArray(jsonLoaiSP);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (response != null) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        MaLoaiSP = jsonObject.getString("maloaisp");
                        TenLoaiSP = jsonObject.getString("tenloaisp");
                        CachBaoQuanLoaiSP = jsonObject.getString("cachbaoquan");
                        HinhAnhLoaiSP = jsonObject.getString("hinhloaisp");
                        mangloaisp_main.add(new LoaiSP(MaLoaiSP, TenLoaiSP, CachBaoQuanLoaiSP, HinhAnhLoaiSP));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void ActionViewFlipper() {
        ArrayList<String> mangQC=new ArrayList<>();
        mangQC.add("http://danang.megafun.vn/dataimages/201009/original/images331821_10172310.jpg");
        mangQC.add("http://dantricdn.com/a3HWDOlTcvMNT73KRccc/Image/2014/05/6-42599.jpg");
        mangQC.add("http://thedelight.vn/ckfinder/userfiles/images/T270420171008/nhung-loi-ich-cua-rau-xanh-2.jpg");
        mangQC.add("http://www.chuabenhgut.com/wp-content/uploads/2016/09/nhung-rau-xanh-can-thiet-cho-nguoi-benh-gut.jpg");
        mangQC.add("http://media2.onbox.vn:8088/onbox/images/20160405/966275.jpg?e=8bf7d09c2b3fcd8b0478f1f4a9f65590");
        mangQC.add("http://s2.dmcdn.net/I6MkJ/1280x720-IiW.jpg");
        for (int i=0;i<mangQC.size();i++) {
            ImageView imageView=new ImageView(getApplicationContext());
            Picasso.with(getApplicationContext()).load(mangQC.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            viewFlipper.addView(imageView);
            viewFlipper.setFlipInterval(5000);
            viewFlipper.setAutoStart(true);
            Animation animation_slide_in = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_in_right);
            Animation animation_slide_out = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_out_right);
            viewFlipper.setInAnimation(animation_slide_in);
            viewFlipper.setOutAnimation(animation_slide_out);
        }
    }

    private void AnhXa() {

        toolbar = (Toolbar) findViewById(R.id.toolbar_Main);
        viewFlipper= (ViewFlipper) findViewById(R.id.viewFlipper_Main);
        recyclerView= (RecyclerView) findViewById(R.id.recyclerView_Main);
        navigationView= (NavigationView) findViewById(R.id.navigationView_Main);
        listView = (ListView) findViewById(R.id.listView_Main);
        drawerLayout= (DrawerLayout) findViewById(R.id.drawerLayout_Main);
        mangloaisp=new ArrayList<>();
        mangloaisp_main=new ArrayList<>();
        mangloaisp.add(0,new LoaiSP("","Trang chính","","http://icons.iconarchive.com/icons/hopstarter/sleek-xp-basic/256/Home-icon.png"));
        LoadNguoiDung();
        if (NguoiCMNDung==null)
            mangloaisp.add(1,new LoaiSP("","Đăng nhập","","https://4.bp.blogspot.com/-zViTfoazhuA/WVxtsIZDC_I/AAAAAAAADsk/rqpX6tekjsIvEANOfQXuW3osWXVpIZGEwCLcBGAs/s1600/icon-qq.jpg"));
        else
            mangloaisp.add(1,new LoaiSP("","Đăng xuất","","https://lamsaodevao.com/wp-content/uploads/2016/11/logout-icon-512x510.png"));
        mangloaisp.add(new LoaiSP("", "Sản phẩm", "", "http://icons.iconarchive.com/icons/icons-land/multiple-smiley/64/Flower-Nerd-icon.png"));
        mangloaisp.add(new LoaiSP("", "Liên hệ", "", "https://adwordsvietnam.com/images/so-dien-thoai-lien-he-ho-tro-cua-google-tai-vietnam.png"));
        mangloaisp.add(new LoaiSP("", "Trụ sở", "", "http://baovecuocsong.com.vn/uploads/news/1889339220_thong_itn.png"));
        mangloaisp.add(new LoaiSP("", "Cá nhân", "", "http://icons.iconarchive.com/icons/icons-land/vista-people/32/Groups-Rescuers-Light-icon.png"));
        mangloaisp.add(new LoaiSP("", "Thoát", "", "https://nhathuocanduoc.vn/images/stories/dau-x.png"));
        if (NguoiCMNDung!=null)
            if (NguoiCMNDung.getLoaitk().compareTo("Admin")==0||NguoiCMNDung.getLoaitk().compareTo("Nhà cung cấp")==0)
                mangloaisp.add(new LoaiSP("", "Đơn đặt hàng", "", "http://icons.iconarchive.com/icons/pelfusion/long-shadow-media/48/Document-icon.png"));
        loaiSPAdapter=new LoaiSPAdapter(mangloaisp,getApplicationContext());
        listView.setAdapter(loaiSPAdapter);
        mangSP=new ArrayList<>();
        sanPhamAdapter=new SanPhamAdapter(MainActivity.this,mangSP);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        recyclerView.setAdapter(sanPhamAdapter);
        if(arrGioHang==null)
        {
            arrGioHang=new ArrayList<>();
        }
        LoadGioHang();
    }

    void LoadGioHang()
    {
        if(Mo==false) {
            myDB=openOrCreateDatabase("my.db", MODE_PRIVATE, null);
            myDB.execSQL(
                    "CREATE TABLE IF NOT EXISTS GioHang (MaSP VARCHAR(30) PRIMARY KEY,TenSP NVARCHAR(200),Gia int,Hinh NVARCHAR(500),SoLuong int )"
            );
            Cursor myCursor =
                    myDB.rawQuery("select * from GioHang", null);
            while(myCursor.moveToNext()) {
                String MaSP=myCursor.getString(0);;
                String TenSP=myCursor.getString(1);;
                long Gia=myCursor.getInt(2);;
                String Hinh=myCursor.getString(3);;
                int SoLuong=myCursor.getInt(4);;
                GioHang gio=new GioHang(MaSP,TenSP,Gia,Hinh,SoLuong);
                arrGioHang.add(gio);
            }
            Mo=true;
        }
    }

    void LoadNguoiDung()
    {
        myDB=openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        myDB.execSQL(
                "CREATE TABLE IF NOT EXISTS NguoiDung (username VARCHAR(50) PRIMARY KEY,password VARCHAR(50),loaitk NVARCHAR(100),email VARCHAR(50) )"
        );
        Cursor myCursor2 =
                myDB.rawQuery("select username,password,loaitk,email from NguoiDung", null);
        while(myCursor2.moveToNext()) {
            String username=myCursor2.getString(0);
            String password=myCursor2.getString(1);
            String loaitk=myCursor2.getString(3);
            String email=myCursor2.getString(2);
            NguoiCMNDung=new NguoiDung(username,password,loaitk,email);
        }
        if (NguoiCMNDung!=null)
            toolbar.setTitle("Trang chính - Hi:"+NguoiCMNDung.getUsername());
    }

    private void ActionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    public void XoaUserTrongDB()
    {
        SQLiteDatabase myDB;
        myDB=openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        myDB.execSQL(
                "CREATE TABLE IF NOT EXISTS NguoiDung (username VARCHAR(50) PRIMARY KEY,password VARCHAR(50),loaitk NVARCHAR(100),email VARCHAR(50) )"
        );
        myDB.execSQL(
                "delete from NguoiDung"
        );
    }

    public void Restart()
    {
        Intent i = getBaseContext().getPackageManager()
                .getLaunchIntentForPackage( getBaseContext().getPackageName() );
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public class GetSPMoi extends AsyncTask<Object,Object,Object> {
        @Override
        protected Object doInBackground(Object[] params) {
            MyService jsonParser = new MyService();
            jsonSPMoi = jsonParser.callService(Server.DuongDanSPMoiNhat, MyService.GET);
            MyService jsonParser2 = new MyService();
            jsonLoaiSP = jsonParser2.callService(Server.DuongDanLoaiSP, MyService.GET);
            return null;
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            GetDuLieuSPMoiNhat();
            GetDuLieuLoaiSP();
        }
    }
}
