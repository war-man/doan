package com.hufi.qlrausach.activity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.RealPathUtil;
import com.hufi.qlrausach.ultil.Server;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.hufi.qlrausach.R.id.imageView_DangSP;

public class DangSanPham extends AppCompatActivity {

    EditText edt_TenSP,edt_MoTa,edt_DonGia,edt_DVT,edt_NgaySX;
    Button btn_ChonHinh,btn_Save,btn_ChonNgay;
    ImageView imageView;
    Spinner spinner_LoaiSP;
    List<String> list_LoaiSP;
    Calendar cal;
    Date date;
    Button btn_Huy;
    String Loais[]={"RauXanh","TraiCay","Nam"};
    ProgressDialog pDialog;

    //UpHinh
    int success;
    String imgName;
    String imgCode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_san_pham);

        AnhXa();
        XuLyNut();
    }

    private void XuLyNut() {
        //Xử lý chọn ngày
        //Set ngày giờ hiện tại khi mới chạy lần đầu
        cal= Calendar.getInstance();
        SimpleDateFormat dft=null;
        //Định dạng kiểu ngày / tháng /năm
        dft=new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String strDate=dft.format(cal.getTime());
        //hiển thị lên giao diện
        edt_NgaySX.setText(strDate);
        date = cal.getTime();
        btn_ChonNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog.OnDateSetListener callback=new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Set text cho textView
                        edt_NgaySX.setText(dayOfMonth + "/" + (month+1) + "/" + year);
                        //Lưu vết lại ngày mới cập nhật
                        cal.set(year, month, dayOfMonth);
                        date = cal.getTime();
                    }
                };
                String s=edt_NgaySX.getText()+"";
                //Lấy ra chuỗi của textView Date
                String strArrtmp[]=s.split("/");
                int ngay=Integer.parseInt(strArrtmp[0]);
                int thang=Integer.parseInt(strArrtmp[1]) - 1;
                int nam=Integer.parseInt(strArrtmp[2]);
                //Hiển thị ra Dialog
                DatePickerDialog pic=new DatePickerDialog(DangSanPham.this, callback, nam, thang, ngay);
                pic.setTitle("Chọn ngày hoàn thành");
                pic.show();
            }
        });

        btn_ChonHinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermistion();
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 0);
            }
        });

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String TenSP=edt_TenSP.getText().toString();
                String MoTa=edt_MoTa.getText().toString();
                Integer DonGia=Integer.parseInt(edt_DonGia.getText().toString());
                String NgaySX=edt_NgaySX.getText().toString();
                String DVT=edt_DVT.getText().toString();
                String LinkHinh="";
                String arrMaLoai[]={"RauXanh","Nam","TraiCay"};
                String MaLoai=arrMaLoai[spinner_LoaiSP.getSelectedItemPosition()];
                SanPham sanPham=new SanPham(null,TenSP,MoTa,DonGia,NgaySX,DVT,LinkHinh,MaLoai);
                new  ThemSanPham(sanPham).execute();

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0 && resultCode == DangSanPham.this.RESULT_OK) {
            String PATH= RealPathUtil.getPath(DangSanPham.this, data.getData());
            Uri uri = Uri.fromFile(new File(PATH));
            // Get name
            imgName = PATH.substring(PATH.lastIndexOf("/")+1);
            Toast.makeText(DangSanPham.this, imgName, Toast.LENGTH_LONG).show();
            Bitmap bitmap=null;
            try {
                //Get BitMap
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            imgCode = getBitMap(bitmap);
            // Load image
            Glide.with(DangSanPham.this).load(uri).override(420, 594).centerCrop().into(imageView);
            Toast.makeText(this, PATH, Toast.LENGTH_LONG).show();

        }
    }
    // Encode bitmap to String
    public String getBitMap(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }





    private void AnhXa() {
        edt_TenSP= (EditText) findViewById(R.id.edt_TenSP_DangSP);
        edt_MoTa= (EditText) findViewById(R.id.edt_MoTa_DangSP);
        edt_DonGia= (EditText) findViewById(R.id.edt_DonGia_DangSP);
        edt_DVT= (EditText) findViewById(R.id.edt_DVT_DangSP);
        edt_NgaySX= (EditText) findViewById(R.id.edt_NgaySX_DangSP);
        btn_ChonHinh= (Button) findViewById(R.id.btn_ChọnHinh_DangSp);
        btn_Save= (Button) findViewById(R.id.btn_XacNhan_DangSP);
        btn_ChonNgay= (Button) findViewById(R.id.btn_ChonNgay_DangSp);
        btn_Huy= (Button) findViewById(R.id.btn_Huy_DangSP);
        spinner_LoaiSP=(Spinner) findViewById(R.id.spinner_LoaiSP_DangSP);
        imageView = (ImageView) findViewById(imageView_DangSP);
        edt_DonGia.setText("000");

        //Đổ dữ liệu cho Loai sp
        List<String> list_TP=new ArrayList<String>();
        list_TP.add("Rau Xanh"); list_TP.add("Trái cây"); list_TP.add("Nấm");
        ArrayAdapter<String> adapter_TP=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,list_TP);
        adapter_TP.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_LoaiSP.setAdapter(adapter_TP);
    }

    class ThemSanPham extends AsyncTask {
        SanPham sanPham;

        public ThemSanPham(SanPham donHang) {
            this.sanPham = donHang;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(DangSanPham.this);
            pDialog.setMessage("Thêm sản phẩm....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

        }

        @Override
        protected Object doInBackground(Object[] params) {

            // Tạo danh sách tham số gửi đến máy chủ
            List<NameValuePair> args = new ArrayList<>();
            args.add(new BasicNameValuePair("tensp", sanPham.getTenSP()));
            args.add(new BasicNameValuePair("mota", sanPham.getMoTa()));
            args.add(new BasicNameValuePair("dongia", sanPham.getDonGia()+""));
            args.add(new BasicNameValuePair("ngaysx", sanPham.getNgaySX()));
            args.add(new BasicNameValuePair("dvt", sanPham.getDVT()));
            args.add(new BasicNameValuePair("linkhinh", sanPham.getLinkHinh()));
            args.add(new BasicNameValuePair("maloai", sanPham.getMaLoai()));
            args.add(new BasicNameValuePair("imageName", imgName));
            args.add(new BasicNameValuePair("imageCode", imgCode));
            args.add(new BasicNameValuePair("username", MainActivity.NguoiCMNDung.getUsername()));

            // Lấy đối tượng JSON
            MyService sh=new MyService();
            String json = sh.callService(Server.DuongDanCreateSanPham, MyService.POST, args);
            if (json != null) {
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    success = jsonObject.getInt("success");
                    if (success == 1) {

                    } else {
                    }
                } catch (JSONException e) {
                    Log.d("Error...", e.toString());
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            pDialog.dismiss();
            VeTrangChu();
        }
    }

    private void VeTrangChu() {
        CheckConnection.ShowToast_Short(getApplicationContext(),"Đăng sản phẩm thành công");
        Restart();
    }

    public void Restart()
    {
        Intent i = getBaseContext().getPackageManager()
                .getLaunchIntentForPackage( getBaseContext().getPackageName() );
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    //Check permistion android 6.0
    private void checkPermistion() {
        if (ContextCompat.checkSelfPermission(DangSanPham.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(DangSanPham.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(DangSanPham.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);
            }
        }
    }

}
