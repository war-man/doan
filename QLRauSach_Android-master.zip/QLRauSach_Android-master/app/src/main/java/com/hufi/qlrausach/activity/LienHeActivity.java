package com.hufi.qlrausach.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.hufi.qlrausach.R;
import com.hufi.qlrausach.ultil.CheckConnection;

public class LienHeActivity extends AppCompatActivity {

    ImageButton btn_Back,btn_Next,btn_Reload;
    Button btn_Search;
    EditText edt_Url;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lien_he);
        
        AnhXa();
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.facebook.com/dung.ho.14224");
        edt_Url.setText(webView.getUrl());
        btn_Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url;
                if(edt_Url.getText().toString().contains("http://"))
                    url=edt_Url.getText().toString().trim();
                else
                    url="http://"+edt_Url.getText().toString().trim();
                webView.loadUrl(url);
                edt_Url.setText(webView.getUrl());
            }
        });
        btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(webView.canGoBack())
                {
                    webView.goBack();
                    edt_Url.setText(webView.getUrl());
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Trang trước");
                }
                else
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Không có trang trước để trở về");
            }
        });
        btn_Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(webView.canGoForward())
                {
                    webView.goForward();
                    edt_Url.setText(webView.getUrl());
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Trang sau");
                }
                else
                    CheckConnection.ShowToast_Short(getApplicationContext(),"Không có trang sau để đi tới");
            }
        });

        btn_Reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webView.reload();
                edt_Url.setText(webView.getUrl());
            }
        });

        WebSettings webSettings=webView.getSettings();
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setJavaScriptEnabled(true);

    }

    private void AnhXa() {
        btn_Back= (ImageButton) findViewById(R.id.btn_Back_LienHe);
        btn_Next= (ImageButton) findViewById(R.id.btn_Next_LienHe);
        btn_Reload= (ImageButton) findViewById(R.id.btn_Reload_LienHe);
        btn_Search= (Button) findViewById(R.id.btn_Search_LienHe);
        edt_Url= (EditText) findViewById(R.id.edt_Url_LienHe);
        webView= (WebView) findViewById(R.id.webview_LienHe);
    }
}
