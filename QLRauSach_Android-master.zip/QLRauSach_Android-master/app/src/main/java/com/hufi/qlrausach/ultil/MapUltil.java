package com.hufi.qlrausach.ultil;

/**
 * Created by HieuPC on 12/15/2017.
 */

public class MapUltil {
    static public final int MY_PERMISSION_REQUEST_CODE=5196;
    static public final int PLAY_SERVICES_RESOLUTION_REQUEST=29296;

    public static int UPDATE_INTERVAL=5000;
    public static int FATEST_INTERVAL=3000;
    public static int DISPLAYMENT=10;

    public static final String DIRECTION_URL_API = "https://maps.googleapis.com/maps/api/directions/json?";
    public static final String GOOGLE_API_KEY = "AIzaSyCCeqOuWnoWj8hA-OcY9lSYqS9oF-_g9JE";
}
