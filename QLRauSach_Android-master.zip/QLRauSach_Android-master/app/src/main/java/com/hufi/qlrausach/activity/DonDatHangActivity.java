package com.hufi.qlrausach.activity;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.adapter.DonDatHangAdapter;
import com.hufi.qlrausach.adapter.RauxanhAdapter;
import com.hufi.qlrausach.model.DonDatHang;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DonDatHangActivity extends AppCompatActivity {

    ListView lv_DonHang;
    Toolbar toolbar_DonHang;
    DonDatHangAdapter datHangAdapter;
    ArrayList<DonDatHang> arrDDH;
    int page=1;
    View footerview;
    boolean isLoading=false;
    DonDatHangActivity.mHandler mHandler;
    boolean limitData=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_don_dat_hang);
        AnhXa();
        ActionToolBar();
        checkAndRequestPermissions();
        GetData();
        LoadMoreData();


    }

    private void AnhXa() {
        toolbar_DonHang=(Toolbar) findViewById(R.id.toolbar_DonHang);
        lv_DonHang=(ListView) findViewById(R.id.lv_DonDatHang);
        arrDDH=new ArrayList<>();
        datHangAdapter=new DonDatHangAdapter(DonDatHangActivity.this,arrDDH);
        lv_DonHang.setAdapter(datHangAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        footerview=inflater.inflate(R.layout.progressbar,null);
        mHandler = new DonDatHangActivity.mHandler();
    }

    private void ActionToolBar() {
        setSupportActionBar(toolbar_DonHang);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar_DonHang.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    public boolean isChangingConfigurations() {
        return super.isChangingConfigurations();
    }

    public class mHandler extends Handler
    {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 0:
                    lv_DonHang.addFooterView(footerview);
                    break;
                case 1:
                    page++;
                    GetData();
                    isLoading=false;
                    break;
            }
            super.handleMessage(msg);
        }
    }

    public class ThreadData extends Thread{
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
            try {

                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message=mHandler.obtainMessage(1);
            mHandler.sendMessage(message);
            super.run();
        }
    }

    private void GetData() {
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        String duongdan= Server.DuongDanDisplayDonHang+page;
        StringRequest stringRequest=new StringRequest(Request.Method.GET, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Xu ly json
                if (response!=null) {
                    String str=response.replace("\uFEFF","");
                    str=str.replace("ï»¿ï»¿","");
                    JSONArray json = null;
                    try {
                        json = new JSONArray(str);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (json != null) {
                        lv_DonHang.removeFooterView(footerview);
                        try {
                            for (int i = 0; i < json.length(); i++) {
                                JSONObject jsonObject = json.getJSONObject(i);
                                String MaDH = jsonObject.getString("madonhang");
                                int TongTien = jsonObject.getInt("tongtien");
                                String DiaChi= jsonObject.getString("diachi");
                                String MaKH= jsonObject.getString("makh");
                                String HoTen= jsonObject.getString("hoten");
                                String Sdt= jsonObject.getString("sdt");
                                String NgaySinh= jsonObject.getString("ngaysinh");
                                String GioiTinh= jsonObject.getString("gioitinh");
                                String TrangThai= jsonObject.getString("trangthai");
                                String GioDat= jsonObject.getString("giodat");

                                arrDDH.add(new DonDatHang(MaDH,TongTien,DiaChi,MaKH,HoTen,Sdt,NgaySinh,GioiTinh,TrangThai,GioDat));
                                datHangAdapter.notifyDataSetChanged();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
                        limitData = true;
                        lv_DonHang.removeFooterView(footerview);
                        CheckConnection.ShowToast_Short(getApplicationContext(), "Đã hết dữ liệu");
                    }
                }
                //Het json
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(stringRequest);

    }

    private void LoadMoreData() {

        try {
            lv_DonHang.setOnScrollListener(new AbsListView.OnScrollListener() {

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                    if(firstVisibleItem+visibleItemCount==totalItemCount && totalItemCount!=0 && isLoading==false && limitData==false)
                    {
                        isLoading=true;
                        DonDatHangActivity.ThreadData threadData=new DonDatHangActivity.ThreadData();
                        threadData.start();
                    }

                }
                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {

                }
            });
        }
        catch (Exception ex) {
            CheckConnection.ShowToast_Short(getApplicationContext(),ex.toString());
        }
    }


    private void checkAndRequestPermissions() {
        String[] permissions = new String[]{
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS
        };
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(permission);
            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    1);
        }
    }
}
