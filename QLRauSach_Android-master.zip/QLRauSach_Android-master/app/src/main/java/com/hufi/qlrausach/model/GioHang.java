package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 11/1/2017.
 */

public class GioHang {
    public String MaSP;
    public String TenSP;
    public long Gia;
    public String Hinh;
    public int SoLuong;

    public GioHang(String maSP, String tenSP, long gia, String hinh, int soLuong) {
        MaSP = maSP;
        TenSP = tenSP;
        Gia = gia;
        Hinh = hinh;
        SoLuong = soLuong;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String maSP) {
        MaSP = maSP;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String tenSP) {
        TenSP = tenSP;
    }

    public long getGia() {
        return Gia;
    }

    public void setGia(long gia) {
        Gia = gia;
    }

    public String getHinh() {
        return Hinh;
    }

    public void setHinh(String hinh) {
        Hinh = hinh;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }
}
