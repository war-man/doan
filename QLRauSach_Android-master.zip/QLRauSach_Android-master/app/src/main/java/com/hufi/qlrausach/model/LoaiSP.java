package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 10/14/2017.
 */

public class LoaiSP {
    public String MaLoaiSP;
    public String TenLoaiSP;
    public String CachBaoQuanLoaiSP;
    public String HinhAnhLoaiSP;

    public LoaiSP(String maLoaiSP, String tenLoaiSP, String cachBaoQuanLoaiSP, String hinhAnhLoaiSP) {
        MaLoaiSP = maLoaiSP;
        TenLoaiSP = tenLoaiSP;
        CachBaoQuanLoaiSP = cachBaoQuanLoaiSP;
        HinhAnhLoaiSP = hinhAnhLoaiSP;
    }

    public String getMaLoaiSP() {
        return MaLoaiSP;
    }

    public void setMaLoaiSP(String maLoaiSP) {
        MaLoaiSP = maLoaiSP;
    }

    public String getTenLoaiSP() {
        return TenLoaiSP;
    }

    public void setTenLoaiSP(String tenLoaiSP) {
        TenLoaiSP = tenLoaiSP;
    }

    public String getCachBaoQuanLoaiSP() {
        return CachBaoQuanLoaiSP;
    }

    public void setCachBaoQuanLoaiSP(String cachBaoQuanLoaiSP) {
        CachBaoQuanLoaiSP = cachBaoQuanLoaiSP;
    }

    public String getHinhAnhLoaiSP() {
        return HinhAnhLoaiSP;
    }

    public void setHinhAnhLoaiSP(String hinhAnhLoaiSP) {
        HinhAnhLoaiSP = hinhAnhLoaiSP;
    }
}
