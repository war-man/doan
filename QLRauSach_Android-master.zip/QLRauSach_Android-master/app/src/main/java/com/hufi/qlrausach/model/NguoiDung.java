package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 11/11/2017.
 */

public class NguoiDung {
    String username,password,loaitk,email;

    public NguoiDung(String username, String password, String loaitk, String email) {
        this.username = username;
        this.password = password;
        this.loaitk = loaitk;
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLoaitk() {
        return loaitk;
    }

    public void setLoaitk(String loaitk) {
        this.loaitk = loaitk;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
