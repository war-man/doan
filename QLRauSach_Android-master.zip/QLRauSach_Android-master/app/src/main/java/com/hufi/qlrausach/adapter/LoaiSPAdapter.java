package com.hufi.qlrausach.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.LoaiSP;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by HieuPC on 10/14/2017.
 */

public class LoaiSPAdapter extends BaseAdapter {
    ArrayList<LoaiSP> loaiSPArrayList;

    public LoaiSPAdapter(ArrayList<LoaiSP> loaiSPArrayList, Context context) {
        this.loaiSPArrayList = loaiSPArrayList;
        this.context = context;
    }

    Context context;

    @Override
    public int getCount() {
        return loaiSPArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return loaiSPArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public  class ViewHolder
    {
        TextView txtTenLoaiSP;
        ImageView imageLoaiSP;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder=null;
        if(convertView==null)
        {
            viewHolder=new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.dong_listview_loaisp,null);
            viewHolder.txtTenLoaiSP= (TextView) convertView.findViewById(R.id.textViewLoaiSP);
            viewHolder.imageLoaiSP= (ImageView) convertView.findViewById(R.id.imageViewLoaiSP);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder= (ViewHolder) convertView.getTag();
        }
        LoaiSP loaiSP = (LoaiSP) getItem(position);
        viewHolder.txtTenLoaiSP.setText(loaiSP.getTenLoaiSP());
        Picasso.with(context).load(loaiSP.getHinhAnhLoaiSP())
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(viewHolder.imageLoaiSP);
        return convertView;
    }
}
