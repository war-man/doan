package com.hufi.qlrausach.activity;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.DirectionFinder;
import com.hufi.qlrausach.model.DirectionFinderListener;
import com.hufi.qlrausach.model.Route;
import com.hufi.qlrausach.ultil.MapUltil;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MapsActivity extends FragmentActivity implements GoogleMap.OnMyLocationButtonClickListener,
        OnMapReadyCallback, DirectionFinderListener,GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,LocationListener{

    private GoogleMap mMap;
    //private ProgressDialog mProgressDialog;
    private List<Marker> mOriginMarkers = new ArrayList<>();
    private List<Marker> mDestinationMarkers = new ArrayList<>();
    private List<Polyline> mPolylinePaths = new ArrayList<>();
    String myLocation;

    private Button mBtnFindPath;
    private EditText mEdtOrigin;
    private EditText mEdtDestination;

    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    private DatabaseReference mRef;
    private GeoFire mGeoFire;

    Address mAddressCustomer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        initView();

        mRef= FirebaseDatabase.getInstance().getReference("MyLocation");
        mGeoFire=new GeoFire(mRef);

        setUpLocation();


    }

    /*
       Request permission
   */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case MapUltil.MY_PERMISSION_REQUEST_CODE:
                if (grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)
                {
                    if (checkPlayService())
                    {
                        buildGoogleApiClient();
                        createLocationRequest();
                        displayLocation();
                    }
                    break;

                }
        }
    }

    /*
        Set up my location
    */
    private void setUpLocation() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&
                ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            //Request runtime permittion
            ActivityCompat.requestPermissions(this,new String[]{
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
            },MapUltil.MY_PERMISSION_REQUEST_CODE);
        }
        else
        {
            if (checkPlayService())
            {
                buildGoogleApiClient();
                createLocationRequest();
                displayLocation();
            }
        }
    }

    /*
        Display location
     */
    private void displayLocation() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&
                ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        mLastLocation=LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation!=null)
        {
            final double latitude=mLastLocation.getLatitude();
            final double longtitude=mLastLocation.getLongitude();

            //Update to Firebase
            mGeoFire.setLocation("You", new GeoLocation(latitude, longtitude), new GeoFire.CompletionListener() {
                @Override
                public void onComplete(String key, DatabaseError error) {
                    //Move camera to mylocation
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude,longtitude),16.0f));
                }
            });

            myLocation = mLastLocation.getLatitude()+","+mLastLocation.getLongitude();
            mEdtOrigin.setText(myLocation);
            String target = mAddressCustomer.getLatitude()+","+mAddressCustomer.getLongitude();
            sendRequest(myLocation, target);

            Log.d("NoteLocation",String.format("Your location was changed: %f / %f",latitude,longtitude));
        }
        else
            Log.d("NoteLocation","Can not get your location");


    }


    /*
        Create location request
     */
    private void createLocationRequest() {
        mLocationRequest=new LocationRequest();
        mLocationRequest.setInterval(MapUltil.UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(MapUltil.FATEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setSmallestDisplacement(MapUltil.DISPLAYMENT);
    }

    /*
        Build google api client
     */
    private void buildGoogleApiClient() {
        mGoogleApiClient=new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    /*
        Check play service
     */
    private boolean checkPlayService() {
        int resultCode= GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode!= ConnectionResult.SUCCESS)
        {
            if(GooglePlayServicesUtil.isUserRecoverableError(resultCode))
                GooglePlayServicesUtil.getErrorDialog(resultCode,this,MapUltil.PLAY_SERVICES_RESOLUTION_REQUEST).show();
            else {
                Toast.makeText(this,"This device not support",Toast.LENGTH_LONG).show();
                finish();
            }
            return false;
        }
        return  true;
    }

    /*
        Init controls
     */
    private void initView() {
        mBtnFindPath = (Button) findViewById(R.id.btnFindPath);
        mEdtOrigin = (EditText) findViewById(R.id.etOrigin);
        mEdtDestination = (EditText) findViewById(R.id.etDestination);

        mBtnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mEdtOrigin.getText().toString().isEmpty()) {
                    Toast.makeText(MapsActivity.this, "Please enter origin address!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (mEdtDestination.getText().toString().isEmpty()) {
                    Toast.makeText(MapsActivity.this, "Please enter destination address!", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Address A=getAddress(mEdtOrigin.getText().toString());
                String pointA = mEdtOrigin.getText().toString();
                Address B=getAddress(mEdtDestination.getText().toString());
                String pointB = B.getLatitude() + "," + B.getLongitude();
                mMap.clear();
                sendRequest(pointA, pointB);
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {

        }
        mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationButtonClickListener(this);
        //mMap.setOnMyLocationClickListener(this);

        //Vẽ chỉ đường
        //beginFindDirection();
        String location = getIntent().getStringExtra("DiaChi");
        mEdtDestination.setText(location);
        mAddressCustomer=getAddress(location);
        //Create dangerous_erea
        LatLng dangerous_erea=new LatLng(mAddressCustomer.getLatitude(),mAddressCustomer.getLongitude());
        mMap.addCircle(new CircleOptions()
                .center(dangerous_erea)
                .radius(500)
                .strokeColor(Color.YELLOW)
                .fillColor(0x220000FF)
                .strokeWidth(12.0f)
        );

        //Add GeoQuery
        //0.5f=0.5km
        GeoQuery geoQuery=mGeoFire.queryAtLocation(new GeoLocation(dangerous_erea.latitude,dangerous_erea.longitude),0.5f);
        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                sendNotification("NoteDangerous",String.format("%s đang đến gần khách hàng",key));
            }

            @Override
            public void onKeyExited(String key) {
                sendNotification("NoteDangerous",String.format("%s is no longer the dangerous area",key));
            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {
                Log.d("MOVE",String.format("%s moved within the dangerous area [%f,%f]",key,location.latitude,location.longitude));
            }

            @Override
            public void onGeoQueryReady() {

            }

            @Override
            public void onGeoQueryError(DatabaseError error) {
                Log.d("ERROR",""+error);
            }
        });

    }

    /*
        Send notification when device go in area dangerous
     */
    private void sendNotification(String title, String content) {
        Notification.Builder builder=new Notification.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(title)
                .setContentText(content);
        NotificationManager manager=(NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent intent=new Intent(this,MapsActivity.class);
        PendingIntent contentIntent=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(contentIntent);
        Notification notification=builder.build();
        notification.flags |=Notification.FLAG_AUTO_CANCEL;
        notification.defaults|=Notification.DEFAULT_SOUND;

        manager.notify(new Random().nextInt(),notification);
    }

    /*
        Init to find direction
    */
    private void beginFindDirection() {

        myLocation = getMyLocation();
        if (myLocation != null) {
            String location = getIntent().getStringExtra("DiaChi");
            mAddressCustomer=getAddress(location);
            String target = mAddressCustomer.getLatitude()+","+mAddressCustomer.getLongitude();
            sendRequest(getMyLocation(), target);
        } else
            Toast.makeText(getApplicationContext(), "Lỗi định vị", Toast.LENGTH_LONG);
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false;
    }

    @Override
    public void onDirectionFinderStart() {
//        mProgressDialog = mProgressDialog.show(this, "Please wait.",
//                "Finding direction..!", true);

        if (mOriginMarkers != null) {
            for (Marker marker : mOriginMarkers) {
                marker.remove();
            }
        }

        if (mDestinationMarkers != null) {
            for (Marker marker : mDestinationMarkers) {
                marker.remove();
            }
        }

        if (mPolylinePaths != null) {
            for (Polyline polyline : mPolylinePaths) {
                polyline.remove();
            }
        }
    }

    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {
//        mProgressDialog.dismiss();
        mPolylinePaths = new ArrayList<>();
        mOriginMarkers = new ArrayList<>();
        mDestinationMarkers = new ArrayList<>();

        for (Route route : routes) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(route.startLocation, 16));

            ((TextView) findViewById(R.id.tvDuration)).setText(route.duration.text);
            ((TextView) findViewById(R.id.tvDistance)).setText(route.distance.text);

            mOriginMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.start_blue))
                    .title(route.startAddress)
                    .position(route.startLocation)));
            mDestinationMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.end_green))
                    .title(route.endAddress)
                    .position(route.endLocation)));

            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.BLUE).
                    width(10);

            for (int i = 0; i < route.points.size(); i++)
                polylineOptions.add(route.points.get(i));

            mPolylinePaths.add(mMap.addPolyline(polylineOptions));
        }
    }

    /*
        Get my location
     */
    public String getMyLocation() {
        LocationManager mLocationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
        List<String> providers = mLocationManager.getProviders(true);
        Location bestLocation = null;
        for (String provider : providers) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            }
            Location l = mLocationManager.getLastKnownLocation(provider);
            if (l == null) {
                continue;
            }
            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                // Found best last known location: %s", l);
                bestLocation = l;
            }
        }
        return bestLocation.getLatitude()+","+bestLocation.getLongitude();

    }

    /*
        Return loction of one address
     */
    private Address getAddress(String location) {
        List<Address> addressList = null;
        Address address = null;
        if (location != null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(getBaseContext());
            try {
                addressList = geocoder.getFromLocationName(location, 1);

            } catch (IOException e) {
                e.printStackTrace();
            }
            address = addressList.get(0);
        }
        //return address.getLatitude() + "," + address.getLongitude();
        return address;
    }
    /*
    Send request to find direction
 */
    private void sendRequest(String a, String b) {

        String origin = a;
        String destination = b;

        try {
            new DirectionFinder(this, origin, destination).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        displayLocation();
        startLocationUpdate();
    }

    /*
        Start update location
     */
    private void startLocationUpdate() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&
                ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationRequest,this);

    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        mLastLocation=location;
        displayLocation();
    }
}
