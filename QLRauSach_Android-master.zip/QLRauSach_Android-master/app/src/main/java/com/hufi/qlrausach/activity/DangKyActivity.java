package com.hufi.qlrausach.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.LoaiSP;
import com.hufi.qlrausach.model.NguoiDung;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DangKyActivity extends AppCompatActivity {

    Spinner spinner_LoaiTK;
    Button btn_Register;
    EditText edt_TK,edt_MK,edt_NhapLaiMK,edt_Email;
    TextView tv_TroVe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ky);
        
        AnhXa();
        XuLySuKien();
    }

    private void XuLySuKien() {
        tv_TroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username=edt_TK.getText().toString();
                final String password=edt_MK.getText().toString();
                final String loaitk=spinner_LoaiTK.getSelectedItem().toString();
                String nhaplai=edt_NhapLaiMK.getText().toString();;
                final String email=edt_Email.getText().toString();

                if (edt_TK.getText().toString().compareTo("")==0||edt_MK.getText().toString().compareTo("")==0||
                        edt_NhapLaiMK.getText().toString().compareTo("")==0||edt_Email.getText().toString().compareTo("")==0)
                {
                    Toast.makeText(getApplicationContext(),"Bạn chưa nhập đủ thông tin",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.compareTo(nhaplai)!=0)
                {
                    Toast.makeText(getApplicationContext(), "Mật khẩu không khớp", Toast.LENGTH_SHORT).show();
                    return;
                }

                RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
                String duongdan= Server.DuongDanTaoNguoiDung;
                StringRequest stringRequest=new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(CheckConnection.haveNetworkConnection(getApplicationContext()))
                                        {
                                            try {
                                                int kq;
                                                JSONObject jsonObject=new JSONObject(response);
                                                kq =jsonObject.getInt("success");

                                                //Thêm tài khoản khách hàng
                                                if (kq ==1) {
                                                    CheckConnection.ShowToast_Short(getApplicationContext(), "Đăng ký thành công");
                                                    MainActivity.NguoiCMNDung=new NguoiDung(username,password,loaitk,email);
                                                    RequestQueue requestQueue2= Volley.newRequestQueue(getApplicationContext());
                                                    String url="";
                                                    if (loaitk.compareTo("Khách hàng")==0) {
                                                        url= Server.DuongDanTaoUserKhachHang;
                                                    }
                                                    else
                                                    {
                                                        url= Server.DuongDanTaoUserNCC;
                                                    }
                                                    StringRequest stringRequest2=new StringRequest(Request.Method.POST,url, new Response.Listener<String>() {
                                                        @Override
                                        public void onResponse(String response) {
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                        }
                                    }){
                                        @Override
                                        protected Map<String, String> getParams() throws AuthFailureError {
                                            HashMap<String,String> para=new HashMap<String,String>();
                                            para.put("username",username);
                                            return para;
                                        }
                                    };
                                    requestQueue2.add(stringRequest2);

                                    //Khỏi tạo trang nhập thông tin
                                    if (loaitk.compareTo("Khách hàng")==0) {
                                        Intent intent = new Intent(getApplicationContext(), ThongTinKhachHang.class);
                                        startActivity(intent);
                                    }
                                    else {
                                        Intent intent = new Intent(getApplicationContext(), ThongTinNCC.class);
                                        startActivity(intent);
                                    }
                                }
                                else {
                                    CheckConnection.ShowToast_Short(getApplicationContext(), "Tài khoản đã tồn tại");
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CheckConnection.ShowToast_Short(getApplicationContext(),"Bạn hãy kiểm tra lại kết nối mạng");
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> para=new HashMap<String,String>();
                        para.put("username",username);
                        para.put("password",password);
                        para.put("email",email);
                        para.put("loaitk",loaitk);
                        return para;
                    }
                };
                requestQueue.add(stringRequest);
            }
        });
    }



    private void AnhXa() {
        edt_TK=(EditText) findViewById(R.id.edt_TK_DangKy);
        edt_MK=(EditText) findViewById(R.id.edt_MK_DangKy);
        edt_NhapLaiMK=(EditText) findViewById(R.id.edt_NhapLaiMK_DangKy);
        btn_Register=(Button) findViewById(R.id.btn_Register_DangKy);
        spinner_LoaiTK=(Spinner) findViewById(R.id.spinner_LoaiTK);
        edt_Email=(EditText) findViewById(R.id.edt_Email_DangKy);
        tv_TroVe=(TextView) findViewById(R.id.txt_Thoat_DangKy);
        List<String> list_LoaiTK=new ArrayList<String>();
        list_LoaiTK.add("Khách hàng");
        list_LoaiTK.add("Nhà cung cấp");
        ArrayAdapter<String> adapter_LoaiTK=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,list_LoaiTK);
        adapter_LoaiTK.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_LoaiTK.setAdapter(adapter_LoaiTK);
    }
}
