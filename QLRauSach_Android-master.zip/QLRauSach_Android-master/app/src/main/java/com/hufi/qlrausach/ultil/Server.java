package com.hufi.qlrausach.ultil;

/**
 * Created by HieuPC on 10/14/2017.
 */

public class Server {
    public static String host="http://auduongvanhieu.xyz/PHPRauSach/";
    public static String DuongDanLoaiSP=host+"display_loaisp.php";
    public static String DuongDanSPMoiNhat=host+"display_sp_moi.php";
    public static String DuongDanRauXanh=host+"display_sp.php?page=";
    public static String DuongDanNguoiDung=host+"nguoidung.php?";
    public static String DuongDanTaoNguoiDung=host+"create_user.php";
    public static String DuongDanTaoUserKhachHang=host+"create_user_khachhang.php";
    public static String DuongDanTaoUserNCC=host+"create_user_ncc.php";
    public static String DuongDanUpDateUserKhachHang=host+"update_user_khachhang.php";
    public static String DuongDanUpDateUserNCC=host+"update_user_ncc.php";
    public static String DuongDanUpDateDonHang=host+"update_donhang.php";
    public static String DuongDanDisplayUserKhachHang=host+"display_user_khachhang.php?username=";
    public static String DuongDanDisplayUserNCC=host+"display_user_ncc.php?username=";
    public static String DuongDanCreateDonHang=host+"create_donhang.php";
    public static String DuongDanCreateCTDonHang=host+"create_ctdonhang.php";
    public static String DuongDanCreateSanPham=host+"create_sp.php";
    public static String UPLOAD_URL=host+"upload/";
    public static String DuongDanDisplayCTSPNCC=host+"display_ct_sp_ncc.php?masp=";
    public static String DuongDanDisplayDonHang=host+"display_donhang.php?page=";
    public static String DuongDanDisplayChiTietDonHang=host+"display_ct_donhang.php?madonhang=";
}
