package com.hufi.qlrausach.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.andy6804tw.zoomimageviewlibrary.ZoomImageView;
import com.hufi.qlrausach.R;
import com.squareup.picasso.Picasso;

public class XemAnhActivity extends AppCompatActivity {

    ZoomImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xem_anh);

        imageView= (ZoomImageView) findViewById(R.id.imv_XemAnh);
        String linkHinh=getIntent().getStringExtra("linkHinh");
        Picasso.with(getApplicationContext()).load(linkHinh)
                .placeholder(R.drawable.noimage)
                .error(R.drawable.error)
                .into(imageView);

    }
}
