package com.hufi.qlrausach.activity;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.GioHang;
import com.hufi.qlrausach.model.NguoiDung;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DangNhapActivity extends AppCompatActivity {
    Button btn_login;
    EditText edt_tk, edt_mk;
    TextView tv_DangKy,tv_Thoat;
    CheckBox checkBox_GhiNho;
    String url;
    String jsonLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_nhap);

        AnhXa();
        XuLyNutLogin();
    }

    private void XuLyNutLogin() {
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edt_tk.getText().toString().trim().compareTo("") == 0) {
                    CheckConnection.ShowToast_Short(getApplication(), "Chưa nhập username");
                    return;
                }
                if (edt_mk.getText().toString().trim().compareTo("") == 0) {
                    CheckConnection.ShowToast_Short(getApplication(), "Chưa nhập password");
                    return;
                }
                url = Server.DuongDanNguoiDung + "user=" + edt_tk.getText() + "&pass=" + edt_mk.getText();
                new GetDangNhap().execute();
            }
        });

        tv_DangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),DangKyActivity.class);
                startActivity(intent);
            }
        });

        tv_Thoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    void KTDangNhap()
    {
        jsonLogin=jsonLogin.replace("\uFEFF","");
        JSONArray response = null;
        try {
            response = new JSONArray(jsonLogin);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (response != null) {
            try {
                JSONObject jsonObject = response.getJSONObject(0);
                String username = jsonObject.getString("username");
                String password = jsonObject.getString("password");
                String email = jsonObject.getString("email");
                String loaitk = jsonObject.getString("loaitk");
                MainActivity.NguoiCMNDung = new NguoiDung(username, password, email, loaitk);
                if (checkBox_GhiNho.isChecked())
                    LuuUserVaoDB();
                Restart();
                CheckConnection.ShowToast_Short(getApplicationContext(), MainActivity.NguoiCMNDung.getUsername());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void AnhXa() {
        btn_login = (Button) findViewById(R.id.btn_Login_DangNhap);
        edt_tk = (EditText) findViewById(R.id.edt_tk_DangNhap);
        edt_mk = (EditText) findViewById(R.id.edt_mk_DangNhap);
        tv_DangKy=(TextView) findViewById(R.id.txt_register_DangNhap);
        tv_Thoat=(TextView) findViewById(R.id.txt_Thoat_DangNhap);
        checkBox_GhiNho= (CheckBox) findViewById(R.id.checkbox_GhiNho_DangNhap);
    }
    public void LuuUserVaoDB()
    {
        SQLiteDatabase myDB;
        myDB=openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        myDB.execSQL(
                "CREATE TABLE IF NOT EXISTS NguoiDung (username VARCHAR(50) PRIMARY KEY,password VARCHAR(50),loaitk NVARCHAR(100),email VARCHAR(50) )"
        );
        try {
            ContentValues row1 = new ContentValues();
            row1.put("username",MainActivity.NguoiCMNDung.getUsername());
            row1.put("password",MainActivity.NguoiCMNDung.getPassword());
            row1.put("loaitk",MainActivity.NguoiCMNDung.getLoaitk());
            row1.put("email",MainActivity.NguoiCMNDung.getEmail());
            myDB.insert("NguoiDung", null, row1);
        }
        catch (Exception e)
        {
        }
    }
    public void Restart()
    {
        Intent i = getBaseContext().getPackageManager()
                .getLaunchIntentForPackage( getBaseContext().getPackageName() );
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    ProgressDialog pDialog;
    public class GetDangNhap extends AsyncTask<Object,Object,Object> {
        @Override
        protected Object doInBackground(Object[] params) {
            MyService jsonParser = new MyService();
            jsonLogin = jsonParser.callService(url, MyService.GET);
            return null;
        }

        protected void onPreExecute() {

            super.onPreExecute();
            pDialog = new ProgressDialog(DangNhapActivity.this);
            pDialog.setMessage("Đang kiểm tra...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            pDialog.dismiss();
            KTDangNhap();
        }
    }
}
