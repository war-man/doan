package com.hufi.qlrausach.model;

import android.util.TimeUtils;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by HieuPC on 10/18/2017.
 */

public class SanPham implements Serializable {
    public String MaSP;
    public String TenSP;
    public String MoTa;
    public Integer DonGia;
    public String NgaySX;
    public String DVT;
    public String LinkHinh;
    public String MaLoai;
    public SanPham(String maSP, String tenSP, String moTa, Integer donGia, String ngaySX, String DVT, String linkHinh, String maLoai) {
        MaSP = maSP;
        TenSP = tenSP;
        MoTa = moTa;
        DonGia = donGia;
        NgaySX = ngaySX;
        this.DVT = DVT;
        LinkHinh = linkHinh;
        MaLoai = maLoai;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String maSP) {
        MaSP = maSP;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String tenSP) {
        TenSP = tenSP;
    }

    public String getMoTa() {
        return MoTa;
    }

    public void setMoTa(String moTa) {
        MoTa = moTa;
    }

    public Integer getDonGia() {
        return DonGia;
    }

    public void setDonGia(Integer donGia) {
        DonGia = donGia;
    }

    public String getNgaySX() {
        return NgaySX;
    }

    public void setNgaySX(String ngaySX) {
        NgaySX = ngaySX;
    }

    public String getDVT() {
        return DVT;
    }

    public void setDVT(String DVT) {
        this.DVT = DVT;
    }

    public String getLinkHinh() {
        return LinkHinh;
    }

    public void setLinkHinh(String linkHinh) {
        LinkHinh = linkHinh;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String maLoai) {
        MaLoai = maLoai;
    }

}
