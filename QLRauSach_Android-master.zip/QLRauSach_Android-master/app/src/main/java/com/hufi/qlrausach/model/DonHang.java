package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 11/12/2017.
 */

public class DonHang {
    int makh;
    String madonhang;
    String dctp;
    String dcquan;
    String dcphuong;
    String dcsonha;
    int phivanchuyen;
    String giodat;
    int tongtien;

    public DonHang(int makh, String madonhang, String dctp, String dcquan, String dcphuong, String dcsonha, int phivanchuyen, String giodat, int tongtien) {
        this.makh = makh;
        this.madonhang = madonhang;
        this.dctp = dctp;
        this.dcquan = dcquan;
        this.dcphuong = dcphuong;
        this.dcsonha = dcsonha;
        this.phivanchuyen = phivanchuyen;
        this.giodat = giodat;
        this.tongtien = tongtien;
    }

    public int getMakh() {
        return makh;
    }

    public void setMakh(int makh) {
        this.makh = makh;
    }

    public String getMadonhang() {
        return madonhang;
    }

    public void setMadonhang(String madonhang) {
        this.madonhang = madonhang;
    }

    public String getDctp() {
        return dctp;
    }

    public void setDctp(String dctp) {
        this.dctp = dctp;
    }

    public String getDcquan() {
        return dcquan;
    }

    public void setDcquan(String dcquan) {
        this.dcquan = dcquan;
    }

    public String getDcphuong() {
        return dcphuong;
    }

    public void setDcphuong(String dcphuong) {
        this.dcphuong = dcphuong;
    }

    public String getDcsonha() {
        return dcsonha;
    }

    public void setDcsonha(String dcsonha) {
        this.dcsonha = dcsonha;
    }

    public int getPhivanchuyen() {
        return phivanchuyen;
    }

    public void setPhivanchuyen(int phivanchuyen) {
        this.phivanchuyen = phivanchuyen;
    }

    public String getGiodat() {
        return giodat;
    }

    public void setGiodat(String giodat) {
        this.giodat = giodat;
    }

    public int getTongtien() {
        return tongtien;
    }

    public void setTongtien(int tongtien) {
        this.tongtien = tongtien;
    }
}