package com.hufi.qlrausach.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.model.UserKhachHang;
import com.hufi.qlrausach.model.UserNCC;
import com.hufi.qlrausach.ultil.CheckConnection;
import com.hufi.qlrausach.ultil.MyService;
import com.hufi.qlrausach.ultil.RealPathUtil;
import com.hufi.qlrausach.ultil.Server;
import com.squareup.picasso.Picasso;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ThongTinNCC extends AppCompatActivity {

    Button btn_XacNhan,btn_ChonHinh,btn_TroVe;
    ProgressDialog pDialog;
    EditText edt_TenNCC, edt_SdtCoDinh,edt_SdtDiDong,edt_DiaChi,edt_WebSite,edt_NamTL,edt_GioiThieu;
    ImageView imageView;
    String imgName;
    String imgCode;
    UserNCC userNCC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin_ncc);

        AnhXa();
        XuLyNut();
        userNCC= (UserNCC) getIntent().getSerializableExtra("thongtinncc");
        if (userNCC!=null) {
            getData();
            btn_ChonHinh.setVisibility(View.GONE);
            btn_XacNhan.setVisibility(View.GONE);
            edt_TenNCC.setEnabled(false);
            edt_SdtCoDinh.setEnabled((false));
            edt_SdtDiDong.setEnabled(false);
            edt_WebSite.setEnabled(false);
            edt_NamTL.setEnabled(false);
            edt_GioiThieu.setEnabled(false);
            edt_DiaChi.setEnabled(false);
        }
        else {
            btn_TroVe.setVisibility(View.GONE);
            if (MainActivity.NguoiCMNDung != null) {
                new GetTTNCC().execute();

            }
        }
    }

    private void XuLyNut() {
        btn_XacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String tenncc=edt_TenNCC.getText().toString();
                final String sdtcodinh=edt_SdtCoDinh.getText().toString();
                final String sdtdidong=edt_SdtDiDong.getText().toString();
                final String diachi=edt_DiaChi.getText().toString();
                final String namthanhlap=edt_NamTL.getText().toString();
                final String website=edt_WebSite.getText().toString();
                final String thongtinct=edt_GioiThieu.getText().toString();
                //Lưu vào bảng User_NguoiDung
                RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
                String duongdan= Server.DuongDanUpDateUserNCC;
                StringRequest stringRequest=new StringRequest(Request.Method.POST, duongdan, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            int kq;
                            JSONObject jsonObject=new JSONObject(response);
                            kq =jsonObject.getInt("success");
                            if (kq ==1) {
                                CheckConnection.ShowToast_Short(getApplicationContext(), "Cập nhật thành công");
                            }
                            else {
                                CheckConnection.ShowToast_Short(getApplicationContext(), "Cập nhật thất bại");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> para=new HashMap<String,String>();
                        para.put("username",MainActivity.NguoiCMNDung.getUsername());
                        para.put("tenncc",tenncc);
                        para.put("sdtcodinh",sdtcodinh);
                        para.put("sdtdidong",sdtdidong);
                        para.put("diachi",diachi);
                        para.put("namthanhlap",namthanhlap);
                        para.put("website",website);
                        para.put("thongtinct",thongtinct);
                        para.put("imageName", imgName);
                        para.put("imageCode", imgCode);
                        return para;
                    }
                };
                requestQueue.add(stringRequest);
                Restart();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0 && resultCode == ThongTinNCC.this.RESULT_OK) {
            String PATH= RealPathUtil.getPath(ThongTinNCC.this, data.getData());
            Uri uri = Uri.fromFile(new File(PATH));
            // Get name
            imgName = PATH.substring(PATH.lastIndexOf("/")+1);
            Toast.makeText(ThongTinNCC.this, imgName, Toast.LENGTH_LONG).show();
            Bitmap bitmap=null;
            try {
                //Get BitMap
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            imgCode = getBitMap(bitmap);
            // Load image
            Glide.with(ThongTinNCC.this).load(uri).override(420, 594).centerCrop().into(imageView);
            Toast.makeText(this, PATH, Toast.LENGTH_LONG).show();

        }
    }
    // Encode bitmap to String
    public String getBitMap(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    private void AnhXa() {
        edt_TenNCC= (EditText) findViewById(R.id.edt_TenKH_TTNCC);
        edt_SdtCoDinh=(EditText)findViewById(R.id.edt_Sdt_TTNCC);
        edt_SdtDiDong=(EditText)findViewById(R.id.edt_SdtDiDong_TTNCC);
        edt_DiaChi=(EditText)findViewById(R.id.edt_DiaChi_TTNCC);
        edt_WebSite=(EditText)findViewById(R.id.edt_Website_TTNCC);
        edt_NamTL=(EditText)findViewById(R.id.edt_NamThanhLap_TTNCC);
        edt_GioiThieu=(EditText)findViewById(R.id.edt_GioiThieu_TTNCC);
        imageView= (ImageView) findViewById(R.id.Hinh_TTNCC);

        btn_XacNhan= (Button) findViewById(R.id.btn_XacNhan_TTNCC);
        btn_XacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Restart();
            }
        });

        btn_ChonHinh=(Button) findViewById(R.id.btn_ChonHinh_TTNCC);
        btn_ChonHinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermistion();
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 0);
            }
        });
        btn_TroVe=(Button) findViewById(R.id.btn_TroVe_TTNCC);
        btn_TroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    public void Restart()
    {
        Intent i = getBaseContext().getPackageManager()
                .getLaunchIntentForPackage( getBaseContext().getPackageName() );
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public void getData()
    {
        edt_TenNCC.setText(userNCC.getTenncc());
        edt_SdtCoDinh.setText(userNCC.getSdtcodinh());
        edt_SdtDiDong.setText(userNCC.getSdtdidong());
        edt_DiaChi.setText(userNCC.getDiachi());
        edt_WebSite.setText(userNCC.getWebsite());
        edt_NamTL.setText(userNCC.getNamthanhlap());
        edt_GioiThieu.setText(userNCC.getThongtinct());
        try {
            Picasso.with(getApplicationContext()).load(userNCC.getLinkhinh()).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }
        catch (Exception e)
        {

        }
    }

    public class GetTTNCC extends AsyncTask<Object,Object,Object> {

        @Override
        protected Object doInBackground(Object[] params) {
            MyService jsonParser = new MyService();
            String duongdan= Server.DuongDanDisplayUserNCC+MainActivity.NguoiCMNDung.getUsername();
            String json = jsonParser.callService(duongdan, MyService.GET);
            if (json != null) {
                try {
                    json=json.replace("\uFEFF","");
                    JSONArray jsonArray = new JSONArray(json);
                    if (jsonArray != null) {
                        JSONObject jsonObject =jsonArray.getJSONObject(0);
                        int mancc=jsonObject.getInt("mancc");
                        String username=jsonObject.getString("username");
                        String tenncc=jsonObject.getString("tenncc");
                        String sdtcodinh=jsonObject.getString("sdtcodinh");
                        String sdtdidong=jsonObject.getString("sdtdidong");
                        String diachi=jsonObject.getString("diachi");
                        String namthanhlap=jsonObject.getString("namthanhlap");
                        String website=jsonObject.getString("website");
                        String thongtinct=jsonObject.getString("thongtinct");
                        String linkhinh=jsonObject.getString("linkhinh");
                        userNCC=new UserNCC(mancc,username,tenncc,sdtcodinh,sdtdidong,diachi,namthanhlap,website,thongtinct,linkhinh);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }
            return null;
        }


        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(ThongTinNCC.this);
            pDialog.setMessage("Loading..");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected void onPostExecute(Object o) {

            super.onPostExecute(o);

            if (pDialog.isShowing())
                pDialog.dismiss();
            getData();
        }
    }

    //Check permistion android 6.0
    private void checkPermistion() {
        if (ContextCompat.checkSelfPermission(ThongTinNCC.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(ThongTinNCC.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(ThongTinNCC.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);
            }
        }
    }
}
