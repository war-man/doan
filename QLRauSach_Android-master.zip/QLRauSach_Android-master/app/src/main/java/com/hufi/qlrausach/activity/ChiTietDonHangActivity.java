package com.hufi.qlrausach.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.hufi.qlrausach.R;
import com.hufi.qlrausach.adapter.ChitTietDHAdapter;
import com.hufi.qlrausach.model.ChiTietDH;
import com.hufi.qlrausach.model.DonDatHang;
import com.hufi.qlrausach.model.SanPham;
import com.hufi.qlrausach.ultil.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ChiTietDonHangActivity extends AppCompatActivity {

    ExpandableListView expandableLV_CTDH;
    android.support.v7.widget.Toolbar toolbar;
    ArrayList<ChiTietDH> arrCTDH;
    ChitTietDHAdapter adapter_CTDH;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_don_hang);
        
        AnhXa();
        ActionToolBar();
        LoadData();

    }

    private void LoadData() {
        DonDatHang donHang= (DonDatHang) getIntent().getSerializableExtra("ctdh");
        ((TextView)findViewById(R.id.tv_MaDH_ChiTietDH)).setText("Mã đơn hàng: "+donHang.getMadonhang());
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        String duongdan= Server.DuongDanDisplayChiTietDonHang+donHang.getMadonhang();
        StringRequest stringRequest=new StringRequest(Request.Method.GET, duongdan, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Xu ly json
                if (response!=null) {
                    String str=response.replace("\uFEFF","");
                    str=str.replace("ï»¿ï»¿","");
                    JSONArray json = null;
                    try {
                        json = new JSONArray(str);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (json != null) {
                        try {
                            for (int i = 0; i < json.length(); i++) {
                                JSONObject jsonObject = json.getJSONObject(i);
                                String MaSP = jsonObject.getString("masp");
                                String TenSP = jsonObject.getString("tensp");
                                String MoTa = jsonObject.getString("mota");
                                int DonGia = jsonObject.getInt("dongia");
                                String NgaySX = jsonObject.getString("ngaysx");
                                String DVT = jsonObject.getString("dvt");
                                String LinkHinh = jsonObject.getString("linkhinh");
                                String MaLoai = jsonObject.getString("maloai");
                                SanPham sp= new SanPham(MaSP, TenSP, MoTa, DonGia, NgaySX, DVT, LinkHinh, MaLoai);
                                int SoLuong=jsonObject.getInt("soluong");
                                arrCTDH.add(new ChiTietDH(sp,SoLuong));
                                adapter_CTDH.notifyDataSetChanged();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(stringRequest);
    }

    private void ActionToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void AnhXa() {
        toolbar= (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar_ChiTietDH);
        expandableLV_CTDH= (ExpandableListView) findViewById(R.id.expand_CTDH);
        arrCTDH=new ArrayList<>();
        adapter_CTDH=new ChitTietDHAdapter(ChiTietDonHangActivity.this,arrCTDH);
        expandableLV_CTDH.setAdapter(adapter_CTDH);
    }
}
