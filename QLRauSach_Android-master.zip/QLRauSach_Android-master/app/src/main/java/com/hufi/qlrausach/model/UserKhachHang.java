package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 11/11/2017.
 */

public class UserKhachHang {
    int makh;
    String username,hoten,sdt,dctinh,dcquanhuyen,dcphuongxa,dcsonhaduong,ngaysinh,gioitinh;

    public UserKhachHang(int makh, String username, String hoten, String sdt, String dctinh, String dcquanhuyen, String dcphuongxa, String dcsonhaduong, String ngaysinh, String gioitinh) {
        this.makh = makh;
        this.username = username;
        this.hoten = hoten;
        this.sdt = sdt;
        this.dctinh = dctinh;
        this.dcquanhuyen = dcquanhuyen;
        this.dcphuongxa = dcphuongxa;
        this.dcsonhaduong = dcsonhaduong;
        this.ngaysinh = ngaysinh;
        this.gioitinh = gioitinh;
    }

    public int getMakh() {
        return makh;
    }

    public void setMakh(int makh) {
        this.makh = makh;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDctinh() {
        return dctinh;
    }

    public void setDctinh(String dctinh) {
        this.dctinh = dctinh;
    }

    public String getDcquanhuyen() {
        return dcquanhuyen;
    }

    public void setDcquanhuyen(String dcquanhuyen) {
        this.dcquanhuyen = dcquanhuyen;
    }

    public String getDcphuongxa() {
        return dcphuongxa;
    }

    public void setDcphuongxa(String dcphuongxa) {
        this.dcphuongxa = dcphuongxa;
    }

    public String getDcsonhaduong() {
        return dcsonhaduong;
    }

    public void setDcsonhaduong(String dcsonhaduong) {
        this.dcsonhaduong = dcsonhaduong;
    }

    public String getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(String ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getGioitinh() {
        return gioitinh;
    }

    public void setGioitinh(String gioitinh) {
        this.gioitinh = gioitinh;
    }
}
