package com.hufi.qlrausach.model;

/**
 * Created by HieuPC on 11/12/2017.
 */

public class CTDonHang {
    String madonhang;
    int masp;
    int soluong;

    public CTDonHang(String madonhang, int masp, int soluong) {
        this.madonhang = madonhang;
        this.masp = masp;
        this.soluong = soluong;
    }

    public String getMadonhang() {
        return madonhang;
    }

    public void setMadonhang(String madonhang) {
        this.madonhang = madonhang;
    }

    public int getMasp() {
        return masp;
    }

    public void setMasp(int masp) {
        this.masp = masp;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }
}
