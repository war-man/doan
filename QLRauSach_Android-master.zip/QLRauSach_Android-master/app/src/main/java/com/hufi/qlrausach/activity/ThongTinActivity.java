package com.hufi.qlrausach.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.hufi.qlrausach.R;

public class ThongTinActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap map;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin);

        MapFragment mapFragment = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.myMap_TT);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        map=googleMap;
        LatLng sydney = new LatLng(10.806480, 106.628667);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 16));

        map.addMarker(new MarkerOptions()
                .title("Hufi")
                .snippet("Trung tâm bảo trì hệ thống")
                .position(sydney));

    }
}
