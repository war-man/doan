package com.trangpig.until;

/**
 * Created by TrangPig on 06/03/2015.
 */
public class MyConstant {
    public static final String MESSAGE_REGISTRY_CHAT_GROUP = (char) 0
            + "registryChatGroup";
    public static final String MESSAGE_CHAT_CONVERSATION = (char) 0
            + "chatConversation";
    public static final String MESSAGE_CHAT_ROOM = (char) 0 + "chatGroup";
    public static final String MESSAGE_ADD_FRIEND = (char) 0 + "addfriend:";
}
