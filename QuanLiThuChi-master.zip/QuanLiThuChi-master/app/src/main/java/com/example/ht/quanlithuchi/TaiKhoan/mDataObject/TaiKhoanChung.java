package com.example.ht.quanlithuchi.TaiKhoan.mDataObject;

public class TaiKhoanChung {


    int id_tkc;
    String tentk;
    int tien;
    int id_image;
    public int getId_tkc() {
        return id_tkc;
    }

    public void setId_tkc(int id_tkc) {
        this.id_tkc = id_tkc;
    }

    public TaiKhoanChung() {
    }

    public TaiKhoanChung(String tentk, int tien) {
        this.tentk = tentk;
        this.tien = tien;
    }

    public TaiKhoanChung(String tentk, int tien, int id_image) {
        this.tentk = tentk;
        this.tien = tien;
        this.id_image = id_image;
    }

    public String getTentk() {
        return tentk;
    }

    public void setTentk(String tentk) {
        this.tentk = tentk;
    }

    public int getTien() {
        return tien;
    }

    public void setTien(int tien) {
        this.tien = tien;
    }

    public TaiKhoanChung(int id_tkc, String tentk, int tien, int id_image) {
        this.id_tkc = id_tkc;
        this.tentk = tentk;
        this.tien = tien;
        this.id_image = id_image;
    }

    public int getId_image() {

        return id_image;
    }

    public void setId_image(int id_image) {
        this.id_image = id_image;
    }
}
