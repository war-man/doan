package com.example.ht.quanlithuchi.DangNhap;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.ht.quanlithuchi.R;

public class TrangChinh extends AppCompatActivity {
    DataBase dataBase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_thuchi);
        dataBase = new DataBase(this);
    }
}
