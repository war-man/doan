package com.example.ht.quanlithuchi.TaiKhoan.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;

import com.example.ht.quanlithuchi.R;
import com.example.ht.quanlithuchi.TaiKhoan.mDataBase.TKC_DBHelper;
import com.example.ht.quanlithuchi.TaiKhoan.mDataObject.TaiKhoanChung;
import com.example.ht.quanlithuchi.TaiKhoan.mListView.AdapterTKC;
import com.example.ht.quanlithuchi.TaiKhoan.mListView.ThemTK;

import java.util.ArrayList;
import java.util.List;

public class FragmentTK extends Fragment {

    View rootview;
    private ImageButton btnButton;
    private ListView listView;
    private ArrayList<TaiKhoanChung> list;
    private AdapterTKC adapterTKC;
    private List<TaiKhoanChung> taiKhoanChungs;
    private TKC_DBHelper tkc_dbHelper;
    Context context;
    private ImageButton btnButton2;
    public FragmentTK() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootview = inflater.inflate(R.layout.taikhoan_tk,container,false);

        listView =rootview.findViewById(R.id.list);
        tkc_dbHelper = new TKC_DBHelper(this.getActivity());
        //Load danh sach tai khoan
        list=tkc_dbHelper.getAll_TKC();
        setAdapterTKC();
        //Xu li nut them
        btnButton = rootview.findViewById(R.id.btnInsert);
        btnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),ThemTK.class);
                startActivity(intent);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        return rootview;

    }

    public void onResume() {
        super.onResume();
        Log.i("TTT", "resume");
        list=tkc_dbHelper.getAll_TKC();
        setAdapterTKC();
    }

    private  void setAdapterTKC()
    {
        if(adapterTKC==null)
        {
            adapterTKC = new AdapterTKC(this.getActivity(),R.layout.taikhoan_row,list);
            listView.setAdapter(adapterTKC);
        }
        else
        {
            adapterTKC = new AdapterTKC(this.getActivity(),R.layout.taikhoan_row,list);
            listView.setAdapter(adapterTKC);
            adapterTKC.notifyDataSetChanged();
            listView.setSelection(adapterTKC.getCount()-1);
        }
    }
}
