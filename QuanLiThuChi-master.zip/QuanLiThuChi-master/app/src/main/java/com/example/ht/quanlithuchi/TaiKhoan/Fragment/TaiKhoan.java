package com.example.ht.quanlithuchi.TaiKhoan.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.ht.quanlithuchi.R;

public class TaiKhoan  extends Fragment {

    private TabLayout tabLayout;
    //private AppBarLayout appBarLayout;
    private ViewPager viewPager;



    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView =inflater.inflate(R.layout.taikhoan,container,false);

        tabLayout = rootView.findViewById(R.id.tablayout);
        viewPager = rootView.findViewById(R.id.viewpaper);
        //ViewPaperAdapter adapter = new ViewPaperAdapter(getActivity().getSupportFragmentManager());
        //ViewPaperAdapter adapter = new ViewPaperAdapter(getFragmentManager());
        ViewPaperAdapter adapter = new ViewPaperAdapter(getActivity().getSupportFragmentManager());
        adapter.AddFragment(new FragmentTK(),"Tài Khoản");
        adapter.AddFragment(new FragmentSTK(),"Sổ tiết kiệm");
        adapter.AddFragment(new FragmentTL(),"Tích Lũy");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        return rootView;


    }




}
