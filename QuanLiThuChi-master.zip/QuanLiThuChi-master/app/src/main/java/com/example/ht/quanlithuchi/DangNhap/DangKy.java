package com.example.ht.quanlithuchi.DangNhap;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ht.quanlithuchi.MainDangNhap;
import com.example.ht.quanlithuchi.R;

public class DangKy extends AppCompatActivity {
    Button btn;
    DataBase dataBase;
    EditText tk,mk1,mk2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dangky);
        btn=findViewById(R.id.btnTaoTK);
        tk=(EditText)findViewById(R.id.edtDKTaiKhoan);
        mk1=(EditText)findViewById(R.id.edtDKMatKhau);
        mk2=(EditText)findViewById(R.id.edtNhapLaiMatKhau);
        dataBase = new DataBase(this);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = tk.getText().toString().trim();
                String s2 = mk1.getText().toString().trim();
                String s3 = mk2.getText().toString().trim();
                if (s1.equals(null)&&s2.equals(null)&&s3.equals(null)) {
                    Toast.makeText(getApplicationContext(),
                            "Thông tin không được để trống", Toast.LENGTH_SHORT).show();

                }
                else {
                    if (s2.equals(s3)) {
                        boolean searchTK = dataBase.searchTK(s1);
                        if (searchTK == true) {
                            DangNhap dn = createDN();
                            if (dn != null) {
                                dataBase.addDangNhap(dn);
                                Toast.makeText(getApplicationContext(),
                                        "dang ki thanh cong", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(DangKy.this, MainDangNhap.class);
                                startActivity(intent);
                            }
                        } else {
                            Toast.makeText(getApplicationContext(),
                                    "Bạn nhập trùng Tài Khoản", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(),
                                "Bạn nhập sai mật khẩu", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            // Intent intent=new Intent(dangky.this,MainActivity.class);
            //startActivity(intent);

        });

    }
    private DangNhap createDN() {
        String ten = tk.getText().toString();
        String mk = mk1.getText().toString();
        DangNhap dangNhap = new DangNhap(ten, mk);
        return dangNhap;
    }



}
