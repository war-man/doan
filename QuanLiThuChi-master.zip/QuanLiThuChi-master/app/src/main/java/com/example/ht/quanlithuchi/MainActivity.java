package com.example.ht.quanlithuchi;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.ht.quanlithuchi.TaiKhoan.Fragment.TaiKhoan;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    private DrawerLayout mDrawerLayout;
    //tao một bố cục layout
    private ActionBarDrawerToggle mToggle;



    //Tạo thanh hoạt động
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerLayout = findViewById(R.id.main);
        //gán giá trị layout vừa tạo
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.Open,R.string.Close);
        //Xủ lí thanh hoạt động vs layout DrawerLayout
        mDrawerLayout.addDrawerListener(mToggle);
        //Thêm mToggle vào thanh DrawerLayout
        mToggle.syncState();


        NavigationView navigationView = findViewById(R.id.menu_view);
        navigationView.setNavigationItemSelectedListener(this);
        //để hàm trên hoạt đọng thì làm hai bước
        //b1: thêm implement OnNavigationItemSelectedListener
        //b2:crtl + I
       getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if(savedInstanceState==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new TaiKhoan()).commit();
            navigationView.setCheckedItem(R.id.tai_khoan);
        }
        if(savedInstanceState==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new Home()).commit();
            navigationView.setCheckedItem(R.id.tong_quan);
        }






    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId())
        {
            case R.id.tong_quan:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new Home()).commit();
                break;
            case R.id.tai_khoan:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new TaiKhoan()).commit();
                break;
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item))
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
