package com.example.ht.quanlithuchi.TaiKhoan.mListView;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.ht.quanlithuchi.R;
import com.example.ht.quanlithuchi.TaiKhoan.Fragment.FragmentTK;
import com.example.ht.quanlithuchi.TaiKhoan.mDataBase.TKC_DBHelper;
import com.example.ht.quanlithuchi.TaiKhoan.mDataObject.TaiKhoanChung;

import java.util.ArrayList;
import java.util.List;

public class ThemTK extends AppCompatActivity {
     @Nullable
    private EditText edtName;
    private EditText edtGiatien;
    private ImageView imgLoaiTK;
    private Button btnLuu;
    private ArrayList<TaiKhoanChung> list;
    private AdapterTKC adapterTKC;
    private ListView listView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.themtaikhoan);

        final TKC_DBHelper tkc_dbHelper = new TKC_DBHelper(this);

        edtName = findViewById(R.id.tentk);
        edtGiatien = findViewById(R.id.tongtien);
        imgLoaiTK = findViewById(R.id.loaitk);
        btnLuu = findViewById(R.id.LuuTK);
        listView =findViewById(R.id.list);
       // list=tkc_dbHelper.getAll_TKC();
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TaiKhoanChung taiKhoanChung = createTKC();
                if(taiKhoanChung!=null)
                {
                    tkc_dbHelper.addTKC(taiKhoanChung);
                }

//                getSupportFragmentManager().beginTransaction().replace(R.id.taikhoan_tk,new FragmentTK()).commit();
                finish();
            }
        });
    }


    private TaiKhoanChung createTKC()
    {
        String name =edtName.getText().toString();
        int giatien =Integer.valueOf(edtGiatien.getText().toString());
        TaiKhoanChung taiKhoanChung = new TaiKhoanChung(name,giatien);
        return taiKhoanChung;
    }

}
