package com.example.ht.quanlithuchi.TaiKhoan.Fragment;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewPaperAdapter extends FragmentPagerAdapter {
    private final List<Fragment> fragmentList = new ArrayList<>();
    private  final List<String> FragmentListTitles = new ArrayList<String>();

    public ViewPaperAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int posision) {
        return fragmentList.get(posision);
    }

    @Override
    public int getCount() {
        return FragmentListTitles.size();
    }

    /*@Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return (CharSequence) FragmentListTitles.get(position);
    }*/

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return FragmentListTitles.get(position);
    }
    public  void AddFragment(Fragment fragment, String Title)
    {
        fragmentList.add(fragment);
        FragmentListTitles.add(Title);

    }
}
