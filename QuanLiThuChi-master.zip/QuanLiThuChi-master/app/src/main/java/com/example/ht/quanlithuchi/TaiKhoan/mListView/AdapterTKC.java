package com.example.ht.quanlithuchi.TaiKhoan.mListView;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.PopupMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ht.quanlithuchi.Home;
import com.example.ht.quanlithuchi.R;
import com.example.ht.quanlithuchi.TaiKhoan.Fragment.TaiKhoan;
import com.example.ht.quanlithuchi.TaiKhoan.mDataObject.TaiKhoanChung;

import java.util.ArrayList;
import java.util.List;

public class AdapterTKC extends ArrayAdapter<TaiKhoanChung> {
    private Context context;
    private int resource;
    View root;
    private ArrayList<TaiKhoanChung> arrContact;

    public AdapterTKC(@NonNull Context context, int resource, @NonNull ArrayList<TaiKhoanChung> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.arrContact=objects;
    }

    @NonNull

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        convertView = LayoutInflater.from(context).inflate(R.layout.taikhoan_row,parent,false);

        ImageView image =(ImageView) convertView.findViewById(R.id.imageLoaiTK);
        TextView name = (TextView) convertView.findViewById(R.id.tentaikhoan);
        TextView giatien = convertView.findViewById(R.id.giatien);

        TaiKhoanChung taiKhoanChung= arrContact.get(position);
        image.setImageResource(taiKhoanChung.getId_image());
        name.setText(taiKhoanChung.getTentk());
        giatien.setText(String.valueOf(taiKhoanChung.getTien()));


        //Xu li icon menu
        final ImageView menu = convertView.findViewById(R.id.imageview);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.imageview:

                        PopupMenu popup = new PopupMenu(menu.getContext(), v);
                        popup.getMenuInflater().inflate(R.menu.menu_chinhsua,
                                popup.getMenu());
                        popup.show();
                        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {

                                switch (item.getItemId()) {
                                    case R.id.sua:

                                        //((FragmentActivity)context).getSupportFragmentManager().beginTransaction().replace(R.id.taikhoan_tk,new ThemTK()).commit();
                                        break;
                                    case R.id.ngungsudung:
                                        //Toast.makeText(getApplicationContext(), "Add to Wish List Clicked at position " + " : " + position, Toast.LENGTH_LONG).show();
                                        break;

                                    default:
                                        break;
                                }
                                return true;
                            }
                        });
                        break;

                    default:
                        break;
                }
            }
        });
        return convertView;
    }

}
