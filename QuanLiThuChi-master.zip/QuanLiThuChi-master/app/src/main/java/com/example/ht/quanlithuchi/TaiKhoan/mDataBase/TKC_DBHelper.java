package com.example.ht.quanlithuchi.TaiKhoan.mDataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.example.ht.quanlithuchi.TaiKhoan.mDataObject.TaiKhoanChung;

import java.util.ArrayList;

public class TKC_DBHelper extends SQLiteOpenHelper {


    public static final String DATABASE_NAME="QLTC2";
    public static final  String TABLE_NAME="TKC";
    public static final  String ID="id";
    public static final  String NAME="name";
    public static final  String TIEN="tien";
    public static final  String LOAITK="loaitaikhoan";
    private  static int VERSION =2;


    private Context context;

    private String SQLQuery ="CREATE TABLE "+TABLE_NAME+"("+
            ID +" INTEGER PRIMARY KEY, " +
            NAME+" TEXT, "+
            TIEN +" INTEGER, "+
            LOAITK +" INTEGER)";
    public TKC_DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context=context;
    }
    //vesion thay doi se goi onUggrade


    @Override
    public void onCreate(SQLiteDatabase db) {
        //GOI CAU TRUY VAN SQLQUERY
        //db.execSQL(SQLQuery);
        db.execSQL(SQLQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void hello()
    {
        Toast.makeText(context, "Hello", Toast.LENGTH_SHORT).show();
    }
    public void addTKC(TaiKhoanChung taiKhoanChung)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        //khong duoc phep luu tkc xuong db mak phai put database
        ContentValues values = new ContentValues();
        values.put(NAME,taiKhoanChung.getTentk());
        values.put(TIEN,taiKhoanChung.getTien());
        //values.put(LOAITK,taiKhoanChung.getId_tkc());
        db.insert(TABLE_NAME,null,values);
        db.close();
    }
    public ArrayList<TaiKhoanChung> getAll_TKC(){
        ArrayList<TaiKhoanChung> ListTKC = new ArrayList<>();

       // db = context.openOrCreateDatabase(DATABASE_NAME,context.MODE_PRIVATE,null);

        String sql = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db=this.getWritableDatabase();

        Cursor cursor  = db.rawQuery(sql ,null);//cursor cho phep lay ra ket qua
        if(cursor.moveToFirst())
        {
            do{
                TaiKhoanChung taiKhoanChung = new TaiKhoanChung();//Phai khoi tao cunstrustor rong ben class TaiKhoanChung do no truyen vao
                taiKhoanChung.setId_tkc(cursor.getInt(0));
                taiKhoanChung.setTentk(cursor.getString(1));
                taiKhoanChung.setTien(cursor.getInt(2));
                //taiKhoanChung.setId_image(cursor.getInt(3));
                Log.i("Test", "y");
                ListTKC.add(taiKhoanChung);
            }
            while (cursor.moveToNext());
        }
        return ListTKC;
    }

}
