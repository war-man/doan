package com.example.ht.quanlithuchi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ht.quanlithuchi.DangNhap.DangKy;
import com.example.ht.quanlithuchi.DangNhap.DataBase;

//import com.example.ngph.phanmemqlthuchi.Data.DataBase;

public class MainDangNhap extends AppCompatActivity {
    Button btn;
    Button btnl;
    DataBase dataBase;
    EditText edttk;
    EditText edtmk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dangnhap);
        edttk =findViewById(R.id.edtTaiKhoan);
        edtmk=findViewById(R.id.edtMatKhau);
        dataBase=new DataBase(this);
        btnl=findViewById(R.id.btnDangKy);
        btnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainDangNhap.this,DangKy.class);
                startActivity(intent);
            }
        });
        btn = findViewById(R.id.btnDangNhap);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tk=edttk.getText().toString();
                String mk=edtmk.getText().toString();

                Boolean search=dataBase.searchTKandMK(tk,mk);
                if(search==true)
                {
                    Toast.makeText(getApplicationContext(), "Đăng nhập Thành công!", Toast.LENGTH_SHORT).show();
                    Intent intent1 = new Intent(MainDangNhap.this,MainActivity.class);
                    startActivity(intent1);
                                    }
                else
                    Toast.makeText(getApplicationContext(),"Đăng nhập Thất bại!",Toast.LENGTH_SHORT).show();


            }
        });
    }
}

