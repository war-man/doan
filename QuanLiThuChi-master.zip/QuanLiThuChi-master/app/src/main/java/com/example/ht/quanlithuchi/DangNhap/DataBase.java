package com.example.ht.quanlithuchi.DangNhap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DataBase extends SQLiteOpenHelper {
    private Context context;
    private final String TAG="Database";
    private static final String DATABASE_NAME = "QL_TaiKhoan.sqlite";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "DangNhap";
    private static final String KEY_ID = "id";
    private static final String KEY_taikhoan = "taikhoan";
    private static final String KEY_matkhau = "matkhau";

    public DataBase(Context context){
                            super(context, DATABASE_NAME,null, DATABASE_VERSION);
                            this.context=context;
    }
    public void hello()
    {Toast.makeText(context,"ok",Toast.LENGTH_SHORT).show();
    }
    public String TaoBangDN="CREATE TABLE "+TABLE_NAME+" ("+
            KEY_ID +" integer PRIMARY KEY, "+
            KEY_taikhoan + " TEXT, "+
            KEY_matkhau +" TEXT)";
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TaoBangDN);


    }
    public void addDangNhap(DangNhap dangNhap){

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(KEY_taikhoan,dangNhap.getTaikhoan());
        values.put(KEY_matkhau,dangNhap.getMatkhau());
        db.insert(TABLE_NAME,null,values);

        db.close();

    }
    private static final String SQL_Delete_DN =
            "DROP TABLE IF EXISTS " + TABLE_NAME;
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_Delete_DN);
        onCreate(db);
    }

    public boolean searchTK(String tk){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from DangNhap Where taikhoan=?",new String[]{tk});
        if(cursor.getCount()>0) return false;
        return true;

    }
    public boolean searchTKandMK(String tk,String mk){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from DangNhap Where taikhoan=? and matkhau=?",new String[]{tk,mk});
        if(cursor.getCount()>0) return true;
        return false;
    }
}
