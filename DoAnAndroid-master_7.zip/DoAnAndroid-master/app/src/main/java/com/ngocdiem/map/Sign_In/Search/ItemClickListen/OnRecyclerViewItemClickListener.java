package com.ngocdiem.map.Sign_In.Search.ItemClickListen;

public interface OnRecyclerViewItemClickListener {
    public void onRecyclerViewItemClicked( int position, int id );
}
