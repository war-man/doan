package com.ngocdiem.map.Sign_In.TruyenDuLieuDangKi;

import com.ngocdiem.map.Sign_In.UserDatabase.UserInfo;

public interface TransactionSignUp {
    void duLieuDangKi( UserInfo userInfoSignUp );
}
