package com.ngocdiem.map.Map.layTenCumDiaDiem;


public class NameLocation {
    private String mNameLocation;

    public NameLocation(String name){
        this.mNameLocation = name;
    }

    public String getmNameLocation() {
        return mNameLocation;
    }

    public void setmNameLocation(String mNameLocation) {
        this.mNameLocation = mNameLocation;
    }
}
