package com.ngocdiem.map.Map.layTenCumDiaDiem;


import android.content.Intent;

public interface PlayerListener {
    void onClickPlayer(int pos, Intent intent);
}
