package com.ngocdiem.map.Sign_In.TruyenDuLieuDangNhap;

public interface TransactionLogin {
    void duLieuDangNhap( String usernameLogin, String passwordLogin );
}
