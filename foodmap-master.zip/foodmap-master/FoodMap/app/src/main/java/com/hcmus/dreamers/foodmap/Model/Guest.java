package com.hcmus.dreamers.foodmap.Model;

public class Guest extends User {
    public Guest(String name, String email) {
        super(name, email);
    }
}
