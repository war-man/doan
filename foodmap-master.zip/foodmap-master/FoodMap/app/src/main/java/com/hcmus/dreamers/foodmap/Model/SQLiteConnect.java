package com.hcmus.dreamers.foodmap.Model;

import android.database.DatabaseErrorHandler;

public class SQLiteConnect {


}
