package com.hcmus.dreamers.foodmap.Model;

public interface TaskCompleteCallbacks {
    public void OnTaskComplete(int codeRequest, String responde);
}
