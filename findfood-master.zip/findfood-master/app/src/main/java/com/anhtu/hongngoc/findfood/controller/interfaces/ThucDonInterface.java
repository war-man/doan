package com.anhtu.hongngoc.findfood.controller.interfaces;


import com.anhtu.hongngoc.findfood.model.ThucDonModel;

import java.util.List;

public interface ThucDonInterface {
    public void getThucDonThanhCong(List<ThucDonModel> thucDonModelList);
}
