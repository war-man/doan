package com.anhtu.hongngoc.findfood.controller.interfaces;

import com.anhtu.hongngoc.findfood.model.QuanAnModel;

import java.util.List;

public interface OdauInterface {
    void getDanhSachQuanAnModel(QuanAnModel quanAnModel);
}
