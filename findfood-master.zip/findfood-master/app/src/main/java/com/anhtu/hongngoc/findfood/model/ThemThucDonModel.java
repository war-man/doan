package com.anhtu.hongngoc.findfood.model;

public class ThemThucDonModel {
    String mathucdon;
    MonAnModel monAnModel;

    public MonAnModel getMonAnModel() {
        return monAnModel;
    }

    public void setMonAnModel(MonAnModel monAnModel) {
        this.monAnModel = monAnModel;
    }



    public String getMathucdon() {
        return mathucdon;
    }

    public void setMathucdon(String mathucdon) {
        this.mathucdon = mathucdon;
    }
}
