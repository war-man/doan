package com.anhtu.hongngoc.findfood.controller.interfaces;

import com.anhtu.hongngoc.findfood.model.WifiQuanAnModel;

public interface ChiTietQuanAnInterface {
    void HienThiDanhSachWifi(WifiQuanAnModel wifiQuanAnModel);
}
