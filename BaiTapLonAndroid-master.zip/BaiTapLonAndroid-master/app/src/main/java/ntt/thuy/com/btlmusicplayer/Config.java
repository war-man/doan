package ntt.thuy.com.btlmusicplayer;

/**
 * Created by nguyen.thi.thu.thuy on 5/11/18.
 */

public class Config {
    public static final String CLIENT_ID = "a7Ucuq0KY8Ksn8WzBG6wj4x6pcId6BpU";
    public static final String PUBLIC_FILTER = "public";
    public static final String PRIVATE_FILTER = "private";
    public static final String ALL_FILTER = "all";
}
