<?php

    $mahocphan=$_GET['mahocphan'];

    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    mysqli_query($connect,'SET CHARACTER SET utf8');


    $sql_select=mysqli_query($connect,"select hocphan.* from hocphan, loptc where hocphan.MaHocPhan='$mahocphan' and hocphan.MaHocPhan=loptc.MaHocPhan;" );
    $row=mysqli_num_rows($sql_select);
    $output=array();

    if($row>0){
        $output['code']=0;
        $output['message']="khong the xoa";
    }
    else{
        $sql=mysqli_query($connect,"DELETE FROM `hocphan` WHERE `hocphan`.`MaHocPhan` = '$mahocphan';");
        if($sql){
            $output['code']=1;
            $output['message']="delete thanh cong";

        }
        else{
            $output['code']=0;
            $output['message']="delete that bai";
        }
    }

    print(json_encode($output,JSON_UNESCAPED_UNICODE));

    mysqli_close($connect);
?>