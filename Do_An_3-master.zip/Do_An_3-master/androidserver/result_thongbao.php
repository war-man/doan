<?php

    $magv=$_GET['magv'];


    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    mysqli_query($connect,'SET CHARACTER SET utf8');
    $sql=mysqli_query($connect,"select thongbao.*, sinhvien.HoTen, diem.DiemGiuaKy, diem.DiemCuoiKy from thongbao, phanconggiangday, giangvien, sinhvien, diem where thongbao.MaLopTC=phanconggiangday.MaLopTC and phanconggiangday.MaGiangVien=giangvien.MaGiangVien and giangvien.MaUser='$magv' and thongbao.MSSV=sinhvien.MSSV
        and diem.MSSV=thongbao.MSSV and diem.MaLopTC=thongbao.MaLopTC
         ;");
    

    if($sql === FALSE) {
        die(mysql_error()); // TODO: better error handling
    }
    $output=array();
    while($row=mysqli_fetch_assoc($sql))
        $output[]=$row;
    print(json_encode($output,JSON_UNESCAPED_UNICODE));
    mysqli_close($connect);
?>