<?php


    $ma_hoc_phan = $_GET['ma_hoc_phan'];
    $ten_hoc_phan = $_GET['ten_hoc_phan'];
    $ma_vien = $_GET['ma_vien'];
    $he_so = $_GET['he_so'];
    $tin_chi = $_GET['tin_chi'];

    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    mysqli_query($connect,'SET CHARACTER SET utf8');
    $sql=mysqli_query($connect,"insert into hocphan values ('$ma_hoc_phan','$ten_hoc_phan','$ma_vien','$he_so','$tin_chi')");
    
    if($sql === FALSE) {
        die(mysql_error()); // TODO: better error handling
    }
    
    mysqli_close($connect);
?>