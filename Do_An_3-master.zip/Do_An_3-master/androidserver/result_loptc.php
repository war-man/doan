<?php

    $ma_user = $_GET['mauser'];


    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    mysqli_query($connect,'SET CHARACTER SET utf8');
    $sql=mysqli_query($connect,"select loptc.*, hocphan.TenHocPhan from hocphan, loptc, phanconggiangday, giangvien where giangvien.MaGiangVien=phanconggiangday.MaGiangVien and phanconggiangday.MaLopTC=loptc.MaLopTC and giangvien.MaUser='$ma_user' and hocphan.MaHocPhan=loptc.MaHocPhan;");
    if($sql === FALSE) {
        die(mysql_error()); // TODO: better error handling
    }
    $output=array();
    while($row=mysqli_fetch_assoc($sql))
        $output[]=$row;
    print(json_encode($output,JSON_UNESCAPED_UNICODE));
    mysqli_close($connect);
?>