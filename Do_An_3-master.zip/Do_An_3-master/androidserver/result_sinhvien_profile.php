<?php
    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    $sql=mysqli_query($connect,"select * from sinhvien;");
    if($sql === FALSE) {
        die(mysql_error()); // TODO: better error handling
    }
    while($row=mysqli_fetch_assoc($sql))
        $output[]=$row;
    print(json_encode($output));
    mysqli_close($connect);
?>