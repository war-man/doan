<?php

    $mahocphan=$_GET['mahocphan'];
    echo $mahocphan;

   
?>