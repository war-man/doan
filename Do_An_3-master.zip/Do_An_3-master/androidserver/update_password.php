<?php

    $oldpw=$_GET['oldpw'];
    $newpw=$_GET['newpw'];
    $mauser=$_GET['mauser'];

    $connect = mysqli_connect("localhost","root","");
    mysqli_select_db($connect,"androidserverqldsv");
    mysqli_query($connect,'SET CHARACTER SET utf8');


    $sql_select=mysqli_query($connect,"select * from user where MaUser='$mauser' and Password='$oldpw';" );
    $row=mysqli_num_rows($sql_select);
    $output=array();

    if($row>0){
        $sql=mysqli_query($connect,"update user set Password='$newpw' where MaUser='$mauser';");
        if($sql){
            $output['code']=1;
            $output['message']="update thanh cong";

        }
        else{
            $output['code']=0;
            $output['message']="update that bai";
        }
    }
    else{
        $output['code']=0;
        $output['message']="sai pw";
        
    }

    print(json_encode($output,JSON_UNESCAPED_UNICODE));

    mysqli_close($connect);
?>