package com.example.qldsv.model;

public class Count_Diem {
    private String Diem;
    private int SoLuong;

    public String getDiem() {
        return Diem;
    }

    public void setDiem(String diem) {
        Diem = diem;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public Count_Diem() {
    }

    public Count_Diem(String diem, int soLuong) {
        Diem = diem;
        SoLuong = soLuong;
    }
}
