package com.example.qldsv.control;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.sinhvien.Menu_Sinhvien;
import com.example.qldsv.model.User;
import com.example.qldsv.admin.Menu_Activity;
import com.example.qldsv.giang_vien.Menu_GiangVien;
import com.example.qldsv.sinhvien.Menu_Sinhvien;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;



public class Login_Activity extends AppCompatActivity{



    public static final String TAG = "user list";
    public static final String MaUser = "MaUser";
    String urlgetData;
    User user = new User();
    ArrayList<User> arrayUser = new ArrayList<>(); // luu tru cac tai khoan tu DB
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;
    private Boolean saveLogin;
    private CheckBox checkBox;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        LinearLayout linearLayout = (LinearLayout)findViewById(R.id.login_sss);
        AnimationDrawable animationDrawable = (AnimationDrawable)linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        (this).getSupportActionBar().setTitle(R.string.Login_Activity);

        getLinkFromDomain gL = new getLinkFromDomain();
        urlgetData = gL.urlgetData_Login();

        //tao hieu ung cho cac edit text trong login.xml
        EditText ed1=(EditText)findViewById(R.id.User);
        EditText ed2=(EditText)findViewById(R.id.Password);
        //them cac hieu ung vien bo ben ngoai
        ed2.setBackgroundResource(R.drawable.lost_focus_border_style);

        ed1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){//neu dang chinh sua
                    v.setBackgroundResource(R.drawable.focus_border_style);
                } else {//khong chinh sua
                    v.setBackgroundResource(R.drawable.lost_focus_border_style);
                }
            }
        });
        ed2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){//dang chinh sua
                    v.setBackgroundResource(R.drawable.focus_border_style);
                } else {//khong chinh sua
                    v.setBackgroundResource(R.drawable.lost_focus_border_style);
                }
            }
        });

        // gan su kien cho nut login
        getData(urlgetData);
        Button login = (Button)findViewById(R.id.login);
        login.setOnClickListener(onLogin);

        checkBox=(CheckBox)findViewById(R.id.check_box_login);//lay id checkbox
        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        saveLogin = loginPreferences.getBoolean("saveLogin", false);
        if (saveLogin == true) {//neu da an nho thong tin tai khoan mat khau
            ed1.setText(loginPreferences.getString("username", ""));//truyen du lieu vao 2 edittext
            ed2.setText(loginPreferences.getString("password", ""));
            checkBox.setChecked(true);
        }

    }
    private View.OnClickListener onLogin = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            EditText ed1=(EditText)findViewById(R.id.User);
            EditText ed2=(EditText)findViewById(R.id.Password);

            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(ed1.getWindowToken(), 0);


            if (checkBox.isChecked()) {
                loginPrefsEditor.putBoolean("saveLogin", true);
                loginPrefsEditor.putString("username", ed1.getText().toString());//lay du lieu tu 2 edittext
                loginPrefsEditor.putString("password", ed2.getText().toString());
                loginPrefsEditor.commit();
            } else {
                loginPrefsEditor.clear();//neu khong thi xoa du lieu di
                loginPrefsEditor.commit();
            }




            user.setUser(ed1.getText().toString());
            user.setPassword(ed2.getText().toString());
            getData(urlgetData);
            Log.e("Nguoi dung nhap",user.toString());
            //Ket noi voi database
            //1 lay du lieu tu respone tra ve


            int check=0;
            int chucvu=-1;
            int Ma_user=-1;
            for(int i=0;i<arrayUser.size();i++){
                if((arrayUser.get(i).getUser().equals(user.getUser()))&&(arrayUser.get(i).getPassword().equals(user.getPassword())))
                {
                    check =1;
                    chucvu=arrayUser.get(i).getChucvu();
                    Ma_user=arrayUser.get(i).getMaUser();
                    Log.e("MaU_login:   ", String.valueOf(Ma_user));
                }
            }
            if(check==1)
            {
                arrayUser.clear();
                if(chucvu==0){
                    Intent intent=new Intent(Login_Activity.this, Menu_Activity.class);

                    startActivity(intent);
                }
                else if(chucvu==1){
                    Intent intent=new Intent(Login_Activity.this, Menu_GiangVien.class);
                    intent.putExtra(MaUser,Ma_user);
                    startActivity(intent);
                }
                else if(chucvu==2){
                    Intent intent=new Intent(Login_Activity.this, Menu_Sinhvien.class);
                    intent.putExtra(MaUser,Ma_user);
                    startActivity(intent);
                }


            }
            else{
                Toast.makeText(Login_Activity.this,"Mật khẩu hoặc tài khoản không chính xác",   Toast.LENGTH_SHORT).show();
            }

        }
    };


    private void getData(String url){
        //Ham ket noi voi DB de lay tai khoan mat khau
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){//Lay du lieu tu mang JSon
                            try {
                                JSONObject object = response.getJSONObject(i);
                                arrayUser.add(new User(//Luu vao mang User
                                        object.getInt("MaUser"),
                                        object.getString("User"),
                                        object.getString("Password"),
                                        object.getInt("Chucvu")
                                ));

                                Log.e(TAG,arrayUser.get(i).toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {//Loi k ket noi dc Server
                        Toast.makeText(Login_Activity.this,"Lỗi không kết nối được server",Toast.LENGTH_SHORT).show();

                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }
}
