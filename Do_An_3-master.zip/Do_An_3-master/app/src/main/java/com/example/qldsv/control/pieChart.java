package com.example.qldsv.control;

import android.content.Context;
import android.database.DefaultDatabaseErrorHandler;
import android.graphics.Color;
import android.opengl.GLSurfaceView;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import java.io.Serializable;

public class pieChart{
    public GraphicalView getraphicalView(Context context,int Ap,int A,int Bp, int B, int Cp, int C, int Dp, int D, int F){
        CategorySeries series=new CategorySeries("Thống kê số điểm chữ");
        int[] position={Ap,A,Bp,B,Cp,C,Dp,D,F};//danh sách các vị trí
        String[] seriesNames=new String[]{"A+","A","B+","B","C+","C","D+","D","F"};//Tên các phần trong biểu đồ

        int numSlide =9;
        for(int i=0;i<numSlide;i++){
            series.add(seriesNames[i],position[i]);
        }
        DefaultRenderer defaultRenderer= new DefaultRenderer();

        defaultRenderer.setLegendHeight(400);//chinh kich thuoc chu thich
        defaultRenderer.setFitLegend(true);
        defaultRenderer.setLegendTextSize(70);//kich thuoc font chu thich
        defaultRenderer.setLabelsColor(Color.RED);//chinh mau sac chu thich trong bieu do
        defaultRenderer.setPanEnabled(false);//khong cho phep keo bieu do
        SimpleSeriesRenderer simpleSeriesRenderer=null;
        int[] color={//cai dat mau cac phan trong bieu do
               Color.rgb(255,0,0),
                Color.rgb(255,20,147),
                Color.rgb(238 ,238, 0),
                Color.rgb(202 ,255, 112),
                Color.rgb(32 ,178 ,170),
                Color.rgb(150, 205, 205),
                Color.rgb(255 ,228 ,181),
                Color.rgb(25 ,68 ,81),
                Color.rgb(66 ,8 ,11)


        };
        for (int i=0;i<numSlide;i++){
            simpleSeriesRenderer=new SimpleSeriesRenderer();
            simpleSeriesRenderer.setColor(color[i]);
            defaultRenderer.addSeriesRenderer(simpleSeriesRenderer);
        }

        return ChartFactory.getPieChartView(context,series,defaultRenderer);

    }


}
