package com.example.qldsv.control;

import android.util.Log;

public class setDiem {
    private double diemGiuaKy;
    private double diemCuoiKy;

    public setDiem() {
    }

    public setDiem(double diemGiuaKy, double diemCuoiKy) {
        this.diemGiuaKy = diemGiuaKy;
        this.diemCuoiKy = diemCuoiKy;
    }

    public double getDiemGiuaKy() {
        return diemGiuaKy;
    }

    public void setDiemGiuaKy(double diemGiuaKy) {
        this.diemGiuaKy = diemGiuaKy;
    }

    public double getDiemCuoiKy() {
        return diemCuoiKy;
    }

    public void setDiemCuoiKy(double diemCuoiKy) {
        this.diemCuoiKy = diemCuoiKy;
    }

    public double getDiemTB(double diemGiuaKy, double diemCuoiKy, String HeSo){
        if(diemGiuaKy<3) return -1;
        else if (HeSo.equals("2-8")) return (diemGiuaKy*0.2 + diemCuoiKy*0.8);
        else if (HeSo.equals("3-7")) return (diemGiuaKy*0.3 + diemCuoiKy*0.7);
        else if (HeSo.equals("4-6")) return (diemGiuaKy*0.4 + diemCuoiKy*0.6);
        else if (HeSo.equals("5-5")) return (diemGiuaKy*0.5 + diemCuoiKy*0.5);
        else return 0;
    }

    public String setDiemChu(double diemGiuaKy, double diemCuoiKy , String HeSo){
        String diemChu = null;
        double dtb=getDiemTB(diemGiuaKy,diemCuoiKy,HeSo);
        Log.wtf("dtb",String.valueOf(dtb));
        if(dtb==-1) diemChu="F";
        else if (dtb == 0) diemChu="-";
        else if (4<=dtb&&dtb<5) diemChu="D";
        else if (5<=dtb&&dtb<5.5) diemChu="D%2B";
        else if (5.5<=dtb&&dtb<6.5) diemChu="C";
        else if (6.5<=dtb&&dtb<7) diemChu="C%2B";
        else if (7<=dtb&&dtb<8) diemChu="B";
        else if (8<=dtb&&dtb<8.5) diemChu="B%2B";
        else if (8.5<=dtb&&dtb<9.5) diemChu="A";
        else if (9.5<=dtb&&dtb<=10) diemChu="A%2B";
        return diemChu;
    }

}
