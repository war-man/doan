package com.example.qldsv.admin;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.qldsv.R;

public class Add_Account extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_account);
        Intent intent=getIntent();
        String LopSV= intent.getStringExtra("MaLopSV");
        (this).getSupportActionBar().setTitle(LopSV);

        EditText ed_acc_name=(EditText)findViewById(R.id.acc_name);
        EditText ed_acc_maso=(EditText)findViewById(R.id.acc_maso);
        EditText ed_acc_sdt=(EditText)findViewById(R.id.acc_sdt);
        EditText ed_acc_tk=(EditText)findViewById(R.id.acc_acc);
        EditText ed_acc_pw=(EditText)findViewById(R.id.acc_pw);
        Spinner spn_gender=(Spinner)findViewById(R.id.acc_gender);
        TextView tv_vien_lop=(TextView)findViewById(R.id.acc_vien_lop);
        Spinner spn_vien_lop=(Spinner)findViewById(R.id.acc_spn_vien_lop);
        Button save=(Button)findViewById(R.id.acc_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

}
