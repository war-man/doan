package com.example.qldsv.model;

public class DiemSV {
    private int MSSV;
    private int MaLopTC;
    private int HocKy;
    private double DiemGiuaKy;
    private double DiemCuoiKy;
    private String DiemChu;
    private String MaHocPhan;
    private String TenHocPhan;

    public DiemSV() {
    }

    public DiemSV(int MSSV, int maLopTC, int hocKy, double diemGiuaKy, double diemCuoiKy, String diemChu, String maHocPhan, String tenHocPhan) {
        this.MSSV = MSSV;
        MaLopTC = maLopTC;
        HocKy = hocKy;
        DiemGiuaKy = diemGiuaKy;
        DiemCuoiKy = diemCuoiKy;
        DiemChu = diemChu;
        MaHocPhan = maHocPhan;
        TenHocPhan = tenHocPhan;
    }

    public int getMSSV() {
        return MSSV;
    }

    public void setMSSV(int MSSV) {
        this.MSSV = MSSV;
    }

    public int getMaLopTC() {
        return MaLopTC;
    }

    public void setMaLopTC(int maLopTC) {
        MaLopTC = maLopTC;
    }

    public int getHocKy() {
        return HocKy;
    }

    public void setHocKy(int hocKy) {
        HocKy = hocKy;
    }

    public double getDiemGiuaKy() {
        return DiemGiuaKy;
    }

    public void setDiemGiuaKy(double diemGiuaKy) {
        DiemGiuaKy = diemGiuaKy;
    }

    public double getDiemCuoiKy() {
        return DiemCuoiKy;
    }

    public void setDiemCuoiKy(double diemCuoiKy) {
        DiemCuoiKy = diemCuoiKy;
    }

    public String getDiemChu() {
        return DiemChu;
    }

    public void setDiemChu(String diemChu) {
        DiemChu = diemChu;
    }

    public String getMaHocPhan() {
        return MaHocPhan;
    }

    public void setMaHocPhan(String maHocPhan) {
        MaHocPhan = maHocPhan;
    }

    public String getTenHocPhan() {
        return TenHocPhan;
    }

    public void setTenHocPhan(String tenHocPhan) {
        TenHocPhan = tenHocPhan;
    }
}
