package com.example.qldsv.sinhvien;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.giang_vien.Class_Giangvien;
import com.example.qldsv.giang_vien.List_SV_Giangvien;
import com.example.qldsv.giang_vien.QuanLyDiem_GiangVien;
import com.example.qldsv.model.Diem;
import com.example.qldsv.model.DiemSV;
import com.example.qldsv.model.LopTC;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Diem_Sinhvien extends Activity {

    ArrayList<DiemSV> arrayDiem= new ArrayList<>(); // luu tru cac lop tin chi phu trach
    String urlgetData;
    ListView listView;



    class Diem_Adapter extends ArrayAdapter<DiemSV> {
        Diem_Adapter() {
            super(Diem_Sinhvien.this,
                    android.R.layout.simple_list_item_1,
                    arrayDiem);
        }

        public View getView(int position, View convertView, ViewGroup parent){
            View row=convertView;
            Diem_Holder holder=null;
            if(row==null){
                LayoutInflater inflater=getLayoutInflater();

                row=inflater.inflate(R.layout.row_diem, null);
                holder=new Diem_Holder(row);
                row.setTag(holder);
            }
            DiemSV r=arrayDiem.get(position);
            ((TextView)row.findViewById(R.id.row_diem_mssv)).setText(String.valueOf(r.getHocKy()));
            ((TextView)row.findViewById(R.id.row_diem_hoten)).setText(r.getMaHocPhan() +" - "+r.getMaLopTC());
            ((TextView)row.findViewById(R.id.row_diem_gk)).setText(String.valueOf(r.getDiemGiuaKy()));
            ((TextView)row.findViewById(R.id.row_diem_ck)).setText(String.valueOf(r.getDiemCuoiKy()));
            ((TextView)row.findViewById(R.id.row_diem_chu)).setText(r.getDiemChu());
            return row;
        }
    }

    static class Diem_Holder{
        private TextView tv1 = null;
        private TextView tv2=null;
        private TextView tv3=null;
        private TextView tv4=null;
        private TextView tv5=null;

        Diem_Holder(View row){
            tv1=(TextView)row.findViewById(R.id.row_diem_mssv);
            tv2=(TextView)row.findViewById(R.id.row_diem_hoten);
            tv3=(TextView)row.findViewById(R.id.row_diem_gk);
            tv4=(TextView)row.findViewById(R.id.row_diem_ck);
            tv5=(TextView)row.findViewById(R.id.row_diem_chu);
        }
        void populateForm(DiemSV r){
            tv1.setText(String.valueOf(r.getHocKy()));
            tv2.setText(r.getMaHocPhan() +" - "+r.getMaLopTC());
            tv3.setText(String.valueOf(r.getDiemGiuaKy()));
            tv4.setText(String.valueOf(r.getDiemCuoiKy()));
            tv5.setText(r.getDiemChu());

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diem_sinhvien);



        Intent intent=getIntent();
        int mauser=intent.getIntExtra("MaUserFromMenu",0);
        //(this).getSupportActionBar().setTitle(String.valueOf(maloptc));

        Log.e("MaLopTc",String.valueOf(mauser));

        getLinkFromDomain gL=new getLinkFromDomain();
        urlgetData=gL.urlgetData_Diem_SinhVien(String.valueOf(mauser));
        getData(urlgetData);

        listView=(ListView)findViewById(R.id.listview_diem_sinhvien);
        Diem_Adapter adapter=new Diem_Adapter();
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o=listView.getItemAtPosition(position);
                DiemSV diem =(DiemSV)o;
                Intent intent1=new Intent(Diem_Sinhvien.this, Show_Diem_Sinhvien.class);
                Bundle bundle = new Bundle();
                bundle.putInt("MSSV",diem.getMSSV());
                bundle.putInt("MaLopTC",diem.getMaLopTC());
                bundle.putInt("HocKy",diem.getHocKy());
                bundle.putDouble("DiemGiuaKy",diem.getDiemGiuaKy());
                bundle.putDouble("DiemCuoiKy",diem.getDiemCuoiKy());
                bundle.putString("DiemChu",diem.getDiemChu());
                bundle.putString("MaHocPhan",diem.getMaHocPhan());
                bundle.putString("TenHocPhan",diem.getTenHocPhan());
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });


        final SwipeRefreshLayout pullToRefresh=findViewById(R.id.sw);


        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {//keo de lay du lieu moi nhat
                getData(urlgetData);//lay du lieu tu server
                listView=(ListView)findViewById(R.id.listview_diem_sinhvien);
                Diem_Adapter adapter=new Diem_Adapter();
                listView.setAdapter(adapter);//gan adapter

                //truyen du lieu cho activity sau
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Object o=listView.getItemAtPosition(position);
                        DiemSV diem =(DiemSV)o;
                        Intent intent1=new Intent(Diem_Sinhvien.this, Show_Diem_Sinhvien.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("MSSV",diem.getMSSV());
                        bundle.putInt("MaLopTC",diem.getMaLopTC());
                        bundle.putInt("HocKy",diem.getHocKy());
                        bundle.putDouble("DiemGiuaKy",diem.getDiemGiuaKy());
                        bundle.putDouble("DiemCuoiKy",diem.getDiemCuoiKy());
                        bundle.putString("DiemChu",diem.getDiemChu());
                        bundle.putString("MaHocPhan",diem.getMaHocPhan());
                        bundle.putString("TenHocPhan",diem.getTenHocPhan());
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                    }
                });
                pullToRefresh.setRefreshing(false);
            }
        });



    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                arrayDiem.add(new DiemSV(
                                        object.getInt("MSSV"),
                                        object.getInt("MaLopTC"),
                                        object.getInt("HocKy"),
                                        object.getDouble("DiemGiuaKy"),
                                        object.getDouble("DiemCuoiKy"),
                                        object.getString("DiemChu"),
                                        object.getString("MaHocPhan"),
                                        object.getString("TenHocPhan")
                                ));

                                Log.e("array diem",String.valueOf(arrayDiem.get(i).getMaLopTC()));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }
}
