package com.example.qldsv.model;

public class Thongbao {
    private int MaThongBao;
    private int MSSV;
    private String HoTenSV;
    private int MaLopTC;
    private String NoiDung;
    private double DiemGiuaKy;
    private double DiemCuoiKy;

    public Thongbao() {
    }

    public Thongbao(int maThongBao, int MSSV, String hoTenSV, int maLopTC, String noiDung, double diemGiuaKy, double diemCuoiKy) {
        MaThongBao = maThongBao;
        this.MSSV = MSSV;
        HoTenSV = hoTenSV;
        MaLopTC = maLopTC;
        NoiDung = noiDung;
        DiemGiuaKy = diemGiuaKy;
        DiemCuoiKy = diemCuoiKy;
    }

    public int getMaThongBao() {
        return MaThongBao;
    }

    public void setMaThongBao(int maThongBao) {
        MaThongBao = maThongBao;
    }

    public int getMSSV() {
        return MSSV;
    }

    public void setMSSV(int MSSV) {
        this.MSSV = MSSV;
    }

    public String getHoTenSV() {
        return HoTenSV;
    }

    public void setHoTenSV(String hoTenSV) {
        HoTenSV = hoTenSV;
    }

    public int getMaLopTC() {
        return MaLopTC;
    }

    public void setMaLopTC(int maLopTC) {
        MaLopTC = maLopTC;
    }

    public String getNoiDung() {
        return NoiDung;
    }

    public void setNoiDung(String noiDung) {
        NoiDung = noiDung;
    }

    public double getDiemGiuaKy() {
        return DiemGiuaKy;
    }

    public void setDiemGiuaKy(double diemGiuaKy) {
        DiemGiuaKy = diemGiuaKy;
    }

    public double getDiemCuoiKy() {
        return DiemCuoiKy;
    }

    public void setDiemCuoiKy(double diemCuoiKy) {
        DiemCuoiKy = diemCuoiKy;
    }
}
