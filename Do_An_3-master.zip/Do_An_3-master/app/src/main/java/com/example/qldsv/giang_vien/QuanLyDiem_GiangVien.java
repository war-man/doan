package com.example.qldsv.giang_vien;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.admin.ListSinhVien;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.control.setDiem;
import com.example.qldsv.model.LopSV;
import com.example.qldsv.model.LopTC;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class QuanLyDiem_GiangVien extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quanly_diem_sv);

        Intent intent=getIntent();
        int maloptc = intent.getIntExtra("MaLopTC",0);

        (this).getSupportActionBar().setTitle(String.valueOf(maloptc));

        EditText ed1 = (EditText)findViewById(R.id.ql_diem_gk);
        EditText ed2 = (EditText)findViewById(R.id.ql_diem_ck);
        TextView t=(TextView)findViewById(R.id.ql_diem_tensv);

        Bundle bundle = intent.getExtras();
        int MSSV=bundle.getInt("MSSV",0);
        String hoTen=bundle.getString("HoTenSV","");
        double dg=bundle.getDouble("DiemGiuaKy",0);
        double dc=bundle.getDouble("DiemCuoiKy",0);

        ed1.setText(String.valueOf(dg));
        ed2.setText(String.valueOf(dc));
        t.setText(hoTen +" - "+MSSV);

        Button saveDiem = (Button)findViewById(R.id.save_quanlydiem);
        saveDiem.setOnClickListener(onsaveDiem);

    }


    private View.OnClickListener onsaveDiem = new View.OnClickListener() {
        @Override
        public void onClick(View v) {



            EditText ed1 = (EditText)findViewById(R.id.ql_diem_gk);
            EditText ed2 = (EditText)findViewById(R.id.ql_diem_ck);

            double dg = Double.parseDouble(ed1.getText().toString()) ;
            double dc = Double.parseDouble(ed2.getText().toString()) ;


            Intent intent = getIntent();
            Bundle bundle = intent.getExtras();
            int MSSV=bundle.getInt("MSSV",0);
            int MaLopTC=bundle.getInt("MaLopTC",0);
            String heso=bundle.getString("HeSo","");
            Log.e("diemgk, diemck ",dg+"-"+dc+" mssv:"+MSSV+"--"+MaLopTC);
            getLinkFromDomain gL = new getLinkFromDomain();
            String url = gL.urlupdateData_DiemSv(MSSV,MaLopTC,dg,dc);
            setDiem sd= new setDiem();

            String diemChu=sd.setDiemChu(dg,dc,heso);
            String url2=gL.urlupdateDiemChu(diemChu,MSSV,MaLopTC);
            Log.wtf("urldiemchu",url2); Log.wtf("diemchu=",diemChu);
            getData(url);
            getData(url2);
            Toast.makeText(QuanLyDiem_GiangVien.this,"Thay đổi điểm thành công",Toast.LENGTH_SHORT).show();


        }
    };


    private void getData(String url){
// prepare the Request
        Log.e("url", url);
        RequestQueue queue = Volley.newRequestQueue(this);  // this = context
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        // display response
                        Log.d("Response", response.toString());
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );

        // add it to the RequestQueue
        queue.add(getRequest);
    }
}
