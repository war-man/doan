package com.example.qldsv.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.qldsv.R;
import com.example.qldsv.model.GiangVien;
import com.example.qldsv.model.HocPhan;
import com.example.qldsv.model.SinhVien;

import java.util.ArrayList;

public class ListGVAdapter extends BaseAdapter implements Filterable {
    public Context context;
    public ArrayList<GiangVien> GVArray;
    public ArrayList<GiangVien> orig;

    public ListGVAdapter(Context context, ArrayList<GiangVien> GVArray) {
        this.context = context;
        this.GVArray = GVArray;
    }

    @Override
    public int getCount() {
        return GVArray.size();
    }

    @Override
    public Object getItem(int position) {
        return GVArray.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    public class Holder{
        private TextView first = null;
        private TextView second=null;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.row_hocphan,parent,false);
            holder=new Holder();
            holder.first=(TextView)convertView.findViewById(R.id.first_row_hocphan);
            holder.second=(TextView)convertView.findViewById(R.id.second_row_hocphan);
            convertView.setTag(holder);
        }
        else {
            holder=(Holder) convertView.getTag();
        }
        holder.first.setText(GVArray.get(position).getHoTen());
        holder.second.setText(GVArray.get(position).getMaGiangVien());
        return convertView;
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                final FilterResults oReturn=new FilterResults();
                final ArrayList<GiangVien> result=new ArrayList<GiangVien>();
                if(orig==null) orig=GVArray;
                if(constraint!=null){
                    if(orig!=null && orig.size()>0){
                        for(final GiangVien g : orig){
                            if(g.getHoTen().toLowerCase().contains(constraint.toString())||String.valueOf(g.getMaGiangVien()).contains(constraint.toString()))
                                result.add(g);
                        }
                    }
                    oReturn.values=result;
                }

                return oReturn;

            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                GVArray=(ArrayList<GiangVien>)results.values;
                notifyDataSetChanged();
            }
        };
    }
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
