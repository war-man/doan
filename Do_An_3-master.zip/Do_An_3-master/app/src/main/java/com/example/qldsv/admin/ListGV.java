package com.example.qldsv.admin;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.GiangVien;
import com.example.qldsv.model.SinhVien;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListGV extends AppCompatActivity implements SearchView.OnQueryTextListener {

    ArrayList<GiangVien> arrayGiangVien=new ArrayList<>();
    ListGVAdapter adapter;
    ListView listView;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actions3, menu);
        MenuItem itemSearch=menu.findItem(R.id.search3);
        SearchView mSearchView = (SearchView) itemSearch.getActionView();
        mSearchView.setQueryHint("Tìm kiếm");
        mSearchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if(TextUtils.isEmpty(newText)){
            adapter.getFilter().filter("");
            listView.clearTextFilter();
        }else {
            listView.setFilterText(newText);
            adapter.getFilter().filter(newText);

        }
        return true;
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_danhsach_hocphan);

        (this).getSupportActionBar().setTitle("Danh sách giảng viên");
        getLinkFromDomain gl=new getLinkFromDomain();
        String url=gl.urlgetData_ListGV();
        Log.e("url list gv",url);
        arrayGiangVien=getData(url);

        listView=(ListView)findViewById(R.id.listview_admin_list_hocphan);
        adapter=new ListGVAdapter(this,arrayGiangVien);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }

    private ArrayList<GiangVien> getData(String url){

        final  ArrayList<GiangVien> arrayGiangVienx=new ArrayList<>();
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                arrayGiangVienx.add(new GiangVien(
                                        object.getInt("MaUser"),
                                        object.getString("MaGiangVien"),
                                        object.getString("MaVien"),
                                        object.getString("HoTen"),
                                        object.getString("NgaySinh"),
                                        object.getString("GioiTinh"),
                                        object.getInt("SoDienThoai")
                                ));

                                Log.e("array lopsv",arrayGiangVienx.get(i).getHoTen());
                                //Toast.makeText(ListSinhVien.this,"Lỗi không kết nối được server",Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
        return arrayGiangVienx;
    }
}
