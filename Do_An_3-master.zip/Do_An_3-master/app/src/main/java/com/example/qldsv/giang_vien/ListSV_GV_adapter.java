package com.example.qldsv.giang_vien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.qldsv.R;
import com.example.qldsv.model.Diem;

import java.util.ArrayList;

public class ListSV_GV_adapter extends BaseAdapter implements Filterable {
    public Context context;
    public ArrayList<Diem> DiemArrayList;//danh sach Diem
    public ArrayList<Diem> orig;//danh sach tim kiem

    public ListSV_GV_adapter(Context context, ArrayList<Diem> DiemArrayList){
        super();
        this.context = context;
        this.DiemArrayList = DiemArrayList;
    }

    public class DiemHolder{ //holder cho cac row trong listview
        private TextView tv1=null;
        private TextView tv2=null;
        private TextView tv3=null;
        private TextView tv4=null;
        private TextView tv5=null;
    }



    @Override
    public int getCount() {
        return DiemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return DiemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DiemHolder holder;
        if(convertView==null){//do du lieu cho row
            convertView= LayoutInflater.from(context).inflate(R.layout.row_diem,parent,false);
            holder=new DiemHolder();
            holder.tv1=(TextView)convertView.findViewById(R.id.row_diem_mssv);
            holder.tv2=(TextView)convertView.findViewById(R.id.row_diem_hoten);
            holder.tv3=(TextView)convertView.findViewById(R.id.row_diem_gk);
            holder.tv4=(TextView)convertView.findViewById(R.id.row_diem_ck);
            holder.tv5=(TextView)convertView.findViewById(R.id.row_diem_chu);
            convertView.setTag(holder);
        }
        else {
            holder=(DiemHolder)convertView.getTag();
        }//do du lieu
        holder.tv1.setText(String.valueOf(DiemArrayList.get(position).getMSSV()));
        holder.tv2.setText(DiemArrayList.get(position).getHoTenSV());
        holder.tv3.setText(String.valueOf(DiemArrayList.get(position).getDiemGiuaKy()));
        holder.tv4.setText(String.valueOf(DiemArrayList.get(position).getDiemCuoiKy()));
        holder.tv5.setText(DiemArrayList.get(position).getDiemChu());


        return convertView;
    }

    @Override
    public Filter getFilter() {//ham tim kiem
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                final FilterResults oReturn=new FilterResults();
                final ArrayList<Diem> result=new ArrayList<Diem>();
                if(orig==null) orig=DiemArrayList;
                if(constraint!=null){
                    if(orig!=null && orig.size()>0){
                        for(final Diem g : orig){//so sanh gia tri truyen vao
                            if(g.getHoTenSV().toLowerCase().contains(constraint.toString())||String.valueOf(g.getMSSV()).contains(constraint.toString()))
                                result.add(g);
                        }
                    }
                    oReturn.values=result;
                }

                return oReturn;
            }


            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                DiemArrayList=(ArrayList<Diem>)results.values;//them du lieu khi tim kiem thanh cong
                notifyDataSetChanged();
            }
        };
    }
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }


}
