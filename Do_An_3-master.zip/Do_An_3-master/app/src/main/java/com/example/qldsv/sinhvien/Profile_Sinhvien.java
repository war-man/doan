package com.example.qldsv.sinhvien;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.ImageConverter;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.GiangVien;
import com.example.qldsv.model.SinhVien;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile_Sinhvien extends Activity {

    String urlgetData;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_sinhvien);

        final Intent intent = getIntent();
        final int ms = intent.getIntExtra("MaUserFromMenu",0);

        getLinkFromDomain gL = new getLinkFromDomain();
        urlgetData = gL.urlgetData_Profile_SinhVien(String.valueOf(ms));//url lay du lieu tu server

        Log.e("link:::", urlgetData);
        getData(urlgetData);//lay du lieu

        final TextView textView=(TextView)findViewById(R.id.name_sinhvien);
        LinearLayout linearLayout=(LinearLayout)findViewById(R.id.setting_ll);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//truyen du lieu khi vao trang thay doi mat khau
                Intent intent1=new Intent(Profile_Sinhvien.this,Setting.class);
                Bundle bundle=new Bundle();
                bundle.putInt("MaUser",ms);
                bundle.putString("HoTen",textView.getText().toString());
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });


    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu

        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);//Lay thong tin tu JSon
                                SinhVien gv = new SinhVien(
                                        object.getInt("MaUser"),
                                        object.getInt("MSSV"),
                                        object.getString("MaLopSV"),
                                        object.getString("HoTen"),
                                        object.getString("NgaySinh"),
                                        object.getString("GioiTinh"),
                                        object.getInt("SoDienThoai")
                                );
                                Log.e("sinhvien_js", gv.toString());
                                //truyen du lieu cho cac textview va Image gioi tinh
                                TextView tv_Name = (TextView)findViewById(R.id.name_sinhvien);
                                TextView tv_Birth = (TextView)findViewById(R.id.birth_sinhvien);
                                TextView tv_MaGV = (TextView)findViewById(R.id.ma_mssv);
                                TextView tv_Vien = (TextView)findViewById(R.id.vien_sinhvien);
                                TextView tv_SDT = (TextView)findViewById(R.id.sdt_sinhvien);
                                CircleImageView gender=(CircleImageView)findViewById(R.id.gender);


                                //truyen du lieu
                                tv_Name.setText(gv.getHoTen());
                                //tv_Name.setText("Phạm Hoài Lâm");
                                tv_MaGV.setText("MSSV: "+gv.getMSSV());
                                tv_Birth.setText("Ngày sinh: "+gv.getNgaySinh());
                                tv_SDT.setText("SDT: +84 "+gv.getSoDienThoai());
                                tv_Vien.setText("Lớp: "+gv.getMaLopSV());
                                if(gv.getGioiTinh().equals("Nam")) gender.setImageResource(R.drawable.male);
                                else gender.setImageResource(R.drawable.female);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(Login_Activity.this,"Lỗi không kết nối được server",Toast.LENGTH_SHORT).show();

                    }
                }
        );
        requestQueue.add(jsonArrayRequest);

    }


}
