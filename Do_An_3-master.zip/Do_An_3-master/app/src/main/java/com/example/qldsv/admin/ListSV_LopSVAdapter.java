package com.example.qldsv.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.qldsv.R;
import com.example.qldsv.model.SinhVien;

import java.util.ArrayList;

public class ListSV_LopSVAdapter extends BaseAdapter implements Filterable {
    public Context context;
    public ArrayList<SinhVien> SinhvienArray;
    public ArrayList<SinhVien> orig;


    public ListSV_LopSVAdapter(Context context, ArrayList<SinhVien> sinhvienArray) {
        this.context = context;
        SinhvienArray = sinhvienArray;
    }

    public class Holder{
        private TextView first = null;
        private TextView second=null;
    }

    @Override
    public int getCount() {
        return SinhvienArray.size();
    }

    @Override
    public Object getItem(int position) {
        return SinhvienArray.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.row_hocphan,parent,false);
            holder=new Holder();
            holder.first=(TextView)convertView.findViewById(R.id.first_row_hocphan);
            holder.second=(TextView)convertView.findViewById(R.id.second_row_hocphan);
            convertView.setTag(holder);
        }
        else {
            holder=(Holder) convertView.getTag();
        }
        holder.first.setText(SinhvienArray.get(position).getHoTen());
        holder.second.setText(String.valueOf(SinhvienArray.get(position).getMSSV()));
        return convertView;

    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                final FilterResults oReturn=new FilterResults();
                final ArrayList<SinhVien> result=new ArrayList<SinhVien>();
                if(orig==null) orig=SinhvienArray;
                if(constraint!=null){
                    if(orig!=null && orig.size()>0){
                        for(final SinhVien g : orig){
                            if(g.getHoTen().toLowerCase().contains(constraint.toString())||String.valueOf(g.getMSSV()).contains(constraint.toString()))
                                result.add(g);
                        }
                    }
                    oReturn.values=result;
                }

                return oReturn;

            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                SinhvienArray=(ArrayList<SinhVien>)results.values;
                notifyDataSetChanged();
            }
        };
    }
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
