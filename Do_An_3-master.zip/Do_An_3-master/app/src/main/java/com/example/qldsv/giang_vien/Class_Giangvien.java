package com.example.qldsv.giang_vien;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.LopTC;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Class_Giangvien extends Activity {

    ArrayList<LopTC> arrayLopTC = new ArrayList<>(); // luu tru cac lop tin chi phu trach
    String urlgetData;
    ListView listView;


    class LopTC_Adapter extends ArrayAdapter<LopTC> {
        LopTC_Adapter() {
            super(Class_Giangvien.this,
                    android.R.layout.simple_list_item_1,
                    arrayLopTC);
        }

        public View getView(int position, View convertView, ViewGroup parent){
            View row=convertView;
            LopTC_Holder holder=null;
            if(row==null){
                LayoutInflater inflater=getLayoutInflater();

                row=inflater.inflate(R.layout.row_lophoc, null);
                holder=new LopTC_Holder(row);
                row.setTag(holder);
            }
            LopTC r=arrayLopTC.get(position);
            ((TextView)row.findViewById(R.id.first_row_lophoc)).setText(r.getMaLopTC()+" "+r.getMaHocPhan());
            ((TextView)row.findViewById(R.id.second_row_lophoc)).setText(r.getTenHocPhan());
            return row;
        }
    }

    static class LopTC_Holder{
        private TextView first = null;
        private TextView second=null;
        LopTC_Holder(View row){
            first=(TextView)row.findViewById(R.id.first_row_lophoc);
            second=(TextView)row.findViewById(R.id.second_row_lophoc);
        }
        void populateForm(LopTC r){
            first.setText(r.getMaLopTC()+ " "+r.getMaHocPhan());
            second.setText(r.getTenHocPhan());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.class_giangvien);

        getLinkFromDomain gL = new getLinkFromDomain();
        urlgetData = gL.urlgetData_Class_GiangVien();


        final Intent intent = getIntent();
        int ms = intent.getIntExtra("MaUserFromMenu",0);
        urlgetData=urlgetData+ms;

        Log.e("MaUserFromMenu: ", String.valueOf(ms));

        getData(urlgetData);

        listView = (ListView)findViewById(R.id.listview_class_giangvien);
        LopTC_Adapter adapter = new LopTC_Adapter();
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o =listView.getItemAtPosition(position);
                LopTC lopTC1= (LopTC)o;
                Intent intent1=new Intent(Class_Giangvien.this,List_SV_Giangvien.class);
                intent1.putExtra("MaLopTC",lopTC1.getMaLopTC());
                startActivity(intent1);
            }
        });
    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {//lay du lieu
                                JSONObject object = response.getJSONObject(i);
                                arrayLopTC.add(new LopTC(
                                        object.getInt("MaLopTC"),
                                        object.getString("MaHocPhan"),
                                        object.getString("TenHocPhan"),
                                        0
                                ));

                                Log.e("array loptc",arrayLopTC.get(i).toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }


    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Đăng xuất?");
        builder.setMessage("Bạn có muốn đăng xuất");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Toast.makeText(Class_Giangvien.this,"sss",Toast.LENGTH_SHORT).show();
                Class_Giangvien.super.onBackPressed();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Class_Giangvien.super.onBackPressed();
            }
        });
        builder.show();
    }

}
