package com.example.qldsv.giang_vien;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.GiangVien;
import com.example.qldsv.sinhvien.Setting;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile_Giangvien extends Activity {

    String urlgetData; //file php chua trong htdoc cua xampp de ket noi voi sql server
    //GiangVien gv=new GiangVien();//(6,"GV01","CNNT","Phạm Hoài Lâm","13-11-1998","Nam",388482231) ;
    //GiangVien gv01 = new GiangVien();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_giangvien);
        getLinkFromDomain gL = new getLinkFromDomain();
        urlgetData = gL.urlgetData_Profile_GiangVien();

        Intent intent = getIntent();
        final int ms = intent.getIntExtra("MaUserFromMenu",0);
        urlgetData=urlgetData+ms;

        getData(urlgetData);

        final TextView textView=(TextView)findViewById(R.id.name_giangvien);

        LinearLayout linearLayout=(LinearLayout)findViewById(R.id.setting_ll_gv);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(Profile_Giangvien.this, Setting.class);
                Bundle bundle=new Bundle();
                bundle.putInt("MaUser",ms);
                bundle.putString("HoTen",textView.getText().toString());
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });


    }


    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu

        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                 GiangVien gv = new GiangVien(
                                        object.getInt("MaUser"),
                                        object.getString("MaGiangVien"),
                                        object.getString("MaVien"),
                                        object.getString("HoTen"),
                                        object.getString("NgaySinh"),
                                        object.getString("GioiTinh"),
                                        object.getInt("SoDienThoai")
                                );

                                Log.e("gv01",gv.toString());
                                TextView tv_Name = (TextView)findViewById(R.id.name_giangvien);
                                TextView tv_Birth = (TextView)findViewById(R.id.birth_giangvien);
                                TextView tv_MaGV = (TextView)findViewById(R.id.ma_giangvien);
                                TextView tv_Vien = (TextView)findViewById(R.id.vien_giangvien);
                                TextView tv_SDT = (TextView)findViewById(R.id.sdt_giangvien);
                                CircleImageView gender=(CircleImageView)findViewById(R.id.gender);

                                //gv=gv01;
                                tv_Name.setText(gv.getHoTen());
                                //tv_Name.setText("Phạm Hoài Lâm");
                                tv_MaGV.setText("Mã GV: "+gv.getMaGiangVien());
                                tv_Birth.setText("Ngày sinh: "+gv.getNgaySinh());
                                tv_SDT.setText("SDT: "+gv.getSoDienThoai());
                                tv_Vien.setText("Viện: "+gv.getMaVien());
                                if(gv.getGioiTinh().equals("Nam")) gender.setImageResource(R.drawable.male);
                                else gender.setImageResource(R.drawable.female);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(Login_Activity.this,"Lỗi không kết nối được server",Toast.LENGTH_SHORT).show();

                    }
                }
        );
        requestQueue.add(jsonArrayRequest);

    }


}
