package com.example.qldsv.sinhvien;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.Login_Activity;
import com.example.qldsv.control.getLinkFromDomain;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Setting extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);

        (this).getSupportActionBar().setTitle("Thay đổi mật khẩu");
        //Lam dep edit text
        EditText ed1=(EditText)findViewById(R.id.oldPassword);
        EditText ed2=(EditText)findViewById(R.id.newPassword);
        ed2.setBackgroundResource(R.drawable.lost_focus_border_style);
        ed1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    v.setBackgroundResource(R.drawable.focus_border_style);
                } else {
                    v.setBackgroundResource(R.drawable.lost_focus_border_style);
                }
            }
        });
        ed2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    v.setBackgroundResource(R.drawable.focus_border_style);
                } else {
                    v.setBackgroundResource(R.drawable.lost_focus_border_style);
                }
            }
        });

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();

        String hoten=bundle.getString("HoTen");
        final int MaUser=bundle.getInt("MaUser",0);
        Log.e("user+name: ",hoten+MaUser);

        TextView txt_name=(TextView)findViewById(R.id.name_setting);
        txt_name.setText(hoten);

        Button button=(Button)findViewById(R.id.save_setting);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText ed1=(EditText)findViewById(R.id.oldPassword);

                EditText ed2=(EditText)findViewById(R.id.newPassword);



                getLinkFromDomain gl=new getLinkFromDomain();
                String url=gl.urlupdate_Password(ed1.getText().toString(),ed2.getText().toString(),MaUser);

                updateData(url);
            }
        });



    }

    private void updateData(String url){
        RequestQueue queue = Volley.newRequestQueue(this);  // this = context
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        // display response
                        Log.d("Response", response.toString());
                        if(response.toString().equals("{\"code\":1,\"message\":\"update thanh cong\"}"))
                            Toast.makeText(Setting.this,"Thay đổi thành công!",Toast.LENGTH_SHORT).show();
                        else if(response.toString().equals("{\"code\":0,\"message\":\"sai pw\"}"))
                            Toast.makeText(Setting.this,"Sai mật khẩu cũ!",Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );

        // add it to the RequestQueue
        queue.add(getRequest);



    }
}


