package com.example.qldsv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

public class AdapterLopTC /*extends ArrayAdapter<LopTC>*/ {
    /*AdapterLopTC(){
        super(Class_Giangvien.this, android.R.layout.simple_list_item_1);
    }
    public View getView(int position, View convertView, ViewGroup parent){
        View row = convertView;
        if(row=null){
            LayoutInflater inflater=getLayoutInflater();
            row=inflater.inflate(R.layout.row_lophoc,null);
        }

    }*/

}
