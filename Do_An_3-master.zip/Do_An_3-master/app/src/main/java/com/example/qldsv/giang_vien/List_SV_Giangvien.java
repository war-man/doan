package com.example.qldsv.giang_vien;

import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.support.v7.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.admin.HocPhan_Activity;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.Diem;
import com.example.qldsv.model.LopTC;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class List_SV_Giangvien extends AppCompatActivity implements SearchView.OnQueryTextListener {

    ArrayList<Diem> arrayDiem= new ArrayList<>(); // luu tru cac lop tin chi phu trach
    String urlgetData;
    ListView listView;
    private SearchView mSearchView;
    private ListSV_GV_adapter adapter;
    //private Diem_Adapter adapter;

    /*class Diem_Adapter extends ArrayAdapter<Diem> {
        Diem_Adapter() {
            super(List_SV_Giangvien.this,
                    android.R.layout.simple_list_item_1,
                    arrayDiem);
        }

        public View getView(int position, View convertView, ViewGroup parent){
            View row=convertView;
            Diem_Holder holder=null;
            if(row==null){
                LayoutInflater inflater=getLayoutInflater();

                row=inflater.inflate(R.layout.row_diem, null);
                holder=new Diem_Holder(row);
                row.setTag(holder);
            }
            Diem r=arrayDiem.get(position);
            ((TextView)row.findViewById(R.id.row_diem_mssv)).setText(String.valueOf(r.getMSSV()));
            ((TextView)row.findViewById(R.id.row_diem_hoten)).setText(r.getHoTenSV());
            ((TextView)row.findViewById(R.id.row_diem_gk)).setText(String.valueOf(r.getDiemGiuaKy()));
            ((TextView)row.findViewById(R.id.row_diem_ck)).setText(String.valueOf(r.getDiemCuoiKy()));
            ((TextView)row.findViewById(R.id.row_diem_chu)).setText(r.getDiemChu());
            return row;
        }
    }

    static class Diem_Holder{
        private TextView tv1 = null;
        private TextView tv2=null;
        private TextView tv3=null;
        private TextView tv4=null;
        private TextView tv5=null;

        Diem_Holder(View row){
            tv1=(TextView)row.findViewById(R.id.row_diem_mssv);
            tv2=(TextView)row.findViewById(R.id.row_diem_hoten);
            tv3=(TextView)row.findViewById(R.id.row_diem_gk);
            tv4=(TextView)row.findViewById(R.id.row_diem_ck);
            tv5=(TextView)row.findViewById(R.id.row_diem_chu);
        }
        void populateForm(Diem r){
            tv1.setText(r.getMSSV());
            tv2.setText(r.getHoTenSV());
            tv3.setText(String.valueOf(r.getDiemGiuaKy()));
            tv4.setText(String.valueOf(r.getDiemCuoiKy()));
            tv5.setText(r.getDiemChu());

        }
    }*/



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_sinhvien);



        Intent intent=getIntent();
        int maloptc=intent.getIntExtra("MaLopTC",0);
        (this).getSupportActionBar().setTitle(String.valueOf(maloptc));

        Log.e("MaLopTc",String.valueOf(maloptc));

        getLinkFromDomain gL=new getLinkFromDomain();
        urlgetData=gL.urlgetData_Diem(String.valueOf(maloptc));
        getData(urlgetData);

        listView=(ListView)findViewById(R.id.listview_danhsach_sinhvien);
        adapter=new ListSV_GV_adapter(List_SV_Giangvien.this,arrayDiem);
        //adapter=new Diem_Adapter();
        listView.setAdapter(adapter);
        listView.setTextFilterEnabled(false);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o=listView.getItemAtPosition(position);
                Diem diem =(Diem)o;
                Intent intent1=new Intent(List_SV_Giangvien.this,QuanLyDiem_GiangVien.class);
                Bundle bundle = new Bundle();
                bundle.putInt("MSSV",diem.getMSSV());
                bundle.putInt("MaLopTC",diem.getMaLopTC());
                bundle.putInt("HocKy",diem.getHocKy());
                bundle.putDouble("DiemGiuaKy",diem.getDiemGiuaKy());
                bundle.putDouble("DiemCuoiKy",diem.getDiemCuoiKy());
                bundle.putString("DiemChu",diem.getDiemChu());
                bundle.putString("HoTenSV",diem.getHoTenSV());
                bundle.putString("HeSo",diem.getHeSo());
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//tao menu tren thanh bar
        getMenuInflater().inflate(R.menu.menu_actions4, menu);
        MenuItem itemSearch=menu.findItem(R.id.search4);

        mSearchView = (SearchView) itemSearch.getActionView();
        mSearchView.setQueryHint("Tìm kiếm");
        mSearchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String arg0) {

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText){//thuc hien tim kiem
        if(TextUtils.isEmpty(newText)){
            adapter.getFilter().filter("");
            listView.clearTextFilter();
        }else {//va do du lieu ra listview
            listView.setFilterText(newText);
            adapter.getFilter().filter(newText);

        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search4:

                return true;
            case R.id.list_all://tat ca
                listView.setAdapter(adapter);
                return true;
            case R.id.list_f://danh sach sinh vien tach mon
                ArrayList<Diem> arrayDiemF= new ArrayList<>();
                ListSV_GV_adapter adapte2r=new ListSV_GV_adapter(List_SV_Giangvien.this,arrayDiemF);

                for(int i=0;i<arrayDiem.size();i++){
                    if(arrayDiem.get(i).getDiemChu().equals("F")) arrayDiemF.add(arrayDiem.get(i));
                }
                listView.setAdapter(adapte2r);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                arrayDiem.add(new Diem(
                                        object.getInt("MSSV"),
                                        object.getInt("MaLopTC"),
                                        object.getInt("HocKy"),
                                        object.getDouble("DiemGiuaKy"),
                                        object.getDouble("DiemCuoiKy"),
                                        object.getString("DiemChu"),
                                        object.getString("HeSo"),
                                        object.getString("HoTen")
                                ));

                                Log.e("array diem",String.valueOf(arrayDiem.get(i).getMaLopTC()));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }


}