package com.example.qldsv.sinhvien;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.util.Log;
import android.view.MenuItem;

import android.view.View;
import android.widget.TabHost;

import com.example.qldsv.R;
import com.example.qldsv.giang_vien.Class_Giangvien;
import com.example.qldsv.giang_vien.Notification;
import com.example.qldsv.giang_vien.Profile_Giangvien;
import com.example.qldsv.giang_vien.Statistic_Giangvien;

public class Menu_Sinhvien extends TabActivity {
    /*private DrawerLayout mDrawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_sinhvien);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.mipmap.menu_ic);

        mDrawerLayout = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        // set item as selected to persist highlight
                        menuItem.setChecked(true);
                        // close drawer when item is tapped
                        mDrawerLayout.closeDrawers();

                        // Add code here to update the UI based on the item selected
                        // For example, swap UI fragments here

                        return true;
                    }
                });



        mDrawerLayout.addDrawerListener(
                new DrawerLayout.DrawerListener() {
                    @Override
                    public void onDrawerSlide(View drawerView, float slideOffset) {
                        // Respond when the drawer's position changes
                    }

                    @Override
                    public void onDrawerOpened(View drawerView) {
                        // Respond when the drawer is opened
                    }

                    @Override
                    public void onDrawerClosed(View drawerView) {
                        // Respond when the drawer is closed
                    }

                    @Override
                    public void onDrawerStateChanged(int newState) {
                        // Respond when the drawer motion state changes
                    }
                }
        );










    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }*/

    public static final String MaUserFromMenu="MaUserFromMenu";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_giangvien);

        TabHost tabHost=(TabHost)findViewById(android.R.id.tabhost);
        TabHost.TabSpec spec;
        Intent intent=getIntent() ;
        int Ma_user= intent.getIntExtra("MaUser",0);
        Log.e("MaU_1:   ", String.valueOf(Ma_user));

        spec=tabHost.newTabSpec("class");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.logo_class));
        intent = new Intent(this, Diem_Sinhvien.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);

        spec=tabHost.newTabSpec("statistic");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.logo_char));
        intent = new Intent(this, Tab_Statistic_SinhVien.class);
        spec.setContent(intent);
        tabHost.addTab(spec);

        /*spec=tabHost.newTabSpec("notification");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.notice));
        intent = new Intent(this, Notification.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);*/




        spec=tabHost.newTabSpec("profile");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.ic_launcher_account));
        intent = new Intent(this, Profile_Sinhvien.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);

        tabHost.setCurrentTab(0);
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {

            }
        });






    }
}
