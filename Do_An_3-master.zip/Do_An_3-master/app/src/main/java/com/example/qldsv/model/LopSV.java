package com.example.qldsv.model;

public class LopSV {
    private String MaLopSV;
    private String TenLop;
    private String MaVien;

    public LopSV() {
    }

    public LopSV(String maLopSV, String tenLop, String maVien) {
        MaLopSV = maLopSV;
        TenLop = tenLop;
        MaVien = maVien;
    }

    public String getMaLopSV() {
        return MaLopSV;
    }

    public void setMaLopSV(String maLopSV) {
        MaLopSV = maLopSV;
    }

    public String getTenLop() {
        return TenLop;
    }

    public void setTenLop(String tenLop) {
        TenLop = tenLop;
    }

    public String getMaVien() {
        return MaVien;
    }

    public void setMaVien(String maVien) {
        MaVien = maVien;
    }
}
