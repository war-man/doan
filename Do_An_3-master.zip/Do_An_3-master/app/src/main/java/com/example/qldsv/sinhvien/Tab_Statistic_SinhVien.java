package com.example.qldsv.sinhvien;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TabHost;

import com.example.qldsv.R;
import com.example.qldsv.giang_vien.Statistic_Giangvien;

public class Tab_Statistic_SinhVien extends TabActivity {

    public static final String MaUserFromMenu="MaUserFromMenu";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.menu_tab);

        TabHost tabHost=(TabHost)findViewById(android.R.id.tabhost);
        TabHost.TabSpec spec;
        Intent intent=getIntent() ;
        int Ma_user= intent.getIntExtra("MaUser",0);
        Log.e("MaU_s_e_R:   ", String.valueOf(Ma_user));

        spec=tabHost.newTabSpec("so_luong_diem");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.diemchart_logo));
        intent = new Intent(this, Pie_chart.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);


        spec=tabHost.newTabSpec("cpa_gpa");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.cpa_logo));
        intent = new Intent(this, Line_Chart.class);
        spec.setContent(intent);
        tabHost.addTab(spec);



        tabHost.setCurrentTab(0);
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {

            }
        });


    }
}
