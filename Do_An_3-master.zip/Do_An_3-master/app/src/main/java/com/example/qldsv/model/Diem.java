package com.example.qldsv.model;

public class Diem {

    private int MSSV;
    private int MaLopTC;
    private int HocKy;
    private double DiemGiuaKy;
    private double DiemCuoiKy;
    private String DiemChu;
    private String HeSo;

    public int getMSSV() {
        return MSSV;
    }

    public void setMSSV(int MSSV) {
        this.MSSV = MSSV;
    }

    public int getMaLopTC() {
        return MaLopTC;
    }

    public void setMaLopTC(int maLopTC) {
        MaLopTC = maLopTC;
    }

    public int getHocKy() {
        return HocKy;
    }

    public void setHocKy(int hocKy) {
        HocKy = hocKy;
    }

    public double getDiemGiuaKy() {
        return DiemGiuaKy;
    }

    public void setDiemGiuaKy(double diemGiuaKy) {
        DiemGiuaKy = diemGiuaKy;
    }

    public double getDiemCuoiKy() {
        return DiemCuoiKy;
    }

    public void setDiemCuoiKy(double diemCuoiKy) {
        DiemCuoiKy = diemCuoiKy;
    }

    public String getDiemChu() {
        return DiemChu;
    }

    public void setDiemChu(String diemChu) {
        DiemChu = diemChu;
    }

    public String getHeSo() {
        return HeSo;
    }

    public void setHeSo(String heSo) {
        HeSo = heSo;
    }

    public String getHoTenSV() {
        return HoTenSV;
    }

    public void setHoTenSV(String hoTenSV) {
        HoTenSV = hoTenSV;
    }

    public Diem() {
    }

    public Diem(int MSSV, int maLopTC, int hocKy, double diemGiuaKy, double diemCuoiKy, String diemChu, String heSo, String hoTenSV) {
        this.MSSV = MSSV;
        MaLopTC = maLopTC;
        HocKy = hocKy;
        DiemGiuaKy = diemGiuaKy;
        DiemCuoiKy = diemCuoiKy;
        DiemChu = diemChu;
        HeSo = heSo;
        HoTenSV = hoTenSV;
    }

    private String HoTenSV;

}
