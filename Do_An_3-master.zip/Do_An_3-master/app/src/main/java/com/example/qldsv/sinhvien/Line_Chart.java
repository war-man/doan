package com.example.qldsv.sinhvien;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.example.qldsv.R;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import static org.achartengine.ChartFactory.getLineChartIntent;

public class Line_Chart extends Activity {
    private String[] mTerm=new String[]{"20161","20162","20171","20172","20181","20182","20191","20192"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.line_chart);
        openChart();


    }



    private void openChart(){
        int[] x = { 1,2,3,4,5,6,7,8 };//set cac vi tri
        float[] income = {4,3.5f,3.4f,3.9f,2.8f,3.5f,3.7f,1.8f};
        float[] expense = {2,3.7f,3.8f,3.0f,3.8f,3.54f,2.7f,2.8f};

        //  XYSeries cho CPA
        XYSeries incomeSeries = new XYSeries("CPA");
        // XYSeries cho GPA
        XYSeries expenseSeries = new XYSeries("GPA");
        // Them date cho CPA va GPA
        for(int i=0;i<x.length;i++){
            incomeSeries.add(x[i], income[i]);
            expenseSeries.add(x[i],expense[i]);
        }

        // Creating a dataset to hold each series
        XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
        // Adding Income Series to the dataset
        dataset.addSeries(incomeSeries);
        // Adding Expense Series to dataset
        dataset.addSeries(expenseSeries);

        // Creating XYSeriesRenderer to customize incomeSeries
        XYSeriesRenderer incomeRenderer = new XYSeriesRenderer();
        incomeRenderer.setColor(Color.GREEN);
        incomeRenderer.setPointStyle(PointStyle.CIRCLE);
        incomeRenderer.setFillPoints(true);
        incomeRenderer.setLineWidth(10);
        incomeRenderer.setDisplayChartValues(true);

        // Creating XYSeriesRenderer to customize expenseSeries
        XYSeriesRenderer expenseRenderer = new XYSeriesRenderer();
        expenseRenderer.setColor(Color.BLUE);
        expenseRenderer.setPointStyle(PointStyle.CIRCLE);
        expenseRenderer.setFillPoints(true);
        expenseRenderer.setLineWidth(10);
        expenseRenderer.setDisplayChartValues(true);

        // Creating a XYMultipleSeriesRenderer to customize the whole chart
        XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
        multiRenderer.setXLabels(0);

        multiRenderer.setLabelsTextSize(50);
        multiRenderer.setLabelsColor(Color.RED);

        //sua cac thuoc tinh trong bieu do
        multiRenderer.setZoomButtonsVisible(false);
        multiRenderer.setPanEnabled(true);
        multiRenderer.setLegendHeight(100);

        multiRenderer.setXLabelsColor(Color.RED);
        multiRenderer.setYLabelsPadding(10);
        multiRenderer.setXLabelsAlign(Paint.Align.CENTER);
        multiRenderer.setGridColor(Color.BLUE);
        multiRenderer.setLegendTextSize(60);
        multiRenderer.setFitLegend(false);
        multiRenderer.setBackgroundColor(Color.alpha(0));

        for(int i=0;i<x.length;i++){
            multiRenderer.addXTextLabel(i+1, mTerm[i]);
        }

        // Adding incomeRenderer and expenseRenderer to multipleRenderer
        // Note: The order of adding dataseries to dataset and renderers to multipleRenderer
        // should be same
        multiRenderer.addSeriesRenderer(incomeRenderer);
        multiRenderer.addSeriesRenderer(expenseRenderer);

        // Creating an intent to plot line chart using dataset and multipleRenderer

        LinearLayout pieGraph=(LinearLayout)findViewById(R.id.linechart);
        GraphicalView graphicalView=ChartFactory.getLineChartView(getBaseContext(), dataset, multiRenderer);
        pieGraph.addView(graphicalView);

    }
}
