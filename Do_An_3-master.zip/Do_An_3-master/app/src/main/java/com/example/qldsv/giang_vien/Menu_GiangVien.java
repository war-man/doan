package com.example.qldsv.giang_vien;

import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TabHost;

import com.example.qldsv.R;

public class Menu_GiangVien extends TabActivity {
    public static final String MaUserFromMenu="MaUserFromMenu";

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.menu_giangvien);


        TabHost tabHost=(TabHost)findViewById(android.R.id.tabhost);
        TabHost.TabSpec spec;
        Intent intent=getIntent() ;
        int Ma_user= intent.getIntExtra("MaUser",0);
        Log.e("MaU_1:   ", String.valueOf(Ma_user));

        spec=tabHost.newTabSpec("class");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.logo_class));
        intent = new Intent(this, Class_Giangvien.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);

        /*spec=tabHost.newTabSpec("statistic");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.logo_char));

        intent = new Intent(this, Statistic_Giangvien.class);

        spec.setContent(intent);
        tabHost.addTab(spec);*/

        /*spec=tabHost.newTabSpec("notification");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.notice));
        intent = new Intent(this, Notification.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);*/




        spec=tabHost.newTabSpec("profile");
        spec.setIndicator(null,getResources().getDrawable(R.mipmap.ic_launcher_account));
        intent = new Intent(this, Profile_Giangvien.class);
        intent.putExtra(MaUserFromMenu,Ma_user);
        spec.setContent(intent);
        tabHost.addTab(spec);

        tabHost.setCurrentTab(0);
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {

            }
        });






    }


}
