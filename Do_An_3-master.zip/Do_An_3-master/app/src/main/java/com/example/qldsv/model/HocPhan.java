package com.example.qldsv.model;

public class HocPhan {
    private String MaHocPhan;
    private String TenHocPhan;
    private String MaVien;
    private String HeSo;
    private int TinChi;

    public HocPhan(String maHocPhan, String tenHocPhan, String maVien, String heSo, int tinChi) {
        MaHocPhan = maHocPhan;
        TenHocPhan = tenHocPhan;
        MaVien = maVien;
        HeSo = heSo;
        TinChi = tinChi;
    }

    public HocPhan() {
    }

    public String getMaHocPhan() {
        return MaHocPhan;
    }

    public void setMaHocPhan(String maHocPhan) {
        MaHocPhan = maHocPhan;
    }

    public String getTenHocPhan() {
        return TenHocPhan;
    }

    public void setTenHocPhan(String tenHocPhan) {
        TenHocPhan = tenHocPhan;
    }

    public String getMaVien() {
        return MaVien;
    }

    public void setMaVien(String maVien) {
        MaVien = maVien;
    }

    public String getHeSo() {
        return HeSo;
    }

    public void setHeSo(String heSo) {
        HeSo = heSo;
    }

    public int getTinChi() {
        return TinChi;
    }

    public void setTinChi(int tinChi) {
        TinChi = tinChi;
    }

    public String toString(){
        return "maHocPhan: "+ MaHocPhan+", tenHocPhan: "+ TenHocPhan+", maVien: "+ MaVien+", heso: " +HeSo+ ", tc: " +TinChi;
    }
}
