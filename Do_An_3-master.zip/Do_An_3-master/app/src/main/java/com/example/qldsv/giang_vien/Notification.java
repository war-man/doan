package com.example.qldsv.giang_vien;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.LopTC;
import com.example.qldsv.model.Thongbao;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Notification extends Activity {

    ArrayList<Thongbao> arrayLopTC = new ArrayList<>(); // luu tru cac lop tin chi phu trach
    String urlgetData;
    ListView listView;


    class LopTC_Adapter extends ArrayAdapter<Thongbao> {
        LopTC_Adapter() {
            super(Notification.this,
                    android.R.layout.simple_list_item_1,
                    arrayLopTC);
        }

        public View getView(int position, View convertView, ViewGroup parent){
            View row=convertView;
            LopTC_Holder holder=null;
            if(row==null){
                LayoutInflater inflater=getLayoutInflater();

                row=inflater.inflate(R.layout.row_thongbao, null);
                holder=new LopTC_Holder(row);
                row.setTag(holder);
            }
            Thongbao r=arrayLopTC.get(position);
            ((TextView)row.findViewById(R.id.first_row_thongbao)).setText(r.getHoTenSV()+ " - "+r.getMSSV()+"  "+String.valueOf(r.getMaLopTC()));
            ((TextView)row.findViewById(R.id.second_row_thongbao)).setText(r.getNoiDung());
            return row;
        }
    }

    static class LopTC_Holder{
        private TextView first = null;
        private TextView second=null;
        LopTC_Holder(View row){
            first=(TextView)row.findViewById(R.id.first_row_thongbao);
            second=(TextView)row.findViewById(R.id.second_row_thongbao);
        }
        void populateForm(Thongbao r){
            first.setText(String.valueOf(r.getMaLopTC()));
            second.setText(r.getHoTenSV()+ " - "+r.getMSSV()+":"+r.getNoiDung());
        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);
        getLinkFromDomain gL = new getLinkFromDomain();
        Intent intent = getIntent();
        int o_o=intent.getIntExtra("MaUserFromMenu",0);
        urlgetData = gL.urlgetData_Thongbao(String.valueOf(o_o));



        getData(urlgetData);
        arrayLopTC.add(new Thongbao(0,0,"s",2,"d",3,4));

        listView = (ListView)findViewById(R.id.listview_notice);
        LopTC_Adapter adapter = new LopTC_Adapter();
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o =listView.getItemAtPosition(position);
                Thongbao ___= (Thongbao) o;
                Intent intent1=new Intent(Notification.this,QuanLyDiem_GiangVien.class);
                intent1.putExtra("MaLopTC",___.getMaLopTC());
                intent1.putExtra("MSSV",___.getMSSV());
                intent1.putExtra("DiemGiuaKy",___.getDiemGiuaKy());
                intent1.putExtra("DiemCuoiKy",___.getDiemCuoiKy());
                intent1.putExtra("HoTenSV",___.getHoTenSV());
                startActivity(intent1);
            }
        });

    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);

                                arrayLopTC.add(new Thongbao(
                                        object.getInt("MaThongBao"),
                                        object.getInt("MSSV"),
                                        object.getString("HoTen"),
                                        object.getInt("MaLopTC"),
                                        object.getString("NoiDung"),
                                        object.getDouble("DiemGiuaKy"),
                                        object.getDouble("DiemCuoiKy")
                                ));
                                Log.e("array thongbao",arrayLopTC.get(i).toString());


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }

}
