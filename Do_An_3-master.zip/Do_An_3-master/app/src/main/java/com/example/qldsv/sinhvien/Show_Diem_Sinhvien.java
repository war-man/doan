package com.example.qldsv.sinhvien;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.qldsv.R;

public class Show_Diem_Sinhvien extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_diem_sv);
        Intent intent = getIntent();
        Bundle bundle=intent.getExtras();
        int mssv=bundle.getInt("MSSV",0);
        (this).getSupportActionBar().setTitle(String.valueOf(mssv));

        int hocky = bundle.getInt("HocKy",0);
        TextView t1 = (TextView)findViewById(R.id.show_diem_sv_hk);
        t1.setText(String.valueOf(hocky));

        int loptc = bundle.getInt("MaLopTC",0);
        TextView x = (TextView)findViewById(R.id.show_diem_sv_loptc);
        x.setText(String.valueOf(loptc));

        String MaHocPhan=bundle.getString("MaHocPhan");
        String TenHocPhan=bundle.getString("TenHocPhan");
        TextView t2=(TextView)findViewById(R.id.show_diem_dv_hocphan);
        t2.setText(MaHocPhan+":");
        TextView tt=(TextView)findViewById(R.id.show_diem_dv_tenhp);
        tt.setText(TenHocPhan);

        double dgk = bundle.getDouble("DiemGiuaKy",0);
        TextView t3 = (TextView)findViewById(R.id.show_diem_dv_dgk);
        t3.setText(String.valueOf(dgk));

        double dck = bundle.getDouble("DiemCuoiKy",0);
        TextView t4 = (TextView)findViewById(R.id.show_diem_dv_dck);
        t4.setText(String.valueOf(dck));

        String dc = bundle.getString("DiemChu");
        TextView t5 = (TextView)findViewById(R.id.show_diem_dv_dc);
        t5.setText(dc);

        Button button=(Button)findViewById(R.id.button_ok);
        button.setOnClickListener(on_ok);

    }

    private View.OnClickListener on_ok = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }

    };
}
