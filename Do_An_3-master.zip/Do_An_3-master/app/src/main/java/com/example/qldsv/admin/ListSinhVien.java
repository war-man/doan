package com.example.qldsv.admin;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;

import com.example.qldsv.control.Login_Activity;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.LopSV;
import com.example.qldsv.model.LopTC;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListSinhVien extends AppCompatActivity implements SearchView.OnQueryTextListener{

    ArrayList<LopSV> arrayLopSV = new ArrayList<>(); // luu tru cac lop tin chi phu trach
    String urlgetData;
    ListView listView;
    Adapter adapter;



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actions2, menu);
        MenuItem itemSearch=menu.findItem(R.id.search2);
        SearchView mSearchView = (SearchView) itemSearch.getActionView();
        mSearchView.setQueryHint("Tìm kiếm");
        mSearchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if(TextUtils.isEmpty(newText)){
            adapter.getFilter().filter("");
            listView.clearTextFilter();
        }else {
            listView.setFilterText(newText);
            if(adapter!=null)
            adapter.getFilter().filter(newText);

        }
        return true;
    }




@Override
    protected void onCreate(Bundle saveInstanceState){
    super.onCreate(saveInstanceState);
    setContentView(R.layout.admin_danhsach_lopsv);

    (this).getSupportActionBar().setTitle(R.string.ListSinhVien);

    getLinkFromDomain gL = new getLinkFromDomain();
    urlgetData = gL.urlgetData_LopSV();
    Log.e("url: ",urlgetData);


    getData(urlgetData);

    listView = (ListView)findViewById(R.id.listview_admin_list_lopsv);
    Adapter adapter = new Adapter( ListSinhVien.this,arrayLopSV);
    listView.setAdapter(adapter);

    //ListView lv = (ListView)findViewById(R.id.);
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Object o =listView.getItemAtPosition(position);
            LopSV lopSV= (LopSV)o;
            Intent intent1=new Intent(ListSinhVien.this,ListSV_LopSV.class);
            intent1.putExtra("MaLopSV",lopSV.getMaLopSV());
            startActivity(intent1);
        }
    });

    }

    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                arrayLopSV.add( new LopSV(object.getString("MaLopSV"),
                                                            object.getString("Tenlop"),
                                                            object.getString("TenVien")
                                        )
                                );

                                Log.e("array lopsv",arrayLopSV.get(i).toString());
                                //Toast.makeText(ListSinhVien.this,"Lỗi không kết nối được server",Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }

}
