package com.example.qldsv.model;

import android.widget.Toast;

public class User {
    private  int MaUser;
    private String User;
    private String Password;
    private int Chucvu;

    public User() {
    }

    public User(int maUser, String user, String password, int chucvu) {
        MaUser = maUser;
        User = user;
        Password = password;
        Chucvu = chucvu;
    }

    public int getMaUser() {
        return MaUser;
    }

    public void setMaUser(int maUser) {
        MaUser = maUser;
    }

    public String getUser() {
        return User;
    }

    public void setUser(String user) {
        User = user;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public int getChucvu() {
        return Chucvu;
    }

    public void setChucvu(int chucvu) {
        Chucvu = chucvu;
    }

    public String toString(){
        String s = "Ma User: " + MaUser + "User: " + User + "Password: " + Password + "Chuc vu: " + Chucvu;
        return s;
    }
}
