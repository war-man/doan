package com.example.qldsv.model;

public class LopTC {
    private int MaLopTC;
    private String MaHocPhan;
    private String TenHocPhan;
    private int SoLuongSV;

    public int getMaLopTC() {
        return MaLopTC;
    }

    public void setMaLopTC(int maLopTC) {
        MaLopTC = maLopTC;
    }

    public String getMaHocPhan() {
        return MaHocPhan;
    }

    public void setMaHocPhan(String maHocPhan) {
        MaHocPhan = maHocPhan;
    }

    public String getTenHocPhan() {
        return TenHocPhan;
    }

    public void setTenHocPhan(String tenHocPhan) {
        TenHocPhan = tenHocPhan;
    }

    public int getSoLuongSV() {
        return SoLuongSV;
    }

    public void setSoLuongSV(int soLuongSV) {
        SoLuongSV = soLuongSV;
    }

    public LopTC() {
    }

    public LopTC(int maLopTC, String maHocPhan, String tenHocPhan, int soLuongSV) {
        MaLopTC = maLopTC;
        MaHocPhan = maHocPhan;
        TenHocPhan = tenHocPhan;
        SoLuongSV = soLuongSV;
    }

    public String toString(){
        return "MaLopTC: "+MaLopTC+", MaHocPhan: "+MaHocPhan;
    }
}
