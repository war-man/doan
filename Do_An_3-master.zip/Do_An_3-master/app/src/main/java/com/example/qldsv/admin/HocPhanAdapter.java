package com.example.qldsv.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.qldsv.R;
import com.example.qldsv.model.HocPhan;

import java.util.ArrayList;

public class HocPhanAdapter extends BaseAdapter implements Filterable {
    public Context context;
    public ArrayList<HocPhan> HocPhanArray;
    public ArrayList<HocPhan> orig;

    public HocPhanAdapter(Context context, ArrayList<HocPhan> hocPhanArray) {
        this.context = context;
        HocPhanArray = hocPhanArray;
    }

    public class Holder{
        private TextView first = null;
        private TextView second=null;
    }

    @Override
    public int getCount() {
        return HocPhanArray.size();
    }

    @Override
    public Object getItem(int position) {
        return HocPhanArray.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if(convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.row_hocphan,parent,false);
            holder=new Holder();
            holder.first=(TextView)convertView.findViewById(R.id.first_row_hocphan);
            holder.second=(TextView)convertView.findViewById(R.id.second_row_hocphan);
            convertView.setTag(holder);
        }
        else {
            holder=(Holder) convertView.getTag();
        }
        holder.first.setText(HocPhanArray.get(position).getMaHocPhan()+ " "+HocPhanArray.get(position).getTenHocPhan());
        holder.second.setText(HocPhanArray.get(position).getMaVien());
        return convertView;
    }

    @Override
    public Filter getFilter() {



        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                final FilterResults oReturn=new FilterResults();
                final ArrayList<HocPhan> result=new ArrayList<HocPhan>();
                if(orig==null) orig=HocPhanArray;
                if(constraint!=null){
                    if(orig!=null && orig.size()>0){
                        for(final HocPhan g : orig){
                            if(g.getMaVien().toLowerCase().contains(constraint.toString())||String.valueOf(g.getTenHocPhan()).contains(constraint.toString())||String.valueOf(g.getMaHocPhan()).contains(constraint.toString()))
                                result.add(g);
                        }
                    }
                    oReturn.values=result;
                }

                return oReturn;

            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                HocPhanArray=(ArrayList<HocPhan>)results.values;
                notifyDataSetChanged();
            }
        };
    }
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
