package com.example.qldsv.giang_vien;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.control.pieChart;
import com.example.qldsv.model.Count_Diem;
import com.example.qldsv.model.Diem;
import com.example.qldsv.model.LopTC;

import org.achartengine.GraphicalView;
import org.achartengine.chart.PieChart;
import org.achartengine.renderer.DefaultRenderer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Statistic_Giangvien extends Activity {
    final ArrayList<Count_Diem> arrayDiem = new ArrayList<>();
    int dAp=0,dA=0,dBp=0,dB=0,dCp=0,dC=0,dDp=0,dD=0,dF=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistic_giangvien);

        getLinkFromDomain gl=new getLinkFromDomain();
        String url=gl.urlgetData_Count_Diem("20166339");
        Log.wtf("url-count",url);


        getData(url);

        Log.d("test", "onCreate: ");
    }


    private void getData(String url) {
        //Ham ket noi voi DB de lay du lieu

        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                     for(int i=0;i<response.length();i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                 Count_Diem cc=new Count_Diem(object.getString("Diem"), object.getInt("SoLuong"));
                                Log.wtf("arr564433 ", cc.getDiem() + " " + cc.getSoLuong());





                                switch (cc.getDiem()){
                                    case "A+":{
                                        dAp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dAp));
                                        break;
                                    }
                                    case "A":{
                                        dA=cc.getSoLuong(); Log.wtf("arr56 ", String.valueOf(dA));
                                        break;
                                    }
                                    case "B+":{
                                        dBp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dBp));
                                        break;
                                    }
                                    case "B":{
                                        dB=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dB));
                                        break;
                                    }
                                    case "C+":{
                                        dCp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dCp));
                                        break;
                                    }
                                    case "C":{
                                        dC=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dC));
                                        break;
                                    }
                                    case "D+":{
                                        dDp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dDp));
                                        break;
                                    }
                                    case "D":{
                                        dD=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dD));
                                        break;
                                    }
                                    case "F":{
                                        dF=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dF));
                                        break;
                                    }
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                     }


                        pieChart pie=new pieChart();
                        GraphicalView graphicalView=pie.getraphicalView(Statistic_Giangvien.this,dAp,dA,dBp,dB,dCp,dC,dDp,dD,dF);
                        LinearLayout pieGraph=(LinearLayout)findViewById(R.id.piechart);
                        pieGraph.addView(graphicalView);




                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }
}