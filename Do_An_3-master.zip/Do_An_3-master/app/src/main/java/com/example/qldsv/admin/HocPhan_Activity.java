package com.example.qldsv.admin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;

import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.HocPhan;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HocPhan_Activity extends AppCompatActivity implements SearchView.OnQueryTextListener{


    ArrayList<HocPhan> arrayHocPhan = new ArrayList<>(); // luu tru cac lop tin chi phu trach
    ArrayList<HocPhan> arrayList_CK=new ArrayList<>();
    ArrayList<HocPhan> arrayList_CNTT=new ArrayList<>();
    String urlgetData;
    ListView listView;
    HocPhanAdapter adapter;
    HocPhanAdapter adapter1;
    HocPhanAdapter adapter2;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_danhsach_hocphan);

        (this).getSupportActionBar().setTitle(R.string.HocPhan_Activity);

        getLinkFromDomain gL = new getLinkFromDomain();
        urlgetData=gL.urlgetData_HocPhan_Admin("all");
        getData(urlgetData);

        listView = (ListView)findViewById(R.id.listview_admin_list_hocphan);

        adapter = new HocPhanAdapter(HocPhan_Activity.this,arrayHocPhan);
        listView.setAdapter(adapter);

        adapter1=new HocPhanAdapter(HocPhan_Activity.this,arrayList_CNTT);

        adapter2=new HocPhanAdapter(HocPhan_Activity.this,arrayList_CK);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o =listView.getItemAtPosition(position);
                HocPhan hocPhan =(HocPhan)o;

                Intent intent = new Intent( HocPhan_Activity.this,HocPhan_QuanLy.class);

                Bundle bundle = new Bundle();
                bundle.putString("MaHocPhan",hocPhan.getMaHocPhan());
                bundle.putString("TenHocPhan",hocPhan.getTenHocPhan());
                bundle.putString("TenVien",hocPhan.getMaVien());
                bundle.putString("HeSo",hocPhan.getHeSo());
                bundle.putInt("TinChi",hocPhan.getTinChi());
                intent.putExtras(bundle);

                startActivity(intent);
                //Toast.makeText(HocPhan_Activity.this, "Selected :"+hocPhan.toString(), Toast.LENGTH_LONG).show();
            }
        });




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actions, menu);
        MenuItem itemSearch=menu.findItem(R.id.search);
        SearchView mSearchView = (SearchView) itemSearch.getActionView();
        mSearchView.setQueryHint("Tìm kiếm");
        mSearchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add:
                Intent intent=new Intent(HocPhan_Activity.this,HocPhan_QuanLy.class);


                Bundle bundle = new Bundle();
                bundle.putString("MaHocPhan","");
                bundle.putString("TenHocPhan","");
                bundle.putString("TenVien","CNTT và TT");
                bundle.putString("HeSo","5-5");
                bundle.putInt("TinChi",2);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.search:
                Toast.makeText(this, "Search button selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.all:
                Toast.makeText(this, "Tất cả", Toast.LENGTH_SHORT).show();
                listView.setAdapter(adapter);
                return true;
            case R.id.vien_CNTT:
                Toast.makeText(this, "Danh sách học phần viện CNTT&TT", Toast.LENGTH_SHORT).show();
                listView.setAdapter(adapter1);
                return true;
            case R.id.vien_cokhi:
                Toast.makeText(this, "Danh sách học phần viện Cơ Khí", Toast.LENGTH_SHORT).show();

                listView.setAdapter(adapter2);
                return true;
            default: listView.setAdapter(null);
        }

        return super.onOptionsItemSelected(item);
    }




    private void getData(String url){
        //Ham ket noi voi DB de lay du lieu
        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++){
                            try {
                                JSONObject object = response.getJSONObject(i);
                                HocPhan hocPhan=new HocPhan(
                                        object.getString("MaHocPhan"),
                                        object.getString("TenHocPhan"),
                                        object.getString("TenVien"),
                                        object.getString("HeSo"),
                                        object.getInt("TinChi"));

                                arrayHocPhan.add(hocPhan);
                                if(object.getString("TenVien").equals("CNTT và TT")){
                                    arrayList_CNTT.add(hocPhan);
                                }else if(object.getString("TenVien").equals("Cơ Khí")){
                                    arrayList_CK.add(hocPhan);
                                }

                                Log.e("array hocphan",arrayHocPhan.get(i).toString());

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }


    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if(TextUtils.isEmpty(newText)){
            adapter.getFilter().filter("");
            listView.clearTextFilter();
        }else {
            listView.setFilterText(newText);
            adapter.getFilter().filter(newText);

        }
        return true;
    }
}