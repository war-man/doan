package com.example.qldsv.control;

import java.io.Serializable;

public class getLinkFromDomain {
    public getLinkFromDomain() {
    }

    String lh="http://10.10.96.62/androidserver/";
    public String urlgetData_Login(){
        String s = lh + "result.php";
        return s;
    }
    public String urlgetData_Class_GiangVien(){
        String s = lh + "result_loptc.php?mauser=";
        return s;
    }
    public String urlgetData_Profile_GiangVien(){
        String s = lh + "result_giangvien_profile.php?mauser=";
        return s;
    }
    public String urlgetData_HocPhan_Admin(String v){

        if(v=="spec"){
            String s = lh + "result_list_hocphan.php?ma_vien=";
            return s;
        }else{
            String s = lh + "result_list_hocphan.php";
            return s;
        }


    }


    public String urlgetData_HeSo_Admin(){
        String s = lh + "result_heso.php";
        return s;
    }
    public String urlgetData_KhoaVien_Admin(){
        String s = lh + "result_khoavien.php";
        return s;
    }

    public String urlsetData_HocPhan(String ma_hoc_phan, String ten_hoc_phan, String ma_vien, String he_so, int tinchi){
        String s = lh+"insert_hocphan.php?ma_hoc_phan="+ ma_hoc_phan+"&ten_hoc_phan="+ten_hoc_phan+"&ma_vien="+ma_vien+"&he_so="+he_so+"&tin_chi="+tinchi;
        return s;
    }

    public String urlgetData_LopSV(){
        String s=lh+"result_lopsv.php";
        return s;
    }

    public String urlgetData_Diem(String maloptc){
        return lh + "result_diem.php?maloptc=" + maloptc;
    }

    public String urlgetData_Thongbao(String magv){
        return lh + "result_thongbao.php?magv=" + magv;
    }


    public String urlupdateData_DiemSv(int mssv, int maloptc, double diemgk, double diemck){
        return lh+"update_diemsv.php?mssv=" +mssv+"&maloptc="+maloptc+"&diemgk="+diemgk+"&diemck="+diemck;
    }

    public String urlupdateDiemChu(String DiemChu, int mssv, int maloptc){
        return lh+"update_diemchusv.php?diemchu="+DiemChu+"&maloptc="+maloptc+"&mssv="+mssv;
    }

    public String urlgetData_Profile_SinhVien(String mauser){
        String s = lh + "result_sinhvien.php?mauser="+mauser;
        return s;
    }

    public String urlgetData_Diem_SinhVien(String mssv){
        String s = lh + "result_diem_sinhvien.php?ms="+mssv;
        return s;
    }

    public String urlgetData_Count_Diem(String mssv){
        return lh+"result_count_diem.php?mssv="+mssv;
    }

    public String urlupdate_HocPhan(String mahocphan, String tenhocphan, String mavien, String heso, String tinchi){
        return lh+"update_hocphan.php?mahocphan="+replace(mahocphan)+"&tenhocphan="+replace(tenhocphan)+"&mavien="+mavien+"&heso="+heso+"&tinchi="+tinchi;
    }
    public String replace(String str) {
        return str.replaceAll(" ", "%20");
    }


    public String urlgetData_ListSv_LopSV(String lopsv){
        return lh+"result_listsv_lopsv.php?lopsv="+replace(lopsv);
    }

    public String urlgetData_ListGV(){
        return lh+"result_listgv.php";
    }

    public String urlupdate_Password(String oldpw, String newpw, int mauser){
        return lh+"update_password.php?oldpw="+oldpw+"&newpw="+newpw+"&mauser="+mauser;
    }

    public String urldelete_hocphan(String mahocphan){
        return lh+"delete_hocphan.php?mahocphan="+mahocphan;
    }
}
