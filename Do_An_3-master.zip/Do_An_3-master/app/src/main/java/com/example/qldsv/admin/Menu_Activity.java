package com.example.qldsv.admin;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.qldsv.R;

public class Menu_Activity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        (this).getSupportActionBar().setTitle(R.string.Menu_Activity);

        Button btn_hocphan = (Button)findViewById(R.id.btn_hocphan);
        btn_hocphan.setOnClickListener(onHocphan);

        Button btn_sv=(Button)findViewById(R.id.btn_sv);
        btn_sv.setOnClickListener(onSV);

        Button btn_gv=(Button)findViewById(R.id.btn_gv);
        btn_gv.setOnClickListener(onGV);
    }
    private View.OnClickListener onHocphan = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(Menu_Activity.this, HocPhan_Activity.class);
            startActivity(intent);
        }
    };

    private View.OnClickListener onSV = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(Menu_Activity.this, ListSinhVien.class);
            startActivity(intent);
        }
    };

    private View.OnClickListener onGV = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(Menu_Activity.this, ListGV.class);
            startActivity(intent);
        }
    };
}
