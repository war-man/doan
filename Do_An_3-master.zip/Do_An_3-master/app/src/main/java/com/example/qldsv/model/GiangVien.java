package com.example.qldsv.model;

import java.util.Date;

public class GiangVien {
    private int MaUser=0;
    private String MaGiangVien="";
    private String MaVien="";
    private String HoTen="";
    private String NgaySinh="";
    private String GioiTinh="";
    private int SoDienThoai=0;

    public GiangVien() {
    }

    public GiangVien(int maUser, String maGiangVien, String maVien, String hoTen, String ngaySinh, String gioiTinh, int soDienThoai) {
        MaUser = maUser;
        MaGiangVien = maGiangVien;
        MaVien = maVien;
        HoTen = hoTen;
        NgaySinh = ngaySinh;
        GioiTinh = gioiTinh;
        SoDienThoai = soDienThoai;
    }

    public int getMaUser() {
        return MaUser;
    }

    public void setMaUser(int maUser) {
        MaUser = maUser;
    }

    public String getMaGiangVien() {
        return MaGiangVien;
    }

    public void setMaGiangVien(String maGiangVien) {
        MaGiangVien = maGiangVien;
    }

    public String getMaVien() {
        return MaVien;
    }

    public void setMaVien(String maVien) {
        MaVien = maVien;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String hoTen) {
        HoTen = hoTen;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        NgaySinh = ngaySinh;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public int getSoDienThoai() {
        return SoDienThoai;
    }

    public void setSoDienThoai(int soDienThoai) {
        SoDienThoai = soDienThoai;
    }

    public String toString(){
        return "MaUser: "+MaUser+", MaGV: "+MaGiangVien+", MaVien: "+MaVien+", HoTen: "+HoTen+", NgaySinh: "+NgaySinh+", GioiTinh: "+GioiTinh+", SDT: "+SoDienThoai;
    }
}
