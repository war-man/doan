package com.example.qldsv.admin;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.model.HeSo;
import com.example.qldsv.model.KhoaVien;
import com.example.qldsv.model.LopTC;
import com.example.qldsv.sinhvien.Setting;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HocPhan_QuanLy extends AppCompatActivity{
    String urlgetData_khoavien;
    String urlgetData_heso;
    /*ArrayList<HeSo> list_Trongso=new ArrayList<HeSo>();*/
    List<String> list_Trongso= new ArrayList<>();
    List<String> list_Vien=new ArrayList<>();
    List<String> list_TC=new ArrayList<>();
    private Spinner spnTrongSo, spnVien, spnTC;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quanly_hocphan);

        (this).getSupportActionBar().setTitle("");

        //Lay du lieu tu activity truoc
        Intent intent = getIntent();


        Bundle bundle = intent.getExtras();

        String _MaHocPhan=bundle.getString("MaHocPhan","");
        final String _TenHocPhan=bundle.getString("TenHocPhan","");
        String _MaVien=bundle.getString("TenVien","CNTT và TT");
        String _HeSo=bundle.getString("HeSo","5-5");
        int _TinChi=bundle.getInt("TinChi",0);

        Log.e("bundle",_MaVien+" "+_HeSo+" "+_TinChi );

        //Lay ten Mahocphan va Tenhocphan
        EditText _Ma_Hoc_Phan_ = (EditText)findViewById(R.id.et_MaHocPhan);
        EditText _Ten_Hoc_Phan = (EditText)findViewById(R.id.et_TenHocPhan);
        spnTC= (Spinner)findViewById(R.id.spn_tc);

        _Ma_Hoc_Phan_.setText(_MaHocPhan);
        _Ten_Hoc_Phan.setText(_TenHocPhan);


        //Gan du lieu cho spinner heso va vien
        spnTrongSo=(Spinner)findViewById(R.id.spn_heso);
        spnVien=(Spinner)findViewById(R.id.spn_vien);


        list_Trongso.add("5-5");
        list_Trongso.add("4-6");
        list_Trongso.add("3-7");
        list_Trongso.add("2-8");
        list_Vien.add("CNTT và TT");
        list_Vien.add("Cơ Khí");
        list_Vien.add("Điện");
        list_Vien.add("Vật Lý Kỹ Thuật");
        list_TC.add("2");
        list_TC.add("3");
        list_TC.add("4");
        list_TC.add("5");
        list_TC.add("12");
        list_TC.add("0");


        ArrayAdapter<String> adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item,list_TC);
        adapter1.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spnTC.setAdapter(adapter1);
        int spinnerPosition_ = list_TC.indexOf(String.valueOf(_TinChi));

        spnTC.setSelection(spinnerPosition_);

        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,list_Trongso);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spnTrongSo.setAdapter(adapter);
        int spinnerPosition = list_Trongso.indexOf(_HeSo);
        spnTrongSo.setSelection(spinnerPosition);


        spnTrongSo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                /*Toast.makeText(HocPhan_QuanLy.this, spnTrongSo.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();*/
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter<String> adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item,list_Vien);
        adapter2.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spnVien.setAdapter(adapter2);
        int spinnerPosition2 = list_Vien.indexOf(_MaVien);
        Log.e("spn pos",String.valueOf(spinnerPosition2));
        spnVien.setSelection(spinnerPosition2);
        spnVien.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                /*Toast.makeText(HocPhan_QuanLy.this, spnVien.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();*/
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        Button button=(Button)findViewById(R.id.hocphan_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText _Ma_Hoc_Phan_ = (EditText)findViewById(R.id.et_MaHocPhan);
                EditText _Ten_Hoc_Phan = (EditText)findViewById(R.id.et_TenHocPhan);
                Spinner _Tin_Chi_ = (Spinner) findViewById(R.id.spn_tc);
                Spinner _Ma_Vien=(Spinner)findViewById(R.id.spn_vien);
                Spinner _HeSo=(Spinner)findViewById(R.id.spn_heso);
                String MV = "";
                switch (_Ma_Vien.getSelectedItem().toString()){
                    case "CNTT và TT":
                        MV="CNTT";
                        break;
                    case "Cơ Khí":
                        MV="CK";
                        break;
                    case "Điện":
                        MV="D";
                        break;
                    case "Vật Lý Kỹ Thuật":
                        MV="VLKT";
                        break;
                }
                getLinkFromDomain gl=new getLinkFromDomain();
                String url=gl.urlupdate_HocPhan(
                        _Ma_Hoc_Phan_.getText().toString(),
                        _Ten_Hoc_Phan.getText().toString(),
                        MV,
                        _HeSo.getSelectedItem().toString(),
                        _Tin_Chi_.getSelectedItem().toString()

                );
                Log.e("url_update_hp",url);
                updateData(url);
            }
        });

        Button del=(Button)findViewById(R.id.hocphan_del);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText MH = (EditText)findViewById(R.id.et_MaHocPhan);



                new AlertDialog.Builder(HocPhan_QuanLy.this)
                        .setTitle("Bạn chắc chắn muốn xóa")
                        .setMessage("Xóa học phần "+MH.getText().toString()+" ?")

                        // Specifying a listener allows you to take an action before dismissing the dialog.
                        // The dialog is automatically dismissed when a dialog button is clicked.
                        .setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with delete operation
                                EditText MHP = (EditText)findViewById(R.id.et_MaHocPhan);
                                getLinkFromDomain gl=new getLinkFromDomain();
                                Log.e("url-del",gl.urldelete_hocphan(MHP.getText().toString()));
                                updateData(gl.urldelete_hocphan(MHP.getText().toString()));
                            }
                        })

                        // A null listener allows the button to dismiss the dialog and take no further action.
                        .setNegativeButton("Hủy", null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

            }
        });
    }


    private void updateData(String url){

        RequestQueue queue = Volley.newRequestQueue(this);  // this = context
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        // display response
                        Log.d("Response", response.toString());
                        if(response.toString().equals("{\"code\":1,\"message\":\"update thanh cong\"}"))
                            Toast.makeText(HocPhan_QuanLy.this,"Thay đổi thành công!",Toast.LENGTH_SHORT).show();
                        else if(response.toString().equals("{\"code\":1,\"message\":\"insert thanh cong\"}"))
                            Toast.makeText(HocPhan_QuanLy.this,"Thêm thành công!",Toast.LENGTH_SHORT).show();
                        else if(response.toString().equals("{\"code\":0,\"message\":\"khong the xoa\"}"))
                            Toast.makeText(HocPhan_QuanLy.this,"Không thể xóa!",Toast.LENGTH_SHORT).show();
                        else if(response.toString().equals("{\"code\":1,\"message\":\"delete thanh cong\"}"))
                            Toast.makeText(HocPhan_QuanLy.this,"Xóa thành công!",Toast.LENGTH_SHORT).show();
                        else Toast.makeText(HocPhan_QuanLy.this,"Có lỗi xảy ra!",Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", error.toString());
                    }
                }
        );

        // add it to the RequestQueue
        queue.add(getRequest);
    }


}
