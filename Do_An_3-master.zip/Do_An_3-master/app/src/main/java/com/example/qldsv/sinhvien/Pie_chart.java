package com.example.qldsv.sinhvien;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.qldsv.R;
import com.example.qldsv.control.getLinkFromDomain;
import com.example.qldsv.control.pieChart;
import com.example.qldsv.giang_vien.Statistic_Giangvien;
import com.example.qldsv.model.Count_Diem;

import org.achartengine.GraphicalView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Pie_chart extends Activity {
    final ArrayList<Count_Diem> arrayDiem = new ArrayList<>();
    int dAp=0,dA=0,dBp=0,dB=0,dCp=0,dC=0,dDp=0,dD=0,dF=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pie_chart);

        getLinkFromDomain gl=new getLinkFromDomain();
        String url=gl.urlgetData_Count_Diem("20166339");
        Log.wtf("url-count",url);


        getData(url);

        Log.d("test", "onCreate: ");
    }


    private void getData(String url) {
        //Ham ket noi voi DB de lay du lieu

        final RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                Count_Diem cc=new Count_Diem(object.getString("Diem"), object.getInt("SoLuong"));
                                Log.wtf("arr564433 ", cc.getDiem() + " " + cc.getSoLuong());





                                switch (cc.getDiem()){
                                    case "A+":{
                                        dAp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dAp));
                                        break;
                                    }
                                    case "A":{
                                        dA=cc.getSoLuong(); Log.wtf("arr56 ", String.valueOf(dA));
                                        break;
                                    }
                                    case "B+":{
                                        dBp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dBp));
                                        break;
                                    }
                                    case "B":{
                                        dB=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dB));
                                        break;
                                    }
                                    case "C+":{
                                        dCp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dCp));
                                        break;
                                    }
                                    case "C":{
                                        dC=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dC));
                                        break;
                                    }
                                    case "D+":{
                                        dDp=cc.getSoLuong(); Log.wtf("arr564433 ", String.valueOf(dDp));
                                        break;
                                    }
                                    case "D":{
                                        dD=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dD));
                                        break;
                                    }
                                    case "F":{
                                        dF=cc.getSoLuong();Log.wtf("arr564433 ", String.valueOf(dF));
                                        break;
                                    }
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }


                        pieChart pie=new pieChart();
                        GraphicalView graphicalView=pie.getraphicalView(Pie_chart.this,dAp,dA,dBp,dB,dCp,dC,dDp,dD,dF);
                        LinearLayout pieGraph=(LinearLayout)findViewById(R.id.piechart);
                        pieGraph.addView(graphicalView);

                        double sd=dAp+dA+dBp+dB+dCp+dC+dDp+dD+dF;

                        TextView txtAp=(TextView)findViewById(R.id.diemAp);
                        TextView txtA=(TextView)findViewById(R.id.diemA);
                        TextView txtBp=(TextView)findViewById(R.id.diemBp);
                        TextView txtB=(TextView)findViewById(R.id.diemB);
                        TextView txtCp=(TextView)findViewById(R.id.diemCp);
                        TextView txtC=(TextView)findViewById(R.id.diemC);
                        TextView txtDp=(TextView)findViewById(R.id.diemDp);
                        TextView txtD=(TextView)findViewById(R.id.diemD);
                        TextView txtF=(TextView)findViewById(R.id.diemF);
                        txtAp.setText("Điểm A+: "+String.valueOf(dAp)+"điểm - "+(double)Math.round(((double)(100*dAp/sd))*100)/100 +"%");
                        txtA.setText("Điểm A: "+String.valueOf(dA)+"điểm - "+(double)Math.round(((double)(100*dA/sd))*100)/100+"%");
                        txtBp.setText("Điểm B+: "+String.valueOf(dBp)+"điểm - "+(double)Math.round(((double)(100*dBp/sd))*100)/100+"%");
                        txtB.setText("Điểm B: "+String.valueOf(dB)+"điểm - "+(double)Math.round(((double)(100*dB/sd))*100)/100+"%");
                        txtCp.setText("Điểm C+: "+String.valueOf(dCp)+"điểm - "+(double)Math.round(((double)(100*dCp/sd))*100)/100+"%");
                        txtC.setText("Điểm C: "+String.valueOf(dC)+"điểm - "+(double)Math.round(((double)(100*dC/sd))*100)/100+"%");
                        txtDp.setText("Điểm D+: "+String.valueOf(dDp)+"điểm - "+(double)Math.round(((double)(100*dDp/sd))*100)/100+"%");
                        txtD.setText("Điểm D: "+String.valueOf(dD)+"điểm - "+(double)Math.round(((double)(100*dD/sd))*100)/100+"%");
                        txtF.setText("Điểm F: "+String.valueOf(dF)+"điểm - "+(double)Math.round(((double)(100*dF/sd))*100)/100+"%");


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }
}
