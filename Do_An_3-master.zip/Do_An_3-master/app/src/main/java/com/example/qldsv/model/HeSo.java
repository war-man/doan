package com.example.qldsv.model;

public class HeSo {
    private String HeSo;

    public HeSo(String heSo) {
        HeSo = heSo;
    }

    public HeSo() {
    }

    public String getHeSo() {
        return HeSo;
    }

    public void setHeSo(String heSo) {
        HeSo = heSo;
    }
    public String toString(){
        return "HeSo: "+ HeSo;
    }
}
