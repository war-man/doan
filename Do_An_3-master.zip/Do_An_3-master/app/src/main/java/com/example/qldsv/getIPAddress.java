package com.example.qldsv;

import com.example.qldsv.giang_vien.Class_Giangvien;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class getIPAddress {

    private void getIP() {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            System.out.println("IP: "+addr.getHostAddress());
        } catch (UnknownHostException ex) {
            Logger.getLogger(Class_Giangvien.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
