package com.example.qldsv.model;

public class KhoaVien {
    private String MaVien;
    private String TenVien;

    public KhoaVien() {
    }

    public KhoaVien(String maVien, String tenVien) {
        MaVien = maVien;
        TenVien = tenVien;
    }

    public String getMaVien() {
        return MaVien;
    }

    public void setMaVien(String maVien) {
        MaVien = maVien;
    }

    public String getTenVien() {
        return TenVien;
    }

    public void setTenVien(String tenVien) {
        TenVien = tenVien;
    }
    public String toString(){
        return TenVien;
    }
}
