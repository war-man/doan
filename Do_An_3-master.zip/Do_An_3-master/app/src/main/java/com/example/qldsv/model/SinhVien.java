package com.example.qldsv.model;

import java.util.Date;

public class SinhVien {
    private int MaUser;
    private int MSSV;
    private String MaLopSV;
    private String HoTen;
    private String NgaySinh;
    private String GioiTinh;
    private int SoDienThoai;

    public SinhVien() {
    }

    public SinhVien(int maUser, int MSSV, String maLopSV, String hoTen, String ngaySinh, String gioiTinh, int soDienThoai) {
        MaUser = maUser;
        this.MSSV = MSSV;
        MaLopSV = maLopSV;
        HoTen = hoTen;
        NgaySinh = ngaySinh;
        GioiTinh = gioiTinh;
        SoDienThoai = soDienThoai;
    }

    public int getMaUser() {
        return MaUser;
    }

    public void setMaUser(int maUser) {
        MaUser = maUser;
    }

    public int getMSSV() {
        return MSSV;
    }

    public void setMSSV(int MSSV) {
        this.MSSV = MSSV;
    }

    public String getMaLopSV() {
        return MaLopSV;
    }

    public void setMaLopSV(String maLopSV) {
        MaLopSV = maLopSV;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String hoTen) {
        HoTen = hoTen;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        NgaySinh = ngaySinh;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public int getSoDienThoai() {
        return SoDienThoai;
    }

    public void setSoDienThoai(int soDienThoai) {
        SoDienThoai = soDienThoai;
    }
}
