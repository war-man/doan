package com.example.quanlytrasua.Common;

import com.example.quanlytrasua.Model.User;

public class Common {
    public static User currentUser;
}
