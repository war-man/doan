# btl_shipdoan
Đây là ứng dụng ship đồ ăn - bài tập lớn môn lập trình android nâng cao của sinh viên Hoàng Hồng Quân lớp N02

![anh1](https://user-images.githubusercontent.com/45795346/56041254-7c979d80-5d62-11e9-9413-2c554deba7ed.png)
![anh2](https://user-images.githubusercontent.com/45795346/56041263-81f4e800-5d62-11e9-80e2-f0f661491a90.png)
![anh3](https://user-images.githubusercontent.com/45795346/56041273-87523280-5d62-11e9-9bc6-287d8de7cf56.png)
![anh4](https://user-images.githubusercontent.com/45795346/56041278-8b7e5000-5d62-11e9-8960-376a245fc27d.png)
