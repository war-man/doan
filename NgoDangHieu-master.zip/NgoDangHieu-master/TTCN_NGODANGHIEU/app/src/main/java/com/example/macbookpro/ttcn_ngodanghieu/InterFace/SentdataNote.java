package com.example.macbookpro.ttcn_ngodanghieu.InterFace;

public interface SentdataNote {
    public void sentNote(String title,String content);
}
