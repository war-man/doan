package com.example.macbookpro.ttcn_ngodanghieu.InterFace;

public interface GoToScream {
    void goTo(int positiom);
//    void sent(int chitieu,int doanhthu);
}
