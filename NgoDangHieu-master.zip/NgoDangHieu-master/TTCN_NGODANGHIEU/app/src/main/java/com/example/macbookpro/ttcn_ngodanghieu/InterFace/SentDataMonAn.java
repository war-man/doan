package com.example.macbookpro.ttcn_ngodanghieu.InterFace;

public interface SentDataMonAn {
    public void sendata(String ten,int id,int sl,int gia);
    public void delete();
    public void hienthanhtoan();
}
