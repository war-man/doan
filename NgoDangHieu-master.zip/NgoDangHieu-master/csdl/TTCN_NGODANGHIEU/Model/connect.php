<?php
	$connect = mysqli_connect("localhost","root","","TTCN_NGODANGHIEU");
	// $connect = mysqli_connect("sql209.unaux.com","unaux_21338597","linh15011997","unaux_21338597_sinhvien");

	mysqli_query($connect,"SET NAMES 'utf8'");
	// mysqli_query($connect,"utf8");
?>