# NgoDangHieu
Bài tập lớn môn Android: App quản lý nhà hàng(hỗ trợ order ,quản lý nhân viên, quản lý kho, quản lý tài chính )

--Giao diện đăng nhập :Khi nhấn chọn vào nút đăng nhập thì chương trình sẽ bắt sự kiện button và kiểm tra điều kiện: Không để trống edittext tên đăng nhập,mật khẩu, tên đăng nhập và mật khẩu đúng hay chưa Nếu edittext tên đăng nhập và mật khẩu trống thông báo cho người dùng”Hay nhập đủ thông tin” tùy theo edittext trống sau đó kiểm tra thông tin tài khoản người dùng nhập nếu đúng thì được  chuyển sang màn hình chính quản lý nhà hàng với chức năng theo từng cấp độ và hiển thị thông báo “ Đăng nhập thành công” đồng thời luu phiên đăng nhập cho quá trình truy cập lại ứng dụng cũng như lưu lại thông tin đăng nhập cho quá trình đăng nhập lần sau.

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/1ab06a8d5e26bc78e537.jpg" height="700" width="400">


--Giao diện Menu chính với người sửu dụng là admin :Hiển thị các chức năng cơ bản quản lý tài chính, quản lý kho, quản lý nhân viên, quản lý order ....

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/d881c0c4f46f16314f7e.jpg" height="700" width="400">

--Giao diện hiển thị tài chính theo tháng hoặc năm:
Hiển thị các sản phẩm đc xuất kho và các sản phẩm được order đồng thời tính số tiền lãi theo tháng hiện tại hoặc năm

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/d68996f1a25a4004194b.jpg" height="700" width="400">

--Giao diện hiển thị menu tuỳ chọn trang chủ

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/b7f374ba4011a24ffb00.jpg" height="700" width="400">

--Giao diện hiển thị thông tin đăng nhập khi chọn thông tin đăng nhập 

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/1797c2fdf65614084d47.jpg" height="700" width="400">

--Giao diện thông báo yêu chấp nhận đăng xuất khỏi ứng dụng

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/0194f5adc10623587a17.jpg" height="700" width="400">

--Giao diện quản lý nhân viên

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/4a1d5e636ac88896d1d9.jpg" height="700" width="400">

-Giao diện thêm nhân viên

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/dedc4cb5781e9a40c30f.jpg" height="700" width="400">

--Giao diện menu tuỳ chọn cho từng nhân viên

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/c197dce6e84d0a13535c.jpg" height="700" width="400">

--Giao diện cập nhật lại mật khẩu cho nhân viên

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/0759a6fb7120937eca31.jpg" height="700" width="400">

--Giao diện quản lý kho

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/e09af9eccd472f197656.jpg" height="700" width="400">

--Giao diện thêm sản phẩm vào kho 

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/fd9f7df1495aab04f24b.jpg" height="700" width="400">

--Giao diện xem chi tiết sản phẩm trong kho 

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/212e27ca3310d14e8801.jpg" height="700" width="400">

--Giao diện xuất sản phẩm trong kho

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/3b33ac5298f97aa723e8.jpg" height="700" width="400">

--Giao diện Order

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/3321667152dab084e9cb.jpg" height="700" width="400">

-Giao diện hiển thị món ăn khi đc tìm kiếm bằng các nhậpj mã hoặc quét Qrcode

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/fc03fc67c8cc2a9273dd.jpg" height="700" width="400">

--Giao diện hiển thị danh sách các món ăn đã  đc order

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/159e2cc21869fa37a378.jpg" height="700" width="400">

--Giao diện hiển thị hoá đơn thanh toán khi được thanh toán 

<img src="https://raw.githubusercontent.com/ngodanghieuictu/NgoDangHieu/master/img/a92ea468b5b257ec0ea3.jpg" height="700" width="400">




