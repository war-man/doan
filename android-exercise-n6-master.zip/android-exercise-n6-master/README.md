# android-exercise-n6

Bài tập nhóm môn Phát triển ứng dụng cho thiết bị di động <br/>
Trường PTIT - Miền Bắc <br/>
Kỳ mùa Xuân 2018 <br/>
Đề tài: Ứng dụng Android đọc truyện tranh <br/>
