package com.uiapp.doan.main.menucontainer.view;

import com.uiapp.doan.base.presenter.IView;

/**
 * Created by hongnhung on 10/23/16.
 */

public interface IMenuContainerView extends IView {
    void goLogin();

    void goThongTin();

    void goAllStaff();

    void goAllOrder();

    void goChoose();
}
