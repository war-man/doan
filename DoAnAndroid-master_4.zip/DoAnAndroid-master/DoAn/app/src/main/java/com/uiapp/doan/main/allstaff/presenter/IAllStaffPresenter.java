package com.uiapp.doan.main.allstaff.presenter;

/**
 * Created by hongnhung on 10/25/16.
 */

public interface IAllStaffPresenter {


    void getallstaff();
    void getAllLicBantho();
}
