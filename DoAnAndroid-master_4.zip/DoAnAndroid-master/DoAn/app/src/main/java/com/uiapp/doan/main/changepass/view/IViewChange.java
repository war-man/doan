package com.uiapp.doan.main.changepass.view;

import com.uiapp.doan.base.presenter.IView;

/**
 * Created by hongnhung on 12/15/16.
 */

public interface IViewChange extends IView {
    void changePasstThoSuccess();
    void changePassThoError();
}
