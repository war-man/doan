package com.uiapp.doan.base.adapter;

/**
 * Created by hongnhung on 10/23/16.
 */

public interface IRecyclerItem {
    int getItemViewType();
}
