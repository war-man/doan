package com.uiapp.doan.interactor.api.request;

import java.io.Serializable;

/**
 * Created by hongnhung on 11/6/16.
 */

public class OrderRequest implements Serializable {


}
