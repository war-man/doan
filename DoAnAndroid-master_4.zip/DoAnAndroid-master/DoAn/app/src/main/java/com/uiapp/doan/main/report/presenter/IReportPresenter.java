package com.uiapp.doan.main.report.presenter;

/**
 * Created by hongnhung on 12/20/16.
 */

public interface IReportPresenter {
    String getQuyen();

    String cmndtho();

    String taikhoan();

    void getAllOrder();

    void getAllOrderTho();
    void getAllTho();

}
