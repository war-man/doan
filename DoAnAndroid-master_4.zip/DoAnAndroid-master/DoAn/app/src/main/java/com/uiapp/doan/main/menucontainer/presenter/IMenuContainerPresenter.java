package com.uiapp.doan.main.menucontainer.presenter;

/**
 * Created by hongnhung on 10/23/16.
 */

public interface IMenuContainerPresenter {
    void goLogOut();
    void goLogin();
    void goThongTin();
    void goDanhSachNguoiSua();
    void goQuanLyGiaoDich();
    void goTimNguoiSua();
    void setQuyen();
    String getQuyen();

}
