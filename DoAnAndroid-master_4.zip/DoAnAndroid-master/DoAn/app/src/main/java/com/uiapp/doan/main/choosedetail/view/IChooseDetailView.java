package com.uiapp.doan.main.choosedetail.view;


import com.uiapp.doan.base.presenter.IView;

public interface IChooseDetailView extends IView {
}
