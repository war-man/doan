package com.uiapp.doan.main.choose.presenter;

import com.uiapp.doan.interactor.api.response.DichVuResponse;
import com.uiapp.doan.interactor.api.response.QuanResponse;

/**
 * Created by hongnhung on 10/23/16.
 */

public interface IChoosePresenter {
    void getAllDichVu();
    void getAllQuan();
}
