package com.uiapp.doan.main.choosedetail.presenter;



public interface IChooseDetailPresenter  {
}
