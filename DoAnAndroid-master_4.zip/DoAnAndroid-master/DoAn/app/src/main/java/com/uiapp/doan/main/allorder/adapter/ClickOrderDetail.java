package com.uiapp.doan.main.allorder.adapter;

/**
 * Created by hongnhung on 11/5/16.
 */

public interface ClickOrderDetail {
    void orderDetail(String orderDetail);
}
