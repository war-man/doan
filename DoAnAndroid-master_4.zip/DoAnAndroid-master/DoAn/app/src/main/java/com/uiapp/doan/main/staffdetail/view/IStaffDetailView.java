package com.uiapp.doan.main.staffdetail.view;

import com.uiapp.doan.base.presenter.IView;

/**
 * Created by hongnhung on 11/19/16.
 */

public interface IStaffDetailView extends IView {
}
