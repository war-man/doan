package com.uiapp.doan.main.choosedetail.injection;


import com.uiapp.doan.injection.PerFragment;

import dagger.Module;

@PerFragment
@Module
public class ChooseDetailModule {
}
