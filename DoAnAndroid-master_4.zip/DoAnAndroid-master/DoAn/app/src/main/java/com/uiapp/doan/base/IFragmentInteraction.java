package com.uiapp.doan.base;

/**
 * Created by hongnhung on 10/23/16.
 */

public interface IFragmentInteraction {
    void onBackScreen();
}
