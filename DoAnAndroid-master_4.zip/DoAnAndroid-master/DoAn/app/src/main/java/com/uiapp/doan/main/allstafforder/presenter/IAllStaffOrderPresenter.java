package com.uiapp.doan.main.allstafforder.presenter;

/**
 * Created by hongnhung on 11/22/16.
 */

public interface IAllStaffOrderPresenter {

    void getAllStaff();
}
