package com.uiapp.doan.main.staffdetail.presenter;

/**
 * Created by hongnhung on 11/19/16.
 */

public interface IStaffDetailPresenter {
}
