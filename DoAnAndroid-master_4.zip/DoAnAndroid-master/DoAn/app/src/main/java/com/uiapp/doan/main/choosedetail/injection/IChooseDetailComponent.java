package com.uiapp.doan.main.choosedetail.injection;



public interface IChooseDetailComponent {
}
