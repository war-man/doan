package com.uiapp.doan.main.signupstaff.presenter;

import com.uiapp.doan.dto.Tho;

/**
 * Created by hongnhung on 11/3/16.
 */

public interface ISignUpStaffPresenter {
    void signUpStaff(Tho tho);
    void getAllDichVu();

}
