package com.uiapp.doan.main.allorder.presenter;

/**
 * Created by hongnhung on 10/25/16.
 */

public interface IAllOrderPresenter  {
    void getAllOrder();
    void getAllOrderTho();

    String getKeyTaiKhoan();
    String getKeyCmnd();
    String getQuyen();

}
