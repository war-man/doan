package com.uiapp.doan.main.allstafforder.adapter;

/**
 * Created by hongnhung on 11/22/16.
 */

public interface OnClickStaffOrder {
    void OnClickDetailStaff( String staffDetail);
}
