package com.uiapp.doan.main.allstaff.adapter;

/**
 * Created by hongnhung on 11/1/16.
 */

public interface OnClickStaff {
    void OnClickDetailStaff( String staffDetail);

    void OnClickOrderStaff(String  staffDetail);
}
