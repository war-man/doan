package com.example.milkteaappandroid.Controller.Interfaces;

import com.example.milkteaappandroid.Model.SanPhamModel;

import java.util.List;

public interface sanphammoiInterface {
    void getDanhSachSanPhamMoiModel(SanPhamModel sanPhamModel);
}
