package com.example.milkteaappandroid.Controller.Interfaces;

import com.example.milkteaappandroid.Model.SanPhamChinaModel;
import com.example.milkteaappandroid.Model.SanPhamModel;

public interface SanPhamChinaInterface {
    void getDanhSachSanPhamChinaModel(SanPhamChinaModel sanPhamChinaModel);
}
