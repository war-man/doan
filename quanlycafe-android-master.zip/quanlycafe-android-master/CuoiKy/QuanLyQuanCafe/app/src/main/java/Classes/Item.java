package Classes;

public class Item {
    public Product product;
    public int quantity;
    public int discount;
}
