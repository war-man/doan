package xyz.khang.baitap_06042019;

public class Film {
    public String name;
    public String vietSub;
    public int rate;
}
