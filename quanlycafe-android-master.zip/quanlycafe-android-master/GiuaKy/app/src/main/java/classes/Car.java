package classes;

public class Car {
    public String MAXE;
    public String TENXE;
    public String XUATXU;
}
