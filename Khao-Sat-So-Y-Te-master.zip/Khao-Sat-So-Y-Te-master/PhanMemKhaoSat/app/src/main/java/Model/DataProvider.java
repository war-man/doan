package Model;

import java.util.ArrayList;

/**
 * Created by hung-pc on 5/4/2017.
 */

public class DataProvider
{
    public static ArrayList<DataListView> arrDanhSachDotKhaoSat = new ArrayList<DataListView>();
    public static  ArrayList<TaiKhoan> arrTaiKhoan = new ArrayList<TaiKhoan>();
}
