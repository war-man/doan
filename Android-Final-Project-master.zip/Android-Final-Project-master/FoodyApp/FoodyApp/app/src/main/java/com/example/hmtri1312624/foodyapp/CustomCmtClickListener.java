package com.example.hmtri1312624.foodyapp;

import android.view.View;

/**
 * Created by M-Tae on 5/22/2016.
 */
public interface CustomCmtClickListener {
    public void onCmtClick(View v, int position);
}
