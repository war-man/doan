package com.example.hmtri1312624.foodyapp;

import android.view.View;

/**
 * Created by M-Tae on 4/7/2016.
 */

public interface CustomItemClickListener {
    public void onItemClick(View v, int position);
}

