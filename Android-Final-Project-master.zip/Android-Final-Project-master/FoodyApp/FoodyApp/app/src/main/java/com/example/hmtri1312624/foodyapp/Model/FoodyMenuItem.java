package com.example.hmtri1312624.foodyapp.Model;

/**
 * Created by M-Tae on 5/22/2016.
 */
public class FoodyMenuItem {
    public String Avatar;
    public String Price;
    public String DetailLink;

    public FoodyMenuItem(String avatar, String price, String detailLink) {
        Avatar = avatar;
        Price = price;
        DetailLink = detailLink;
    }
}
