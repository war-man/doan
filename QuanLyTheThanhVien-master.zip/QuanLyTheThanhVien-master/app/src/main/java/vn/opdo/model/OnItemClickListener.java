package vn.opdo.model;


public interface OnItemClickListener {
    void onItemClick(Card item, boolean longClick, int position);
}