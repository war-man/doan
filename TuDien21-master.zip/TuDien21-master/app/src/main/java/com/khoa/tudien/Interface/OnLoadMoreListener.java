package com.khoa.tudien.Interface;

public interface OnLoadMoreListener {
    void onLoadMore();
}
