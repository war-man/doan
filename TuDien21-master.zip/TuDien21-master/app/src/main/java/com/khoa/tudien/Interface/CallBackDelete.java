package com.khoa.tudien.Interface;

public interface CallBackDelete {
    public void deleteWord();
}
